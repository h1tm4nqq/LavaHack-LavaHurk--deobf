/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 */
package lavahack.client;

import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

class AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$leqS0IyKEB621E1SrHdAcHHAUjScjmKi {
    private final BlockPos Field10856;
    private final EnumFacing Field10857;
    private String Field10858 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(BlockPos blockPos, EnumFacing enumFacing) {
        this.Field10856 = blockPos;
        this.Field10857 = enumFacing;
    }

    public BlockPos Method2856() {
        return this.Field10856;
    }

    public EnumFacing Method2857() {
        return this.Field10857;
    }
}

