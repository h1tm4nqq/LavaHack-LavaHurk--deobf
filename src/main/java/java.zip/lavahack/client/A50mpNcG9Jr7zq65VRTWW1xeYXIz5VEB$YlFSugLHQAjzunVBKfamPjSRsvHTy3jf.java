/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ServerData
 */
package lavahack.client;

import lavahack.client.A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB;
import net.minecraft.client.multiplayer.ServerData;

public class A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf
extends A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB {
    private int Field10484;

    public A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf(ServerData serverData) {
        super(serverData);
    }
}

