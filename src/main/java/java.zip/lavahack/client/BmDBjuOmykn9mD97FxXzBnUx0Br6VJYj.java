/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0;
import lavahack.client.fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011\u00a8\u0006\u0012"}, d2={"Lcom/kisman/cc/util/enums/Fonts;", "", "font", "Lcom/kisman/cc/util/render/customfont/AbstractFontRenderer;", "(Ljava/lang/String;ILcom/kisman/cc/util/render/customfont/AbstractFontRenderer;)V", "getFont", "()Lcom/kisman/cc/util/render/customfont/AbstractFontRenderer;", "Verdana", "Comfortaa", "ComfortaaLight", "ComfortaaBold", "Consolas", "LexendDeca", "Futura", "SfUi", "Century", "JelleeBold", "MinecraftRus", "kisman.cc"})
public final class BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj
extends Enum {
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14654;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14655;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14656;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14657;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14658;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14659;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14660;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14661;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14662;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14663;
    public static final /* enum */ BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Field14664;
    private static final BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj[] Field14665;
    @NotNull
    private final XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field14666;
    private String Field14667 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj[] bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj[(int)((long)-1423911784 ^ (long)-1423911789)];
        BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj[] bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray2 = bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray;
        int n = (int)1900270894L ^ 0x7143D52E;
        int n2 = (int)2078444714L ^ 0x7BE28CAA;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13333;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i0, (String)"verdana18");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n] = Field14654 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("Verdana", n2, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i0);
        int n3 = (int)614754165L ^ 0x24A46774;
        int n4 = (int)1183814776L ^ 0x468F9479;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i02 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13321;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i02, (String)"comfortaa18");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n3] = Field14655 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("Comfortaa", n4, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i02);
        int n5 = ((int)410198462L ^ 0x187321BF) << 1;
        int n6 = (int)((long)-1769789559 ^ (long)-1769789560) << 1;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i03 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13310;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i03, (String)"comfortaal18");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n5] = Field14656 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("ComfortaaLight", n6, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i03);
        int n7 = (int)((long)1115633217 ^ (long)1115633218);
        int n8 = (int)574720240L ^ 0x224188F3;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i04 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13317;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i04, (String)"comfortaab18");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n7] = Field14657 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("ComfortaaBold", n8, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i04);
        int n9 = (int)((long)664704239 ^ (long)664704238) << 2;
        int n10 = (int)((long)1647939369 ^ (long)1647939368) << 2;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i05 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13324;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i05, (String)"consolas18");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n9] = Field14658 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("Consolas", n10, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i05);
        int n11 = (int)((long)967209549 ^ (long)967209544);
        int n12 = (int)((long)1355258925 ^ (long)1355258920);
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i06 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13331;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i06, (String)"lexendDeca18");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n11] = Field14659 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("LexendDeca", n12, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i06);
        int n13 = (int)((long)270823794 ^ (long)270823793) << 1;
        int n14 = (int)((long)-553290150 ^ (long)-553290151) << 1;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i07 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13329;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i07, (String)"futura20");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n13] = Field14660 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("Futura", n14, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i07);
        int n15 = (int)((long)99125966 ^ (long)99125961);
        int n16 = (int)((long)1380531810 ^ (long)1380531813);
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i08 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13327;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i08, (String)"sfui19");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n15] = Field14661 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("SfUi", n16, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i08);
        int n17 = ((int)845504320L ^ 0x32655F41) << 3;
        int n18 = (int)((long)-212901825 ^ (long)-212901826) << 3;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i09 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13332;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i09, (String)"century18");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n17] = Field14662 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("Century", n18, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i09);
        int n19 = (int)1585612479L ^ 0x5E8286B6;
        int n20 = (int)-96839855L ^ 0xFA3A5758;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i010 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13334;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i010, (String)"jelleeb18");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n19] = Field14663 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("JelleeBold", n20, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i010);
        int n21 = ((int)-155735261L ^ 0xF6B7AB26) << 1;
        int n22 = ((int)1967711052L ^ 0x7548E349) << 1;
        XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 xFDKv2nzCgumb6lLxnd2S4gp8mbth6i011 = fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Field13335;
        Intrinsics.checkExpressionValueIsNotNull((Object)xFDKv2nzCgumb6lLxnd2S4gp8mbth6i011, (String)"minecraftRus13");
        bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray[n21] = Field14664 = new BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj("MinecraftRus", n22, xFDKv2nzCgumb6lLxnd2S4gp8mbth6i011);
        Field14665 = bmDBjuOmykn9mD97FxXzBnUx0Br6VJYjArray;
    }

    @NotNull
    @NotNull
    public final XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Method5712() {
        return this.Field14666;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj() {
        void var3_1;
        void var2_-1;
        void var1_-1;
        this.Field14666 = var3_1;
    }

    public static BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj[] values() {
        return (BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj[])Field14665.clone();
    }

    public static BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj valueOf(String string) {
        return Enum.valueOf(BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj.class, string);
    }

    private static String Method5713(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-821433443 ^ (long)-821433443);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)1871409196L ^ 0x6F8B70D3);
            int n2 = (int)((long)-2143689346 ^ (long)-2143689401);
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)-1727845193 ^ (long)-1727832760) ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

