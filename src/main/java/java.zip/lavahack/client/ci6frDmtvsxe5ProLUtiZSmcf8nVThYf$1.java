/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;

class ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$1 {
    static final int[] Field13263 = new int[ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.values().length];
    private String Field13264 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$1.Field13263[ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field10003.ordinal()] = (int)-219364182L ^ 0xF2ECC4AB;
        ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$1.Field13263[ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field10004.ordinal()] = ((int)-2142843008L ^ 0x8046CF81) << 1;
    }
}

