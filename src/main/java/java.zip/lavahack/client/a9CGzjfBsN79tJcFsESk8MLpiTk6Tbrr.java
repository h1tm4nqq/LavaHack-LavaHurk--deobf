/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.RenderGlobal
 *  net.minecraft.client.renderer.chunk.IRenderChunkFactory
 *  net.minecraft.world.World
 */
package lavahack.client;

import lavahack.client.aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.chunk.IRenderChunkFactory;
import net.minecraft.world.World;

public interface a9CGzjfBsN79tJcFsESk8MLpiTk6Tbrr
extends IRenderChunkFactory {
    public aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC makeRenderOverlay(World var1, RenderGlobal var2, int var3);
}

