/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.chunk.RenderChunk
 */
package lavahack.client;

import com.kisman.cc.event.Event;
import net.minecraft.client.renderer.chunk.RenderChunk;

public class D2A33i4puy3VG87sLGopuKBa7759W0RD
extends Event {
    public RenderChunk Field15074;
    private String Field15075 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public D2A33i4puy3VG87sLGopuKBa7759W0RD(RenderChunk renderChunk) {
        super(new Object[(int)1667073912L ^ 0x635D8778]);
        this.Field15074 = renderChunk;
    }
}

