/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD;
import lavahack.client.mfMV2c4rVa7u4GL8lHnT3me6PuDQR04X;
import lavahack.client.xDcocRY9ZnZXaPQ8zU20qL5jXWb6vgwF;

public class DXjKqX0c7P4em579SJwxKJk7QIiAoRBF
extends EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD {
    public double Field15157;
    private String Field15158 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF() {
        this(0.0, 0.0, 0.0);
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF) {
        this(dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf, dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV, dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.Field15157);
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF(double d) {
        this(d, d, d);
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF(double d, double d2, double d3) {
        super(d, d2);
        this.Field15157 = d3;
    }

    public final double Method5846() {
        return this.Field15157;
    }

    public final void Method5847(double d) {
        this.Field15157 = d;
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5848(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF) {
        return this.Method5849(dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf, dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV, dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.Field15157);
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5849(double d, double d2, double d3) {
        this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf = d;
        this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV = d2;
        this.Field15157 = d3;
        return this;
    }

    @Override
    public double Method5826() {
        return this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf * this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf + this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV * this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV + this.Field15157 * this.Field15157;
    }

    public final double Method5850(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF) {
        return Math.sqrt(this.Method5851(dXjKqX0c7P4em579SJwxKJk7QIiAoRBF));
    }

    public double Method5851(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF) {
        return this.Method5829(this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf - dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf) + this.Method5829(this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV - dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV) + this.Method5829(this.Field15157 - dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.Field15157);
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5852() {
        this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf = -this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
        this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV = -this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV;
        this.Field15157 = -this.Field15157;
        return this;
    }

    public double Method5853(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF) {
        return this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf * dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf + this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV * dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV + this.Field15157 * dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.Field15157;
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5854(double d) {
        this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf *= d;
        this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV *= d;
        this.Field15157 *= d;
        return this;
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5855(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF) {
        this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf += dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
        this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV += dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV;
        this.Field15157 += dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.Field15157;
        return this;
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5856(double d, double d2, double d3) {
        this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf += d;
        this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV += d2;
        this.Field15157 += d3;
        return this;
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5857(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF) {
        this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf -= dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
        this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV -= dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV;
        this.Field15157 -= dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.Field15157;
        return this;
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5858(double d, double d2, double d3) {
        this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf -= d;
        this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV -= d2;
        this.Field15157 -= d3;
        return this;
    }

    public xDcocRY9ZnZXaPQ8zU20qL5jXWb6vgwF Method5859() {
        return new xDcocRY9ZnZXaPQ8zU20qL5jXWb6vgwF((int)Math.floor(this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf), (int)Math.floor(this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV), (int)Math.floor(this.Field15157));
    }

    public xDcocRY9ZnZXaPQ8zU20qL5jXWb6vgwF Method5860(xDcocRY9ZnZXaPQ8zU20qL5jXWb6vgwF xDcocRY9ZnZXaPQ8zU20qL5jXWb6vgwF2) {
        return xDcocRY9ZnZXaPQ8zU20qL5jXWb6vgwF2.Method1032((int)Math.floor(this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf), (int)Math.floor(this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV), (int)Math.floor(this.Field15157));
    }

    public mfMV2c4rVa7u4GL8lHnT3me6PuDQR04X Method5861() {
        return new mfMV2c4rVa7u4GL8lHnT3me6PuDQR04X((float)Math.floor(this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf), (float)Math.floor(this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV), (float)Math.floor(this.Field15157));
    }

    public mfMV2c4rVa7u4GL8lHnT3me6PuDQR04X Method5862(mfMV2c4rVa7u4GL8lHnT3me6PuDQR04X mfMV2c4rVa7u4GL8lHnT3me6PuDQR04X2) {
        return mfMV2c4rVa7u4GL8lHnT3me6PuDQR04X2.Method6910((float)Math.floor(this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf), (float)Math.floor(this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV), (float)Math.floor(this.Field15157));
    }

    public DXjKqX0c7P4em579SJwxKJk7QIiAoRBF Method5863() {
        return new DXjKqX0c7P4em579SJwxKJk7QIiAoRBF(this);
    }

    @Override
    public boolean equals(Object object) {
        int n;
        if (object instanceof DXjKqX0c7P4em579SJwxKJk7QIiAoRBF && this.Method5864((DXjKqX0c7P4em579SJwxKJk7QIiAoRBF)object)) {
            n = (int)((long)-1594566223 ^ (long)-1594566224);
            return n != 0;
        }
        n = (int)479417445L ^ 0x1C935465;
        return n != 0;
    }

    public boolean Method5864(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF) {
        return this.Method5865(dXjKqX0c7P4em579SJwxKJk7QIiAoRBF, Double.longBitsToDouble((long)1824382635 ^ 0x3EE4F8B5ECBDDEABL));
    }

    public boolean Method5865(DXjKqX0c7P4em579SJwxKJk7QIiAoRBF dXjKqX0c7P4em579SJwxKJk7QIiAoRBF, double d) {
        int n;
        if (Math.abs(this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf - dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf) < d && Math.abs(this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV - dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV) < d && Math.abs(this.Field15157 - dXjKqX0c7P4em579SJwxKJk7QIiAoRBF.Field15157) < d) {
            n = (int)((long)-435124896 ^ (long)-435124895);
            return n != 0;
        }
        n = (int)-1064254467L ^ 0xC090C3FD;
        return n != 0;
    }

    @Override
    public String toString() {
        Object[] objectArray = new Object[(int)-1259880949L ^ 0xB4E7BE08];
        objectArray[(int)((long)1809191592 ^ (long)1809191592)] = this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
        objectArray[(int)548734004L ^ 0x20B50435] = this.UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV;
        objectArray[((int)979620595L ^ 0x3A63D2F2) << 1] = this.Field15157;
        return String.format("[%s, %s, %s]", objectArray);
    }

    @Override
    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5842() {
        return this.Method5863();
    }

    @Override
    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5833(double d) {
        return this.Method5854(d);
    }

    @Override
    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5831() {
        return this.Method5852();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return this.Method5863();
    }

    private static String Method5845(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)882867220 ^ (long)882867220);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)1521653780L ^ 0x5AB298EB);
            int n2 = (int)((long)-296421507 ^ (long)-296421424);
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)-460347455 ^ (long)-460353654) ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

