/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import java.util.function.Supplier;
import kotlin.Metadata;
import lavahack.client.DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=3, d1={"\u0000\b\n\u0000\n\u0002\u0010\u000b\n\u0000\u0010\u0000\u001a\u00020\u0001H\n\u00a2\u0006\u0002\b\u0002"}, d2={"<anonymous>", "", "get"})
final class DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU$ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS
implements Supplier {
    final DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU Field15936;
    private String Field15937 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public Object get() {
        return this.Method6599();
    }

    public final boolean Method6599() {
        return this.Field15936.Method2737().Method365();
    }

    DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU$ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS(DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU dZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU) {
        this.Field15936 = dZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU;
    }
}

