/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;

class aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$1 {
    static final int[] Field11832 = new int[aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.values().length];
    private int Field11833;

    static {
        aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$1.Field11832[aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field12709.ordinal()] = (int)((long)-222590067 ^ (long)-222590068);
        aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$1.Field11832[aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field12710.ordinal()] = (int)((long)950591680 ^ (long)950591681) << 1;
        aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$1.Field11832[aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field12711.ordinal()] = (int)((long)1161530766 ^ (long)1161530765);
        aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$1.Field11832[aYbbYntkurUPImKqpn4NToDjVrwxuFgJ$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field12712.ordinal()] = ((int)1184781383L ^ 0x469E5446) << 2;
    }
}

