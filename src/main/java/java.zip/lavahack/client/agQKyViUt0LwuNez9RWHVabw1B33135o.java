/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.resources.IResource
 */
package lavahack.client;

import lavahack.client.Csi3zhdVbG2hwuonRwuIPTdK5alKV1HC;
import net.minecraft.client.resources.IResource;

@FunctionalInterface
public interface agQKyViUt0LwuNez9RWHVabw1B33135o {
    public IResource Method3676() throws Csi3zhdVbG2hwuonRwuIPTdK5alKV1HC;
}

