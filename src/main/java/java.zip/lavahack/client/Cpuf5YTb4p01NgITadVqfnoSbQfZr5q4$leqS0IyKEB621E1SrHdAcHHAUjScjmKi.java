/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005\u00a8\u0006\u0006"}, d2={"Lcom/kisman/cc/websockets/data/SocketMessage$Type;", "", "(Ljava/lang/String;I)V", "Text", "File", "Bytes", "kisman.cc"})
public final class Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends Enum {
    public static final /* enum */ Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field11110;
    public static final /* enum */ Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field11111;
    public static final /* enum */ Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field11112;
    private static final Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] Field11113;
    private String Field11114 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray = new Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[(int)1886068663L ^ 0x706B1FB4];
        Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray2 = cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
        cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)414888044L ^ 0x18BAB06C] = Field11110 = new Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Text", (int)-1701823473L ^ 0x9A903C0F);
        cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)-319002632L ^ 0xECFC67F9] = Field11111 = new Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("File", (int)((long)-1953691610 ^ (long)-1953691609));
        cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[((int)-249065712L ^ 0xF1278F11) << 1] = Field11112 = new Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Bytes", (int)((long)1798025491 ^ (long)1798025490) << 1);
        Field11113 = cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
        void var2_-1;
        void var1_-1;
    }

    public static Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] values() {
        return (Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[])Field11113.clone();
    }

    public static Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi valueOf(String string) {
        return Enum.valueOf(Cpuf5YTb4p01NgITadVqfnoSbQfZr5q4$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.class, string);
    }

    private static String Method3060(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)-380375532L ^ 0xE953EE14;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)1535877882L ^ 0x5B8BA205);
            int n2 = (int)((long)-444005316 ^ (long)-444005245);
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)-1833334853 ^ (long)-1833333592) ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

