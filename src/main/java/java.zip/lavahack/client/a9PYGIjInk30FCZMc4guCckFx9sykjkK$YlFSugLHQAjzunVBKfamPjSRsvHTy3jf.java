/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R2\u0010\u0006\u001a&\u0012\f\u0012\n \b*\u0004\u0018\u00010\u00050\u0005 \b*\u0012\u0012\f\u0012\n \b*\u0004\u0018\u00010\u00050\u0005\u0018\u00010\u00070\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\t"}, d2={"Lcom/kisman/cc/util/enums/dynamic/CharmsRewriteOptionsEnum$Companion;", "", "()V", "task", "Lorg/cubic/dynamictask/AbstractTask$DelegateAbstractTask;", "Ljava/lang/Void;", "voidTask", "Lorg/cubic/dynamictask/AbstractTask;", "kotlin.jvm.PlatformType", "kisman.cc"})
public final class a9PYGIjInk30FCZMc4guCckFx9sykjkK$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf {
    private String Field10655 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    private a9PYGIjInk30FCZMc4guCckFx9sykjkK$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf() {
    }

    public a9PYGIjInk30FCZMc4guCckFx9sykjkK$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }
}

