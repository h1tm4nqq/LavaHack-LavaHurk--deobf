/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import com.kisman.cc.event.Event;

public class fWLM1xYQAvLvszZ46JEibQwGmnGO0DeQ
extends Event {
    public float Field14969;
    public float Field14970;
    public float Field14971;
    private String Field14972 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public fWLM1xYQAvLvszZ46JEibQwGmnGO0DeQ(float f, float f2, float f3) {
        super(new Object[(int)-185896375L ^ 0xF4EB7249]);
        this.Field14969 = f;
        this.Field14970 = f2;
        this.Field14971 = f3;
    }
}

