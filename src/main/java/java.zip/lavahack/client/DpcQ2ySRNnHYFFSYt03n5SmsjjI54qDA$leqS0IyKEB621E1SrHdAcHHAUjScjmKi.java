/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;

class DpcQ2ySRNnHYFFSYt03n5SmsjjI54qDA$leqS0IyKEB621E1SrHdAcHHAUjScjmKi {
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field11280 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, new Class[(int)31081260L ^ 0x1DA432C]);
    private int Field11281;

    private DpcQ2ySRNnHYFFSYt03n5SmsjjI54qDA$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
    }

    static hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method3228() {
        return Field11280;
    }
}

