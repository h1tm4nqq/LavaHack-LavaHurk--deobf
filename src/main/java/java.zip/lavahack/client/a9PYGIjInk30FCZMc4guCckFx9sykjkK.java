/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\u0018\u0000 \u00042\u00020\u0001:\u0002\u0003\u0004B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0005"}, d2={"Lcom/kisman/cc/util/enums/dynamic/CharmsRewriteOptionsEnum;", "", "()V", "CharmsRewriteOptions", "Companion", "kisman.cc"})
public final class a9PYGIjInk30FCZMc4guCckFx9sykjkK {
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field9553;
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field9554;
    public static final a9PYGIjInk30FCZMc4guCckFx9sykjkK$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field9555;
    private String Field9556 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        Field9555 = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf(null);
        Class[] classArray = new Class[(int)((long)1051973022 ^ (long)1051973023)];
        classArray[(int)((long)-831898397 ^ (long)-831898397)] = Void.class;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, classArray);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf, (String)"AbstractTask.types(\n    \u2026oid::class.java\n        )");
        Field9553 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
        Field9554 = Field9553.Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV.Field17339);
    }

    public static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method1820() {
        return Field9553;
    }

    public static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method1821() {
        return Field9554;
    }

    private static String Method1822(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)2056010515L ^ 0x7A8C3B13;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-1646430658L ^ 0x9DDD76C1);
            int n2 = ((int)-355805217L ^ 0xEACAD7FE) << 2;
            cArray2[n] = (char)(cArray[n] ^ (((int)1636605949L ^ 0x618C92E8) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

