/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 */
package lavahack.client;

import java.util.List;
import net.minecraft.block.state.IBlockState;

public interface BncXhW1Lav2keMHZiuNSuqnTUtKdNWgY {
    public List Method6049(List var1, IBlockState var2);
}

