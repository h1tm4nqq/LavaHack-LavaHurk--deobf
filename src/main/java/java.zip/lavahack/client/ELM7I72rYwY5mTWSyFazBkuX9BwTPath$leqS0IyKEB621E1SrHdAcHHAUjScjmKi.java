/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public final class ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends Enum {
    public static final /* enum */ ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field13466 = new ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("BEGIN_WAIT", (int)((long)916986635 ^ (long)916986635), ((int)393492222L ^ 0x177436FF) != 0);
    public static final /* enum */ ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field13467 = new ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("BEGIN", (int)((long)-119853439 ^ (long)-119853440));
    public static final /* enum */ ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field13468 = new ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("CHUNK_WAIT", (int)((long)-443566520 ^ (long)-443566519) << 1, (boolean)((long)-1600286404 ^ (long)-1600286403));
    public static final /* enum */ ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field13469 = new ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("CHUNK", (int)((long)1322273611 ^ (long)1322273608));
    public static final /* enum */ ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field13470 = new ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("END_WAIT", (int)((long)1056597312 ^ (long)1056597313) << 2, (boolean)((long)1799672633 ^ (long)1799672632));
    public static final /* enum */ ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field13471 = new ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("END", (int)((long)1369925426 ^ (long)1369925431));
    private boolean Field13472;
    private static final ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] Field13473;
    private String Field13474 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public static ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] values() {
        return (ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[])Field13473.clone();
    }

    public static ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi valueOf(String string) {
        return Enum.valueOf(ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.class, string);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
        void var2_-1;
        void var1_-1;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
        void var3_1;
        void var2_-1;
        void var1_-1;
        this.Field13472 = var3_1;
    }

    public boolean Method4867() {
        return this.Field13472;
    }

    static {
        ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray = new ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[(int)((long)1183690127 ^ (long)1183690124) << 1];
        eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)-1649672058 ^ (long)-1649672058)] = Field13466;
        eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)1544396768 ^ (long)1544396769)] = Field13467;
        eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[((int)-1618356074L ^ 0x9F89D897) << 1] = Field13468;
        eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)-1668103931 ^ (long)-1668103930)] = Field13469;
        eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[((int)-1997395541L ^ 0x88F229AA) << 2] = Field13470;
        eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)-950437148L ^ 0xC7597AE1] = Field13471;
        Field13473 = eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
    }

    private static String Method4868(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)1302167339L ^ 0x4D9D7F2B;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)2123610351 ^ (long)2123610128);
            int n2 = (int)((long)-837136598 ^ (long)-837136561) << 1;
            cArray2[n] = (char)(cArray[n] ^ ((int)1300371932L ^ 0x4D824391 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

