/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL;
import lavahack.client.ikFh2tmmaEajuvVhfN5Stlzrrra2EacP;
import lavahack.client.mPNKUHesROKSVtFpAZyhLqRAupt8dodO;

public abstract class c5C8Nidhqo0zCg0ZubFUIxZ7PBIbYfMx
extends ikFh2tmmaEajuvVhfN5Stlzrrra2EacP {
    private String Field14770 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public c5C8Nidhqo0zCg0ZubFUIxZ7PBIbYfMx(mPNKUHesROKSVtFpAZyhLqRAupt8dodO mPNKUHesROKSVtFpAZyhLqRAupt8dodO2) {
        super(mPNKUHesROKSVtFpAZyhLqRAupt8dodO2);
    }

    @Override
    public void Method1620() throws eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL {
    }
}

