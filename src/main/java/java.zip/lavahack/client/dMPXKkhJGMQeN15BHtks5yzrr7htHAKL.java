/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import lavahack.client.CwEo7gYx6g7WvHLf7z8vSrm0Y59KeUvY;
import lavahack.client.leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

public abstract class dMPXKkhJGMQeN15BHtks5yzrr7htHAKL {
    private static final Map Field16925 = new HashMap(((int)935391288L ^ 0x37C0F039) << 6);
    private final Map Field16926 = new HashMap();
    private String Field16927 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    @Deprecated
    @Deprecated
    public static dMPXKkhJGMQeN15BHtks5yzrr7htHAKL Method2726(String string) {
        dMPXKkhJGMQeN15BHtks5yzrr7htHAKL dMPXKkhJGMQeN15BHtks5yzrr7htHAKL2 = (dMPXKkhJGMQeN15BHtks5yzrr7htHAKL)((Callable)Field16925.get(string)).call();
        dMPXKkhJGMQeN15BHtks5yzrr7htHAKL2.Method2730();
        return dMPXKkhJGMQeN15BHtks5yzrr7htHAKL2;
    }

    @Deprecated
    @Deprecated
    public static void Method2727(String string, Callable callable) {
        Field16925.put(string, callable);
    }

    protected final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Method2728(String string, qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2) {
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16241.Field16258.Method7569(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2);
        this.Field16926.put(string, qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2);
        return qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2;
    }

    public dMPXKkhJGMQeN15BHtks5yzrr7htHAKL Method2729() {
        this.Method2730();
        return this;
    }

    protected void Method2730() {
    }

    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Method2731(String string) {
        return (qdws5c2TrWCYwByZ0oQUUWIrq72gJscD)this.Field16926.get(string);
    }

    public abstract CwEo7gYx6g7WvHLf7z8vSrm0Y59KeUvY Method2732();
}

