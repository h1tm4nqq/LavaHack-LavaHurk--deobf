/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL20
 */
package lavahack.client;

import lavahack.client.HtWBWK2ivuwKi50cf15GY5qM8YWcaqqp;
import lavahack.client.WieLcrIxU3iYF11f2EiUDyi7gNqAZWP8;
import org.lwjgl.opengl.GL20;

public class DP2YaKl8Qd5YZRL2RjJeCWnDJiiFSGP1
extends WieLcrIxU3iYF11f2EiUDyi7gNqAZWP8 {
    private String Field14236 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public HtWBWK2ivuwKi50cf15GY5qM8YWcaqqp Method5469() {
        return new HtWBWK2ivuwKi50cf15GY5qM8YWcaqqp();
    }

    public DP2YaKl8Qd5YZRL2RjJeCWnDJiiFSGP1 Method5470(int n) {
        GL20.glUniform2i((int)n, (int)((HtWBWK2ivuwKi50cf15GY5qM8YWcaqqp)this.Method647()).Field11301, (int)((HtWBWK2ivuwKi50cf15GY5qM8YWcaqqp)this.Method647()).Field11302);
        return this;
    }

    @Override
    public Object Method646(int n) {
        return this.Method5470(n);
    }

    @Override
    public Object Method645() {
        return this.Method5469();
    }
}

