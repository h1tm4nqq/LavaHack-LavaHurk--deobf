/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraftforge.fml.common.eventhandler.Cancelable
 *  net.minecraftforge.fml.common.eventhandler.Event
 */
package lavahack.client;

import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class BrWsHdiLAwYGSB35z3ypQAx8eRulUOBh
extends Event {
    private Entity Field12973;
    private String Field12974 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public BrWsHdiLAwYGSB35z3ypQAx8eRulUOBh(Entity entity) {
        this.Field12973 = entity;
    }

    public Entity leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
        return this.Field12973;
    }
}

