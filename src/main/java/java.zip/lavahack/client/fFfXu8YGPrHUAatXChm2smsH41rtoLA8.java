/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 */
package lavahack.client;

import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import net.minecraft.block.Block;

public class fFfXu8YGPrHUAatXChm2smsH41rtoLA8 {
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field14025 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Block.class, new Class[(int)((long)-1137527857 ^ (long)-1137527857)]);
    private String Field14026 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method5340() {
        return Field14025;
    }
}

