/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.lang.reflect.Method;

class dsGGdHDauaEpIGTENBJZHKgBhLIqd0D5 {
    private final Method Field15143;
    private final Object Field15144;
    private int Field15145;

    public dsGGdHDauaEpIGTENBJZHKgBhLIqd0D5(Method method, Object object) {
        this.Field15143 = method;
        this.Field15144 = object;
    }

    public Method Method6067() {
        return this.Field15143;
    }

    public Object Method6068() {
        return this.Field15144;
    }

    public boolean equals(Object object) {
        int n;
        if (!(object instanceof dsGGdHDauaEpIGTENBJZHKgBhLIqd0D5)) {
            return ((int)-523128029L ^ 0xE0D1B323) != 0;
        }
        dsGGdHDauaEpIGTENBJZHKgBhLIqd0D5 dsGGdHDauaEpIGTENBJZHKgBhLIqd0D52 = (dsGGdHDauaEpIGTENBJZHKgBhLIqd0D5)object;
        if (this.Field15143.equals(dsGGdHDauaEpIGTENBJZHKgBhLIqd0D52.Field15143) && this.Field15144.equals(dsGGdHDauaEpIGTENBJZHKgBhLIqd0D52.Field15144)) {
            n = (int)1287819000L ^ 0x4CC28EF9;
            return n != 0;
        }
        n = (int)((long)1422780502 ^ (long)1422780502);
        return n != 0;
    }
}

