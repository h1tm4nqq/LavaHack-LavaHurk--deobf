/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 *  net.minecraft.util.math.BlockPos
 */
package lavahack.client;

import lavahack.client.u5CRioThdnglBh9lVJeSNzNoUAZImAg0;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;

public class ASuMcgM5AEARMUacGCCzRjLlcqrqV9ji
extends u5CRioThdnglBh9lVJeSNzNoUAZImAg0 {
    public boolean Field16228;
    public Item Field16229;
    private String Field16230 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public ASuMcgM5AEARMUacGCCzRjLlcqrqV9ji(BlockPos blockPos, Item item) {
        super(blockPos);
        this.Field16229 = item;
    }
}

