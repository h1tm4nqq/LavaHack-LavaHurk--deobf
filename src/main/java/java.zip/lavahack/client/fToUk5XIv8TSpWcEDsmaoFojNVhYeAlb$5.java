/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import lavahack.client.fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb;
import lavahack.client.paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF;

class fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb$5
implements ActionListener {
    final paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF Field13207;
    final fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb Field13208;
    private String Field13209 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb$5(fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb2, paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF2) {
        this.Field13208 = fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb2;
        this.Field13207 = paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF2;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        this.Field13207.Method5027();
    }
}

