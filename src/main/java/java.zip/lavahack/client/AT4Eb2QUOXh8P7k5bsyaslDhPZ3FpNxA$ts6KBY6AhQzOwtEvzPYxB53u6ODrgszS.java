/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;

class AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS {
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field14056;
    private String Field14057 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    private AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS() {
    }

    static hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method5351() {
        return Field14056;
    }

    static {
        Class[] classArray = new Class[(int)((long)840727120 ^ (long)840727121) << 1];
        classArray[(int)((long)-535220320 ^ (long)-535220320)] = Integer.class;
        classArray[(int)((long)357900994 ^ (long)357900995)] = Boolean.class;
        Field14056 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, classArray);
    }
}

