/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;
import lavahack.client.Fzym2ppH3Dp5NmKdHeQc0MJ44rHAejrG;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=3)
public final class APtPrB112pn7h48gEC65Bh3MdL3vmTuU {
    public static final int[] Field12044 = new int[Fzym2ppH3Dp5NmKdHeQc0MJ44rHAejrG.values().length];
    private String Field12045 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        APtPrB112pn7h48gEC65Bh3MdL3vmTuU.Field12044[Fzym2ppH3Dp5NmKdHeQc0MJ44rHAejrG.Field12640.ordinal()] = (int)-117470411L ^ 0xF8FF8B34;
        APtPrB112pn7h48gEC65Bh3MdL3vmTuU.Field12044[Fzym2ppH3Dp5NmKdHeQc0MJ44rHAejrG.Field12641.ordinal()] = ((int)-1060923915L ^ 0xC0C395F4) << 1;
    }
}

