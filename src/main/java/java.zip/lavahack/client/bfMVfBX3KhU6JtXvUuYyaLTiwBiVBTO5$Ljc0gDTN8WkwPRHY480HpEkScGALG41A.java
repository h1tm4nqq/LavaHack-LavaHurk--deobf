/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5;
import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

public class bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$Ljc0gDTN8WkwPRHY480HpEkScGALG41A
extends bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5 {
    private String Field8389 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$Ljc0gDTN8WkwPRHY480HpEkScGALG41A(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2) {
        super(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.Field12932, bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field11531);
    }
}

