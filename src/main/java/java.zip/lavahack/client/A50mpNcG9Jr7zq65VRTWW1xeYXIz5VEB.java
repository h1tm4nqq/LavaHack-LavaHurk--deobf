/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ServerData
 */
package lavahack.client;

import com.kisman.cc.event.Event;
import net.minecraft.client.multiplayer.ServerData;

public class A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB
extends Event {
    private final ServerData Field16203;
    private String Field16204 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB(ServerData serverData) {
        super(new Object[(int)1802159274L ^ 0x6B6AC4AA]);
        this.Field16203 = serverData;
    }

    public ServerData Method2533() {
        return this.Field16203;
    }
}

