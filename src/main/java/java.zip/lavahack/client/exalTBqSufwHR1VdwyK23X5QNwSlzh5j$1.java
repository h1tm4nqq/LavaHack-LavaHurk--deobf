/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 */
package lavahack.client;

import net.minecraft.util.EnumFacing;

class exalTBqSufwHR1VdwyK23X5QNwSlzh5j$1 {
    static final int[] Field17010 = new int[EnumFacing.values().length];
    private String Field17011 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        exalTBqSufwHR1VdwyK23X5QNwSlzh5j$1.Field17010[EnumFacing.UP.ordinal()] = (int)408839324L ^ 0x185E649D;
        exalTBqSufwHR1VdwyK23X5QNwSlzh5j$1.Field17010[EnumFacing.DOWN.ordinal()] = (int)((long)-2130824914 ^ (long)-2130824913) << 1;
        exalTBqSufwHR1VdwyK23X5QNwSlzh5j$1.Field17010[EnumFacing.NORTH.ordinal()] = (int)((long)-59008371 ^ (long)-59008370);
        exalTBqSufwHR1VdwyK23X5QNwSlzh5j$1.Field17010[EnumFacing.EAST.ordinal()] = ((int)1830891706L ^ 0x6D2130BB) << 2;
        exalTBqSufwHR1VdwyK23X5QNwSlzh5j$1.Field17010[EnumFacing.SOUTH.ordinal()] = (int)((long)745648266 ^ (long)745648271);
        exalTBqSufwHR1VdwyK23X5QNwSlzh5j$1.Field17010[EnumFacing.WEST.ordinal()] = (int)((long)-805816513 ^ (long)-805816516) << 1;
    }
}

