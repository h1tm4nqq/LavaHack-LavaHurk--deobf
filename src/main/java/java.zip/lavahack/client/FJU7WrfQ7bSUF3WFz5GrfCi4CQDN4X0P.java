/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P$1;
import lavahack.client.FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P$2;
import lavahack.client.PvteZBChsPEgLHGF5q9aE49MYRREwvMT;
import lavahack.client.T8i6BphJTXvvM16fH7WT5rIvM5EGB9Zr;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000j\u0002\b\tj\u0002\b\n\u00a8\u0006\u000b"}, d2={"Lcom/kisman/cc/util/enums/PhaseModes;", "", "handler", "Lcom/kisman/cc/util/enums/IPhaseMode;", "(Ljava/lang/String;ILcom/kisman/cc/util/enums/IPhaseMode;)V", "update", "", "phase", "Lcom/kisman/cc/features/module/movement/Phase;", "Pearl", "PearlBypass", "kisman.cc"})
public final class FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P
extends Enum {
    public static final /* enum */ FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P Field10019;
    public static final /* enum */ FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P Field10020;
    private static final FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P[] Field10021;
    private final PvteZBChsPEgLHGF5q9aE49MYRREwvMT Field10022;
    private String Field10023 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P[] fJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0PArray = new FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P[((int)355055138L ^ 0x1529B623) << 1];
        FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P[] fJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0PArray2 = fJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0PArray;
        fJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0PArray[(int)((long)878920794 ^ (long)878920794)] = Field10019 = new FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P("Pearl", (int)((long)230580132 ^ (long)230580132), (PvteZBChsPEgLHGF5q9aE49MYRREwvMT)new FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P$1());
        fJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0PArray[(int)1986729644L ^ 0x766B16AD] = Field10020 = new FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P("PearlBypass", (int)756487062L ^ 0x2D171397, (PvteZBChsPEgLHGF5q9aE49MYRREwvMT)new FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P$2());
        Field10021 = fJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0PArray;
    }

    public final void Method2245(@NotNull @NotNull T8i6BphJTXvvM16fH7WT5rIvM5EGB9Zr t8i6BphJTXvvM16fH7WT5rIvM5EGB9Zr) {
        Intrinsics.checkParameterIsNotNull((Object)t8i6BphJTXvvM16fH7WT5rIvM5EGB9Zr, (String)"phase");
        this.Field10022.Method2773(t8i6BphJTXvvM16fH7WT5rIvM5EGB9Zr);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P() {
        void var3_1;
        void var2_-1;
        void var1_-1;
        this.Field10022 = var3_1;
    }

    public static FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P[] values() {
        return (FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P[])Field10021.clone();
    }

    public static FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P valueOf(String string) {
        return Enum.valueOf(FJU7WrfQ7bSUF3WFz5GrfCi4CQDN4X0P.class, string);
    }

    private static String Method2246(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)-1063747582L ^ 0xC0988002;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-1100641554L ^ 0xBE658A11);
            int n2 = (int)((long)-1515711156 ^ (long)-1515711155) << 4;
            cArray2[n] = (char)(cArray[n] ^ ((int)449462389L ^ 0x1ACA740A ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

