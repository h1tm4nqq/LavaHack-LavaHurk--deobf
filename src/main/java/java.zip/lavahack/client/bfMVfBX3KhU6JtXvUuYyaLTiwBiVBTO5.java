/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import com.kisman.cc.event.Event;
import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

public class bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5
extends Event {
    public qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field9851;
    public bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi Field9852;
    public bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field9853;
    private String Field9854 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi, bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi) {
        super(new Object[(int)413671751L ^ 0x18A82147]);
        this.Field9851 = qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2;
        this.Field9852 = bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi;
        this.Field9853 = bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
    }
}

