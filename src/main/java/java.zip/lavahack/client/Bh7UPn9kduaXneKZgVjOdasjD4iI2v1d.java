/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.OXnmHkicoKSXO07qPVZZlEOZLMS63HK3;
import lavahack.client.PlexElxneO8yJrjYrpdC3UIsltSpVGba;
import lavahack.client.VKBZXvQOFrziN0pExmLPOVv8CIcXCELf;
import lavahack.client.VKswaMs8Qxm0K4Sninx8F7JXZylB2itm;
import lavahack.client.VPBYw2VGdK2kwLwoTSMmMQSEpO5xmUmc;
import lavahack.client.X1yA7NU2CPgCvjCJwrfBEcvyASGzVWbj;
import lavahack.client.mHSBObrtWzin96tJsUtbVAD85n5BPNKC;
import lavahack.client.mjHNsPE7kHLCCsmNM6Uuc1TituSJGAOt;
import org.objectweb.asm.tree.ClassNode;

public class Bh7UPn9kduaXneKZgVjOdasjD4iI2v1d {
    private final VKswaMs8Qxm0K4Sninx8F7JXZylB2itm[] Field14291 = new VKswaMs8Qxm0K4Sninx8F7JXZylB2itm[(int)((long)783110433 ^ (long)783110436)];
    private String Field14292 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public Bh7UPn9kduaXneKZgVjOdasjD4iI2v1d() {
        this.Field14291[(int)2137568794L ^ 0x7F68B61A] = new VPBYw2VGdK2kwLwoTSMmMQSEpO5xmUmc();
        this.Field14291[(int)-1976830578L ^ 0x8A2BF58F] = new PlexElxneO8yJrjYrpdC3UIsltSpVGba();
        this.Field14291[(int)((long)964833379 ^ (long)964833378) << 1] = new mjHNsPE7kHLCCsmNM6Uuc1TituSJGAOt();
        this.Field14291[(int)-194656325L ^ 0xF465C7B8] = new X1yA7NU2CPgCvjCJwrfBEcvyASGzVWbj();
        this.Field14291[((int)1143195327L ^ 0x4423C6BE) << 2] = new mHSBObrtWzin96tJsUtbVAD85n5BPNKC();
    }

    public byte[] Method5495(byte[] byArray, OXnmHkicoKSXO07qPVZZlEOZLMS63HK3 oXnmHkicoKSXO07qPVZZlEOZLMS63HK3) {
        ClassNode classNode = VKBZXvQOFrziN0pExmLPOVv8CIcXCELf.Method5516(byArray, new int[(int)-1563932611L ^ 0xA2C8483D]);
        VKswaMs8Qxm0K4Sninx8F7JXZylB2itm[] vKswaMs8Qxm0K4Sninx8F7JXZylB2itmArray = this.Field14291;
        int n = vKswaMs8Qxm0K4Sninx8F7JXZylB2itmArray.length;
        int n2 = (int)-1786769334L ^ 0x9580104A;
        while (n2 < n) {
            VKswaMs8Qxm0K4Sninx8F7JXZylB2itm vKswaMs8Qxm0K4Sninx8F7JXZylB2itm = vKswaMs8Qxm0K4Sninx8F7JXZylB2itmArray[n2];
            vKswaMs8Qxm0K4Sninx8F7JXZylB2itm.Method193(classNode, oXnmHkicoKSXO07qPVZZlEOZLMS63HK3);
            ++n2;
        }
        return VKBZXvQOFrziN0pExmLPOVv8CIcXCELf.Method5517(classNode, new int[(int)((long)-1860935177 ^ (long)-1860935177)]);
    }
}

