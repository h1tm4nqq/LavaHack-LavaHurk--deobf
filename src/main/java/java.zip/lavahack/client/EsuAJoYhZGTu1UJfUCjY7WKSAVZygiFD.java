/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.DRYM3f1zoD6FgG1OtQzVQOOmQysudi50;
import lavahack.client.ruoGkcTnw0k9gX6fMoZEvqaaVBSDLyov;

public class EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD {
    public static final double Field17785 = 0.0;
    public double Field17786;
    public double Field17787;
    private String Field17788 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD() {
        this(0.0, 0.0);
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD) {
        this(esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17786, esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17787);
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD(double d) {
        this(d, d);
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD(double d, double d2) {
        this.Field17786 = d;
        this.Field17787 = d2;
    }

    public final double Method5819() {
        return this.Field17786;
    }

    public final double Method5820() {
        return this.Field17787;
    }

    public final void Method5821(double d) {
        this.Field17786 = d;
    }

    public final void Method5822(double d) {
        this.Field17787 = d;
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5823(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD) {
        return this.Method5824(esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17786, esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17787);
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5824(double d, double d2) {
        this.Field17786 = d;
        this.Field17787 = d2;
        return this;
    }

    public final double Method5825() {
        return Math.sqrt(this.Method5826());
    }

    public double Method5826() {
        return this.Field17786 * this.Field17786 + this.Field17787 * this.Field17787;
    }

    public final double Method5827(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD) {
        return Math.sqrt(this.Method5828(esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD));
    }

    public double Method5828(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD) {
        return this.Method5829(this.Field17786 - esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17786) + this.Method5829(this.Field17787 - esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17787);
    }

    protected final double Method5829(double d) {
        return d * d;
    }

    public final EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5830() {
        double d = this.Method5825();
        if (d == 0.0) return this;
        return this.Method5833(1.0 / d);
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5831() {
        this.Field17786 = -this.Field17786;
        this.Field17787 = -this.Field17787;
        return this;
    }

    public double Method5832(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD) {
        return this.Field17786 * esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17786 + this.Field17787 * esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17787;
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5833(double d) {
        this.Field17786 *= d;
        this.Field17787 *= d;
        return this;
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5834(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD) {
        this.Field17786 += esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17786;
        this.Field17787 += esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17787;
        return this;
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5835(double d, double d2) {
        this.Field17786 += d;
        this.Field17787 += d2;
        return this;
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5836(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD) {
        this.Field17786 -= esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17786;
        this.Field17787 -= esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17787;
        return this;
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5837(double d, double d2) {
        this.Field17786 -= d;
        this.Field17787 -= d2;
        return this;
    }

    public DRYM3f1zoD6FgG1OtQzVQOOmQysudi50 Method5838() {
        return new DRYM3f1zoD6FgG1OtQzVQOOmQysudi50((int)Math.floor(this.Field17786), (int)Math.floor(this.Field17787));
    }

    public DRYM3f1zoD6FgG1OtQzVQOOmQysudi50 Method5839(DRYM3f1zoD6FgG1OtQzVQOOmQysudi50 dRYM3f1zoD6FgG1OtQzVQOOmQysudi50) {
        return dRYM3f1zoD6FgG1OtQzVQOOmQysudi50.Method1008((int)Math.floor(this.Field17786), (int)Math.floor(this.Field17787));
    }

    public ruoGkcTnw0k9gX6fMoZEvqaaVBSDLyov Method5840() {
        return new ruoGkcTnw0k9gX6fMoZEvqaaVBSDLyov((float)Math.floor(this.Field17786), (float)Math.floor(this.Field17787));
    }

    public ruoGkcTnw0k9gX6fMoZEvqaaVBSDLyov Method5841(ruoGkcTnw0k9gX6fMoZEvqaaVBSDLyov ruoGkcTnw0k9gX6fMoZEvqaaVBSDLyov2) {
        return ruoGkcTnw0k9gX6fMoZEvqaaVBSDLyov2.Method3494((float)Math.floor(this.Field17786), (float)Math.floor(this.Field17787));
    }

    public EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD Method5842() {
        return new EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD(this);
    }

    public boolean equals(Object object) {
        int n;
        if (object instanceof EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD && this.Method5843((EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD)object)) {
            n = (int)762742056L ^ 0x2D768529;
            return n != 0;
        }
        n = (int)1955317251L ^ 0x748BC603;
        return n != 0;
    }

    public boolean Method5843(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD) {
        return this.Method5844(esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD, Double.longBitsToDouble((long)1372050612 ^ 0x3EE4F8B5D1C7D4B4L));
    }

    public boolean Method5844(EsuAJoYhZGTu1UJfUCjY7WKSAVZygiFD esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD, double d) {
        int n;
        if (Math.abs(this.Field17786 - esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17786) < d && Math.abs(this.Field17787 - esuAJoYhZGTu1UJfUCjY7WKSAVZygiFD.Field17787) < d) {
            n = (int)381555355L ^ 0x16BE129A;
            return n != 0;
        }
        n = (int)1363534453L ^ 0x5145E275;
        return n != 0;
    }

    public String toString() {
        Object[] objectArray = new Object[((int)1788838530L ^ 0x6A9F8283) << 1];
        objectArray[(int)((long)1756427695 ^ (long)1756427695)] = this.Field17786;
        objectArray[(int)-1361439886L ^ 0xAEDA1373] = this.Field17787;
        return String.format("[%s, %s]", objectArray);
    }

    public Object clone() throws CloneNotSupportedException {
        return this.Method5842();
    }

    private static String Method5845(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)-507749662L ^ 0xE1BC5AE2;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)1118355538L ^ 0x42A8C0AD);
            int n2 = (int)1302395194L ^ 0x4DA0F9BD;
            cArray2[n] = (char)(cArray[n] ^ ((int)-13123733L ^ 0xFF37FD14 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

