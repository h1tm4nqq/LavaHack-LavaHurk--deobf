/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.GT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8;
import lavahack.client.UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u00002\u00020\u0001B\u001f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bB'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n\u00a2\u0006\u0002\u0010\u000bR\u0013\u0010\t\u001a\u0004\u0018\u00010\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013\u00a8\u0006\u0014"}, d2={"Lcom/kisman/cc/settings/CharmsRewriteSetting;", "", "setting", "Lcom/kisman/cc/settings/Setting;", "typeE", "Lcom/kisman/cc/util/enums/CharmsRewriteEntityTypes;", "typeS", "Lcom/kisman/cc/util/enums/CharmsRewriteTypes;", "(Lcom/kisman/cc/settings/Setting;Lcom/kisman/cc/util/enums/CharmsRewriteEntityTypes;Lcom/kisman/cc/util/enums/CharmsRewriteTypes;)V", "option", "Lcom/kisman/cc/util/enums/dynamic/CharmsRewriteOptionsEnum$CharmsRewriteOptions;", "(Lcom/kisman/cc/settings/Setting;Lcom/kisman/cc/util/enums/CharmsRewriteEntityTypes;Lcom/kisman/cc/util/enums/CharmsRewriteTypes;Lcom/kisman/cc/util/enums/dynamic/CharmsRewriteOptionsEnum$CharmsRewriteOptions;)V", "getOption", "()Lcom/kisman/cc/util/enums/dynamic/CharmsRewriteOptionsEnum$CharmsRewriteOptions;", "getSetting", "()Lcom/kisman/cc/settings/Setting;", "getTypeE", "()Lcom/kisman/cc/util/enums/CharmsRewriteEntityTypes;", "getTypeS", "()Lcom/kisman/cc/util/enums/CharmsRewriteTypes;", "kisman.cc"})
public final class bjipKPiJHHAGRmSIHIAczNHDJY0Pkg3O {
    @NotNull
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field15402;
    @NotNull
    private final GT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8 Field15403;
    @NotNull
    private final UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp Field15404;
    @Nullable
    private final a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field15405;
    private String Field15406 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    @NotNull
    @NotNull
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Method6219() {
        return this.Field15402;
    }

    @NotNull
    @NotNull
    public final GT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8 Method6220() {
        return this.Field15403;
    }

    @NotNull
    @NotNull
    public final UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp Method6221() {
        return this.Field15404;
    }

    @Nullable
    @Nullable
    public final a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Method6222() {
        return this.Field15405;
    }

    public bjipKPiJHHAGRmSIHIAczNHDJY0Pkg3O(@NotNull @NotNull qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, @NotNull @NotNull GT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8 gT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8, @NotNull @NotNull UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp, @Nullable @Nullable a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi) {
        Intrinsics.checkParameterIsNotNull((Object)qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, (String)"setting");
        Intrinsics.checkParameterIsNotNull((Object)((Object)gT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8), (String)"typeE");
        Intrinsics.checkParameterIsNotNull((Object)((Object)uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp), (String)"typeS");
        this.Field15402 = qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2;
        this.Field15403 = gT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8;
        this.Field15404 = uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp;
        this.Field15405 = a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
    }

    public bjipKPiJHHAGRmSIHIAczNHDJY0Pkg3O(@NotNull @NotNull qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, @NotNull @NotNull GT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8 gT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8, @NotNull @NotNull UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp) {
        Intrinsics.checkParameterIsNotNull((Object)qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, (String)"setting");
        Intrinsics.checkParameterIsNotNull((Object)((Object)gT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8), (String)"typeE");
        Intrinsics.checkParameterIsNotNull((Object)((Object)uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp), (String)"typeS");
        this(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, gT4VSMfcgSw6eOCykWZkqGRUp1KIwpI8, uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp, null);
    }

    private static String Method6223(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-1251671897 ^ (long)-1251671897);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)-1025806566 ^ (long)-1025806363);
            int n2 = (int)((long)-714679787 ^ (long)-714679672);
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)-900943455 ^ (long)-900943466) ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

