/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

public class bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf
extends bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5 {
    private String Field13400 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2) {
        super(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, null, null);
    }
}

