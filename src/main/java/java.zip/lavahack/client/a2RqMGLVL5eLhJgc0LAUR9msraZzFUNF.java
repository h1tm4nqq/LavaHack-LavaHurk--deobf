//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.Minecraft
 *  net.minecraft.util.math.BlockPos
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.Fzym2ppH3Dp5NmKdHeQc0MJ44rHAejrG;
import lavahack.client.JfOy1lP2UqL88yBXCMNp0lo8w80UjXTU;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\u0018\u0000 \u00032\u00020\u0001:\u0002\u0003\u0004B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0005"}, d2={"Lcom/kisman/cc/util/enums/dynamic/RotationEnum;", "", "()V", "Companion", "Rotation", "kisman.cc"})
public final class a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF {
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field14070;
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field14071;
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field14072;
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field14073;
    private static final Minecraft Field14074;
    public static final a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field14075;
    private int Field14076;

    static {
        Field14075 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(null);
        Class[] classArray = new Class[(int)((long)118863778 ^ (long)118863779) << 1];
        classArray[(int)-18681315L ^ 0xFEE2F21D] = float[].class;
        classArray[(int)((long)-1062669731 ^ (long)-1062669732)] = Boolean.class;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, classArray);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf, (String)"AbstractTask.types(\n    \u2026ss.java//Silent\n        )");
        Field14070 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
        Class[] classArray2 = new Class[(int)((long)898526633 ^ (long)898526632) << 1];
        classArray2[(int)-338160019L ^ 0xEBD8166D] = JfOy1lP2UqL88yBXCMNp0lo8w80UjXTU.class;
        classArray2[(int)((long)-1704510573 ^ (long)-1704510574)] = Boolean.class;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf2 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, classArray2);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf2, (String)"AbstractTask.types(\n    \u2026ss.java//Silent\n        )");
        Field14071 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf2;
        Class[] classArray3 = new Class[(int)((long)-706935743 ^ (long)-706935744) << 1];
        classArray3[(int)((long)-743527352 ^ (long)-743527352)] = Integer.class;
        classArray3[(int)((long)623375935 ^ (long)623375934)] = Fzym2ppH3Dp5NmKdHeQc0MJ44rHAejrG.class;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf3 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(float[].class, classArray3);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf3, (String)"AbstractTask.types(\n    \u2026/Rotation logic\n        )");
        Field14072 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf3;
        Class[] classArray4 = new Class[(int)2028236404L ^ 0x78E46E75];
        classArray4[(int)-908283029L ^ 0xC9DCB36B] = BlockPos.class;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf4 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(float[].class, classArray4);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf4, (String)"AbstractTask.types(\n    \u2026ass.java//block\n        )");
        Field14073 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf4;
        Field14074 = Minecraft.getMinecraft();
    }

    public static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method5363() {
        return Field14070;
    }

    public static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method5364() {
        return Field14071;
    }

    public static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method5365() {
        return Field14072;
    }

    public static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method5366() {
        return Field14073;
    }

    public static final Minecraft Method5367() {
        return Field14074;
    }

    private static String Method5368(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-1042067899 ^ (long)-1042067899);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-981075574L ^ 0xC585F975);
            int n2 = (int)-1424807442L ^ 0xAB132927;
            cArray2[n] = (char)(cArray[n] ^ ((int)962093830L ^ 0x39580685 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

