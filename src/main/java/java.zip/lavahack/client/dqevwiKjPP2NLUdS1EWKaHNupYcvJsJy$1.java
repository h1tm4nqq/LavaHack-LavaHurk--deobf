/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 */
package lavahack.client;

import net.minecraft.util.EnumFacing;

class dqevwiKjPP2NLUdS1EWKaHNupYcvJsJy$1 {
    static final int[] Field10886 = new int[EnumFacing.values().length];
    private String Field10887 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        dqevwiKjPP2NLUdS1EWKaHNupYcvJsJy$1.Field10886[EnumFacing.NORTH.ordinal()] = (int)666799138L ^ 0x27BE8C23;
        dqevwiKjPP2NLUdS1EWKaHNupYcvJsJy$1.Field10886[EnumFacing.EAST.ordinal()] = (int)((long)1443509902 ^ (long)1443509903) << 1;
        dqevwiKjPP2NLUdS1EWKaHNupYcvJsJy$1.Field10886[EnumFacing.SOUTH.ordinal()] = (int)-1473984692L ^ 0xA824C74F;
        dqevwiKjPP2NLUdS1EWKaHNupYcvJsJy$1.Field10886[EnumFacing.WEST.ordinal()] = ((int)-494974960L ^ 0xE27F4811) << 2;
    }
}

