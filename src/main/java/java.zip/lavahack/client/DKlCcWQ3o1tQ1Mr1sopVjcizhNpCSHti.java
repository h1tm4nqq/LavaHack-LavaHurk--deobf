/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import java.util.ArrayDeque;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=2, d1={"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0017\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004\u00a8\u0006\u0005"}, d2={"processes", "Ljava/util/ArrayDeque;", "Ljava/lang/Runnable;", "getProcesses", "()Ljava/util/ArrayDeque;", "kisman.cc"})
public final class DKlCcWQ3o1tQ1Mr1sopVjcizhNpCSHti {
    @NotNull
    private static final ArrayDeque Field8959 = new ArrayDeque();
    private String Field8960 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    @NotNull
    @NotNull
    public static final ArrayDeque Method1271() {
        return Field8959;
    }
}

