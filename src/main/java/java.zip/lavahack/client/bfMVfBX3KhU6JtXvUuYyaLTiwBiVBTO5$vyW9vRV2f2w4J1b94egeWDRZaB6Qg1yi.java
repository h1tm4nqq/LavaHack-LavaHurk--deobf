/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public final class bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi
extends Enum {
    public static final /* enum */ bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi Field12932 = new bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi("Boolean", (int)((long)-1677887825 ^ (long)-1677887825));
    public static final /* enum */ bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi Field12933 = new bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi("Mode", (int)((long)1911196022 ^ (long)1911196023));
    public static final /* enum */ bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi Field12934 = new bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi("Color", (int)((long)-190021494 ^ (long)-190021493) << 1);
    public static final /* enum */ bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi Field12935 = new bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi("Number", (int)36846760L ^ 0x2323CAB);
    private static final bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi[] Field12936;
    private String Field12937 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public static bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi[] values() {
        return (bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi[])Field12936.clone();
    }

    public static bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi valueOf(String string) {
        return Enum.valueOf(bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.class, string);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi() {
        void var2_-1;
        void var1_-1;
    }

    static {
        bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi[] bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yiArray = new bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi[(int)((long)-81086988 ^ (long)-81086987) << 2];
        bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yiArray[(int)((long)1899118430 ^ (long)1899118430)] = Field12932;
        bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yiArray[(int)((long)793100890 ^ (long)793100891)] = Field12933;
        bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yiArray[((int)420467152L ^ 0x190FD1D1) << 1] = Field12934;
        bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yiArray[(int)-405848901L ^ 0xE7CF3CB8] = Field12935;
        Field12936 = bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yiArray;
    }

    private static String Method4486(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)2091788542 ^ (long)2091788542);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)1600401020L ^ 0x5F642E83);
            int n2 = (int)((long)1784694228 ^ (long)1784694251) << 1;
            cArray2[n] = (char)(cArray[n] ^ (((int)-1335820636L ^ 0xB060F3D9) << 3 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

