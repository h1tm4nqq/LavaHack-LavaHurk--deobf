/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import com.kisman.cc.event.Event;

public class DsAaAHmL7Yq0IkjnWsKfUDurp0luEZxB
extends Event {
    private String Field17338 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public DsAaAHmL7Yq0IkjnWsKfUDurp0luEZxB() {
        super(new Object[(int)-1020003906L ^ 0xC333F9BE]);
    }
}

