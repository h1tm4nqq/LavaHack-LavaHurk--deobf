/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public class bNzPAby7ejbT9nCckVXJRyiVLV4qRBhE {
    public double Field11662;
    public double Field11663;
    private String Field11664 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public bNzPAby7ejbT9nCckVXJRyiVLV4qRBhE(double d, double d2) {
        this.Field11662 = d;
        this.Field11663 = d2;
    }
}

