/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.GnakMUPs8Y6dOYDRxYeXWX0dk0PiYXm7;
import lavahack.client.ItlMspXe4sYKo9sO7veaMUQwviMUhYJh;
import lavahack.client.M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk;
import lavahack.client.WjjBVRrUqJUKhloA7ANknrTEODhuGa0J;
import lavahack.client.exalTBqSufwHR1VdwyK23X5QNwSlzh5j;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;
import lavahack.client.xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl;
import lavahack.client.yA6FfBWveAENft82JRISn3FwZ8fifzBI$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import lavahack.client.yA6FfBWveAENft82JRISn3FwZ8fifzBI$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\b\u0010\u000e\u001a\u00020\u0000H\u0016J\u0016\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u0013J\u0016\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0012\u001a\u00020\u0013J\u000e\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0013J\b\u0010\u0018\u001a\u00020\u0000H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\r0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0019"}, d2={"Lcom/kisman/cc/settings/util/EasingsPattern;", "Lcom/kisman/cc/settings/util/AbstractPattern;", "module", "Lcom/kisman/cc/features/module/Module;", "(Lcom/kisman/cc/features/module/Module;)V", "group_", "Lcom/kisman/cc/settings/types/SettingGroup;", "mode", "Lcom/kisman/cc/settings/Setting;", "normalMode", "Lcom/kisman/cc/settings/types/SettingEnum;", "Lcom/kisman/cc/util/enums/dynamic/EasingEnum$Easing;", "reverseMode", "Lcom/kisman/cc/util/enums/dynamic/EasingEnum$EasingReverse;", "init", "mutateBB", "Lnet/minecraft/util/math/AxisAlignedBB;", "bb", "progress", "", "mutateBlockBB", "pos", "Lnet/minecraft/util/math/BlockPos;", "mutateProgress", "preInit", "kisman.cc"})
public final class bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC
extends GnakMUPs8Y6dOYDRxYeXWX0dk0PiYXm7 {
    private final xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl Field9033;
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field9034;
    private final M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk Field9035;
    private final M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk Field9036;
    private String Field9037 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    @NotNull
    @NotNull
    public bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC Method1307() {
        if (this.Method769() == null) return this;
        xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl2 = this.Method769();
        if (xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl2 == null) return this;
        xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl2.Method7406(this.Field9033);
        return this;
    }

    @Override
    public Object Method778() {
        return this.Method1307();
    }

    @NotNull
    @NotNull
    public bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC Method1308() {
        this.Method780().Method24(this.Field9033);
        this.Method780().Method23(this.Field9034);
        this.Method780().Method25(this.Field9035);
        this.Method780().Method25(this.Field9036);
        return this;
    }

    @Override
    public Object Method779() {
        return this.Method1308();
    }

    public final double Method1309(double d) {
        double d2;
        if (this.Field9034.Method341() == ItlMspXe4sYKo9sO7veaMUQwviMUhYJh.Field9762) {
            Object[] objectArray = new Object[(int)((long)-45085734 ^ (long)-45085733)];
            objectArray[(int)35606360L ^ 0x21F4F58] = d;
            Object object = ((yA6FfBWveAENft82JRISn3FwZ8fifzBI$leqS0IyKEB621E1SrHdAcHHAUjScjmKi)this.Field9035.Method341()).Method849().Method1726(objectArray);
            Intrinsics.checkExpressionValueIsNotNull((Object)object, (String)"normalMode.valEnum.task.doTask(progress)");
            d2 = ((Number)object).doubleValue();
            return d2;
        }
        Object[] objectArray = new Object[(int)((long)-1616480594 ^ (long)-1616480593)];
        objectArray[(int)((long)-2057763789 ^ (long)-2057763789)] = d;
        Object object = ((yA6FfBWveAENft82JRISn3FwZ8fifzBI$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf)this.Field9036.Method341()).Method849().Method1726(objectArray);
        Intrinsics.checkExpressionValueIsNotNull((Object)object, (String)"reverseMode.valEnum.task.doTask(progress)");
        d2 = ((Number)object).doubleValue();
        return d2;
    }

    @NotNull
    @NotNull
    public final AxisAlignedBB Method1310(@NotNull @NotNull AxisAlignedBB axisAlignedBB, double d) {
        Intrinsics.checkParameterIsNotNull((Object)axisAlignedBB, (String)"bb");
        AxisAlignedBB axisAlignedBB2 = exalTBqSufwHR1VdwyK23X5QNwSlzh5j.Method3450(axisAlignedBB, this.Method1309(d));
        Intrinsics.checkExpressionValueIsNotNull((Object)axisAlignedBB2, (String)"Rendering.scale(bb, mutateProgress(progress))");
        return axisAlignedBB2;
    }

    @NotNull
    @NotNull
    public final AxisAlignedBB Method1311(@NotNull @NotNull BlockPos blockPos, double d) {
        Intrinsics.checkParameterIsNotNull((Object)blockPos, (String)"pos");
        AxisAlignedBB axisAlignedBB = exalTBqSufwHR1VdwyK23X5QNwSlzh5j.Method3449(blockPos, this.Method1309(d));
        Intrinsics.checkExpressionValueIsNotNull((Object)axisAlignedBB, (String)"Rendering.scale(pos, mutateProgress(progress))");
        return axisAlignedBB;
    }

    public bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC(@NotNull @NotNull WjjBVRrUqJUKhloA7ANknrTEODhuGa0J wjjBVRrUqJUKhloA7ANknrTEODhuGa0J) {
        M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk;
        Intrinsics.checkParameterIsNotNull((Object)wjjBVRrUqJUKhloA7ANknrTEODhuGa0J, (String)"module");
        super(wjjBVRrUqJUKhloA7ANknrTEODhuGa0J);
        this.Field9033 = this.Method776(new xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Easing", wjjBVRrUqJUKhloA7ANknrTEODhuGa0J)));
        this.Field9034 = this.Field9033.Method7405(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Easing Mode", wjjBVRrUqJUKhloA7ANknrTEODhuGa0J, ItlMspXe4sYKo9sO7veaMUQwviMUhYJh.Field9762));
        M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk2 = new M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk("Easing Normal Mode", wjjBVRrUqJUKhloA7ANknrTEODhuGa0J, yA6FfBWveAENft82JRISn3FwZ8fifzBI$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field8814).Method5300("Normal");
        bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC2 = this;
        int n = (int)1718321380L ^ 0x666B80E4;
        int n2 = (int)-80052624L ^ 0xFB3A7E70;
        M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk3 = m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk2;
        int n3 = (int)((long)-1154970967 ^ (long)-1154970967);
        this.Method774(m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk3);
        this.Field9033.Method7407(m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk3);
        bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC2.Field9035 = m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk = m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk2;
        m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk2 = new M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk("Easing Reverse Mode", wjjBVRrUqJUKhloA7ANknrTEODhuGa0J, yA6FfBWveAENft82JRISn3FwZ8fifzBI$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field12478).Method5300("Reverse");
        bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC2 = this;
        n = (int)((long)334134590 ^ (long)334134590);
        n2 = (int)887775729L ^ 0x34EA61F1;
        m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk3 = m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk2;
        n3 = (int)((long)822147065 ^ (long)822147065);
        this.Method774(m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk3);
        this.Field9033.Method7407(m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk3);
        bAaIh3bYHxH7ANifZFFb4hVRX7sKeeUC2.Field9036 = m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk = m5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk2;
    }

    private static String Method781(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)1997727557 ^ (long)1997727557);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-570763067L ^ 0xDDFAD83A);
            int n2 = ((int)-2077463786L ^ 0x842C6B37) << 1;
            cArray2[n] = (char)(cArray[n] ^ (((int)-833840423L ^ 0xCE4C8694) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

