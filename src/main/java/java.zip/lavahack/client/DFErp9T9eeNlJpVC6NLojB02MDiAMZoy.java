/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;

public interface DFErp9T9eeNlJpVC6NLojB02MDiAMZoy
extends ByteChannel {
    public boolean Method2482();

    public void Method2483() throws IOException;

    public boolean Method2484();

    public int Method2485(ByteBuffer var1) throws IOException;

    public boolean Method2486();
}

