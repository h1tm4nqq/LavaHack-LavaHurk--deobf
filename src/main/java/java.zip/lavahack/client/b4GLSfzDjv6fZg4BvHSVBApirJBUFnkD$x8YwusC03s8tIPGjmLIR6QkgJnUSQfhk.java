/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public class b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$x8YwusC03s8tIPGjmLIR6QkgJnUSQfhk
implements Runnable {
    public static b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$x8YwusC03s8tIPGjmLIR6QkgJnUSQfhk Field12954 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$x8YwusC03s8tIPGjmLIR6QkgJnUSQfhk();
    private String Field12955 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    private b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$x8YwusC03s8tIPGjmLIR6QkgJnUSQfhk() {
    }

    @Override
    public void run() {
    }
}

