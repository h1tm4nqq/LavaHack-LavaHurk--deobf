/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public interface a5tJYuzaFW84Fvomx2rUBagDbe2NbMmD {
    public void Method158();

    public boolean Method159();
}

