/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$1;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$10;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$11;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$12;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$13;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$14;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$15;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$16;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$17;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$18;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$19;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$2;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$20;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$21;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$3;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$4;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$5;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$6;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$7;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$8;
import lavahack.client.a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$9;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0011\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001BO\b\u0002\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u00a2\u0006\u0002\u0010\u000bR\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\rR\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\rR\u0011\u0010\n\u001a\u00020\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\b\u001a\u00020\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018j\u0002\b\u0019\u00a8\u0006\u001a"}, d2={"Lcom/kisman/cc/util/enums/dynamic/CharmsRewriteOptionsEnum$CharmsRewriteOptions;", "", "beginIfTrue", "Lorg/cubic/dynamictask/AbstractTask;", "Ljava/lang/Void;", "beginIfFalse", "afterIfTrue", "afterIfFalse", "typeW", "Lcom/kisman/cc/util/enums/CharmsRewriteTypes;", "typeM", "(Ljava/lang/String;ILorg/cubic/dynamictask/AbstractTask;Lorg/cubic/dynamictask/AbstractTask;Lorg/cubic/dynamictask/AbstractTask;Lorg/cubic/dynamictask/AbstractTask;Lcom/kisman/cc/util/enums/CharmsRewriteTypes;Lcom/kisman/cc/util/enums/CharmsRewriteTypes;)V", "getAfterIfFalse", "()Lorg/cubic/dynamictask/AbstractTask;", "getAfterIfTrue", "getBeginIfFalse", "getBeginIfTrue", "getTypeM", "()Lcom/kisman/cc/util/enums/CharmsRewriteTypes;", "getTypeW", "Depth", "Lighting", "Culling", "Blend", "Translucent", "Texture2D", "kisman.cc"})
public final class a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends Enum {
    public static final /* enum */ a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field9509;
    public static final /* enum */ a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field9510;
    public static final /* enum */ a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field9511;
    public static final /* enum */ a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field9512;
    public static final /* enum */ a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field9513;
    public static final /* enum */ a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field9514;
    private static final a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] Field9515;
    @NotNull
    private final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field9516;
    @NotNull
    private final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field9517;
    @NotNull
    private final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field9518;
    @NotNull
    private final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field9519;
    @NotNull
    private final UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp Field9520;
    @NotNull
    private final UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp Field9521;
    private int Field9522;

    static {
        a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[(int)((long)265180800 ^ (long)265180803) << 1];
        a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray2 = a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
        int n = (int)-68731029L ^ 0xFBE73F6B;
        int n2 = (int)-1684636806L ^ 0x9B967B7A;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs2 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$1.Field14328);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs2, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$12.Field9652);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$15.Field9677);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs5 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$16.Field9675);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs5, (String)"task.task {\n            \u2026n@task null\n            }");
        a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[n] = Field9509 = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Depth", n2, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs2, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs5, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8651, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8662);
        int n3 = (int)((long)-1614818192 ^ (long)-1614818191);
        int n4 = (int)((long)-641734816 ^ (long)-641734815);
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs6 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$17.Field9694);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs6, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs7 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$18.Field9692);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs7, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs8 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$19.Field9690);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs8, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs9 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$20.Field9605);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs9, (String)"task.task {\n            \u2026n@task null\n            }");
        a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[n3] = Field9510 = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Lighting", n4, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs6, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs7, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs8, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs9, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8652, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8663);
        int n5 = (int)((long)1655098112 ^ (long)1655098113) << 1;
        int n6 = (int)((long)-538706746 ^ (long)-538706745) << 1;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs10 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$21.Field9603);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs10, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs11 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$2.Field14326);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs11, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs12 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$3.Field14323);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs12, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs13 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$4.Field14321);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs13, (String)"task.task {\n            \u2026n@task null\n            }");
        a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[n5] = Field9511 = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Culling", n6, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs10, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs11, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs12, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs13, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8653, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8664);
        int n7 = (int)((long)-800739223 ^ (long)-800739222);
        int n8 = (int)((long)1537608528 ^ (long)1537608531);
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs14 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$5.Field14311);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs14, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs15 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$6.Field14267);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs15, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs16 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$7.Field14264);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs16, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs17 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$8.Field14256);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs17, (String)"task.task {\n            \u2026n@task null\n            }");
        a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[n7] = Field9512 = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Blend", n8, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs14, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs15, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs16, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs17, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8654, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8665);
        int n9 = ((int)-269519840L ^ 0xEFEF7421) << 2;
        int n10 = ((int)-2022783661L ^ 0x876EC552) << 2;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs18 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$9.Field14252);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs18, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs19 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1821();
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs19, (String)"voidTask");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs20 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1821();
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs20, (String)"voidTask");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs21 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1821();
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs21, (String)"voidTask");
        a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[n9] = Field9513 = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Translucent", n10, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs18, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs19, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs20, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs21, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8655, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8666);
        int n11 = (int)-109500680L ^ 0xF97926FD;
        int n12 = (int)((long)1244815766 ^ (long)1244815763);
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs22 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$10.Field9662);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs22, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs23 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$11.Field9660);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs23, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs24 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$13.Field9688);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs24, (String)"task.task {\n            \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs25 = a9PYGIjInk30FCZMc4guCckFx9sykjkK.Method1820().Method7663(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$14.Field9686);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs25, (String)"task.task {\n            \u2026n@task null\n            }");
        a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[n11] = Field9514 = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Texture2D", n12, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs22, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs23, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs24, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs25, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8656, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp.Field8667);
        Field9515 = a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
    }

    @NotNull
    @NotNull
    public final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method1807() {
        return this.Field9516;
    }

    @NotNull
    @NotNull
    public final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method1808() {
        return this.Field9517;
    }

    @NotNull
    @NotNull
    public final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method1809() {
        return this.Field9518;
    }

    @NotNull
    @NotNull
    public final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method1810() {
        return this.Field9519;
    }

    @NotNull
    @NotNull
    public final UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp Method1811() {
        return this.Field9520;
    }

    @NotNull
    @NotNull
    public final UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp Method1812() {
        return this.Field9521;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp, UAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp2) {
        void var8_6;
        void var7_5;
        void var2_-1;
        void var1_-1;
        this.Field9516 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3;
        this.Field9517 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4;
        this.Field9518 = uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp;
        this.Field9519 = uAo5ZGeXfsGn5huJ8j9wEh8Ldt3NzXrp2;
        this.Field9520 = var7_5;
        this.Field9521 = var8_6;
    }

    public static a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] values() {
        return (a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[])Field9515.clone();
    }

    public static a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi valueOf(String string) {
        return Enum.valueOf(a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.class, string);
    }

    private static String Method1813(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)91569102L ^ 0x5753BCE;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)388181091 ^ (long)388181148);
            int n2 = (int)((long)357306244 ^ (long)357306211);
            cArray2[n] = (char)(cArray[n] ^ (((int)1264292507L ^ 0x4B5BAE60) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

