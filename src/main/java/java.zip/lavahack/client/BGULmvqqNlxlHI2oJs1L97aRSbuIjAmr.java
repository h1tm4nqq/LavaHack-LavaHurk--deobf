/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;
import lavahack.client.m1tK2wr7aCudWKkiTyHef1jx8HzV9wJs;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=3)
public final class BGULmvqqNlxlHI2oJs1L97aRSbuIjAmr {
    public static final int[] Field8776 = new int[m1tK2wr7aCudWKkiTyHef1jx8HzV9wJs.values().length];
    private String Field8777 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        BGULmvqqNlxlHI2oJs1L97aRSbuIjAmr.Field8776[m1tK2wr7aCudWKkiTyHef1jx8HzV9wJs.Field8718.ordinal()] = (int)-1253516177L ^ 0xB548DC6E;
        BGULmvqqNlxlHI2oJs1L97aRSbuIjAmr.Field8776[m1tK2wr7aCudWKkiTyHef1jx8HzV9wJs.Field8719.ordinal()] = (int)((long)-138334024 ^ (long)-138334023) << 1;
        BGULmvqqNlxlHI2oJs1L97aRSbuIjAmr.Field8776[m1tK2wr7aCudWKkiTyHef1jx8HzV9wJs.Field8720.ordinal()] = (int)-1958297017L ^ 0x8B46C244;
        BGULmvqqNlxlHI2oJs1L97aRSbuIjAmr.Field8776[m1tK2wr7aCudWKkiTyHef1jx8HzV9wJs.Field8722.ordinal()] = ((int)-1950677456L ^ 0x8BBB0631) << 2;
        BGULmvqqNlxlHI2oJs1L97aRSbuIjAmr.Field8776[m1tK2wr7aCudWKkiTyHef1jx8HzV9wJs.Field8721.ordinal()] = (int)((long)894461464 ^ (long)894461469);
    }
}

