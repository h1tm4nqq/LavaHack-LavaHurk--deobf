/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

final class aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends Enum {
    public static final /* enum */ aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field8293 = new aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("EXTRA_BLOCK", (int)((long)1931301872 ^ (long)1931301872), (int)((long)-930510979 ^ (long)-935950398));
    public static final /* enum */ aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field8294 = new aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("WRONG_BLOCK", (int)((long)-542914176 ^ (long)-542914175), (int)((long)-2029028106 ^ (long)-2029028343) << 16);
    public static final /* enum */ aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field8295 = new aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("WRONG_META", ((int)1670763880L ^ 0x6395D569) << 1, (int)((long)-1731598048 ^ (long)-1731635585) << 8);
    public static final /* enum */ aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field8296 = new aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("MISSING_BLOCK", (int)-2016985028L ^ 0x87C7403F, (int)11462414L ^ 0xAE58F1);
    public final int Field8297;
    private static final aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] Field8298;
    private String Field8299 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public static aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] values() {
        return (aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[])Field8298.clone();
    }

    public static aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi valueOf(String string) {
        return Enum.valueOf(aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.class, string);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
        void var3_1;
        void var2_-1;
        void var1_-1;
        this.Field8297 = var3_1;
    }

    static {
        aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray = new aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[((int)-797030167L ^ 0xD07E48E8) << 2];
        aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)1568530707 ^ (long)1568530707)] = Field8293;
        aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)-2094199057L ^ 0x832D0EEE] = Field8294;
        aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)1285427381 ^ (long)1285427380) << 1] = Field8295;
        aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)563684797L ^ 0x219925BE] = Field8296;
        Field8298 = aHsp7hHIuzANEyruZeiq3e1ocuEjb7cC$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
    }

    private static String Method745(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)-1099632884L ^ 0xBE74EF0C;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-698166148L ^ 0xD662D483);
            int n2 = (int)122845276L ^ 0x75278B9;
            cArray2[n] = (char)(cArray[n] ^ (((int)-781382192L ^ 0xD16D307F) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

