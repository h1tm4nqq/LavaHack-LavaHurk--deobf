/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import com.kisman.cc.event.Event;
import kotlin.Metadata;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0016\u0018\u00002\u00020\u0001:\u0005\u0003\u0004\u0005\u0006\u0007B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\b"}, d2={"Lcom/kisman/cc/event/events/EventIngameOverlay;", "Lcom/kisman/cc/event/Event;", "()V", "BossBar", "Hotbar", "Overlay", "Portal", "Pumpkin", "kisman.cc"})
public class DitR6vZ79qQrTZ031J7xzQQWKdUckNea
extends Event {
    private String Field9162 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public DitR6vZ79qQrTZ031J7xzQQWKdUckNea() {
        super(new Object[(int)-458231424L ^ 0xE4AFF180]);
    }
}

