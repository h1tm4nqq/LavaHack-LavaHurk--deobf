/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0003H&J\b\u0010\t\u001a\u00020\u0000H&J\b\u0010\n\u001a\u00020\u0003H&R\u0012\u0010\u0002\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005\u00a8\u0006\u000b"}, d2={"Lcom/kisman/cc/websockets/api/protocols/IProtocol;", "", "providedProtocol", "", "getProvidedProtocol", "()Ljava/lang/String;", "acceptProvidedProtocol", "", "inputProtocolHeader", "copyInstance", "toString", "kisman.cc"})
public interface dLtfcAfLpVozije9AO0FW8DO22lwsDHm {
    public boolean Method1144(@NotNull @NotNull String var1);

    @NotNull
    @NotNull
    public String Method1145();

    @NotNull
    @NotNull
    public dLtfcAfLpVozije9AO0FW8DO22lwsDHm Method1146();

    @NotNull
    @NotNull
    public String toString();
}

