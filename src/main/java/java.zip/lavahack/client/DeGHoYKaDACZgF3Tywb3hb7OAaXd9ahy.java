/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC;

public interface DeGHoYKaDACZgF3Tywb3hb7OAaXd9ahy {
    public Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC Method3313(Object[] var1, Class[] var2);
}

