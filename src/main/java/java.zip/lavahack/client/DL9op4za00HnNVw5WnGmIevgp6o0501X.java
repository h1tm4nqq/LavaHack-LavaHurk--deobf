/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC;

public interface DL9op4za00HnNVw5WnGmIevgp6o0501X {
    public Object Method4631(Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC var1);
}

