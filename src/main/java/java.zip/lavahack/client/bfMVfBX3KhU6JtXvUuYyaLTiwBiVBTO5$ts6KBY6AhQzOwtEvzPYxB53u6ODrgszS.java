/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5;
import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

public class bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS
extends bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5 {
    private int Field9527;

    public bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2) {
        super(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.Field12932, bfMVfBX3KhU6JtXvUuYyaLTiwBiVBTO5$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field11530);
    }
}

