/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL20
 */
package lavahack.client;

import lavahack.client.WieLcrIxU3iYF11f2EiUDyi7gNqAZWP8;
import org.lwjgl.opengl.GL20;

public class cr0M8mK9GGI5hAZcYO5z8A4281TSSYrL
extends WieLcrIxU3iYF11f2EiUDyi7gNqAZWP8 {
    private String Field14194 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public Boolean Method5429() {
        return (boolean)((long)1757894504 ^ (long)1757894504);
    }

    public cr0M8mK9GGI5hAZcYO5z8A4281TSSYrL Method5430(int n) {
        GL20.glUniform1i((int)n, (int)((Boolean)this.Method647() != false ? (int)((long)424496211 ^ (long)424496210) : (int)((long)-413683543 ^ (long)-413683543)));
        return this;
    }

    @Override
    public Object Method646(int n) {
        return this.Method5430(n);
    }

    @Override
    public Object Method645() {
        return this.Method5429();
    }
}

