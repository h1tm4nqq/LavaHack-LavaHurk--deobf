/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.util.Arrays;
import lavahack.client.BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj;
import lavahack.client.M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk;
import lavahack.client.WjjBVRrUqJUKhloA7ANknrTEODhuGa0J;
import lavahack.client.XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9;
import lavahack.client.qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P;
import lavahack.client.qTretGQGc3EMQ1oiqlGmYy7Xw28i5pmW;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

public class aaIDVwbtzp3KxPpHfK7jnkVMYqAV3lzi
extends WjjBVRrUqJUKhloA7ANknrTEODhuGa0J {
    public final M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk Field16453 = new M5Lq2iwJmjqoQZOEOhulHI2lN3li1Zlk("Mode", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj.Field14654).Method5303();
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16454 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Anti Alias", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, ((int)456097636L ^ 0x1B2F7F65) != 0));
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16455 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Fraction Metrics", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, (boolean)((long)-127907336 ^ (long)-127907335)));
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16456 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Style", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, qTretGQGc3EMQ1oiqlGmYy7Xw28i5pmW.Field15543));
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16457 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Test", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, (boolean)((long)522043069 ^ (long)522043069)));
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16458 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Test 2", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, (boolean)((long)-1365515118 ^ (long)-1365515118)));
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16459 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Multi Line Offset", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, Double.longBitsToDouble(0xAAC0E95465C167EAL ^ 0xEAC0E95465C167EAL), 0.0, Double.longBitsToDouble(0x35E107F3CBDC7A7EL ^ 0x75CF07F3CBDC7A7EL), (boolean)((long)1288580271 ^ (long)1288580270)));
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16460 = new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Fallback Font", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, ((int)-1253884186L ^ 0xB5433EE6) != 0);
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16461;
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16462;
    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field16463;
    public static boolean Field16464 = (int)-291579103L ^ 0xEE9EDB21;
    public static aaIDVwbtzp3KxPpHfK7jnkVMYqAV3lzi Field16465 = new aaIDVwbtzp3KxPpHfK7jnkVMYqAV3lzi();
    private String Field16466 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    private aaIDVwbtzp3KxPpHfK7jnkVMYqAV3lzi() {
        super("CustomFont", "custom font", qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P.Field8339);
        String[] stringArray = new String[(int)((long)-1279649984 ^ (long)-1279649975)];
        stringArray[(int)-194359726L ^ 0xF46A4E52] = "Verdana";
        stringArray[(int)((long)740778068 ^ (long)740778069)] = "Comfortaa";
        stringArray[(int)((long)647368141 ^ (long)647368140) << 1] = "Comfortaa Light";
        stringArray[(int)((long)1851495257 ^ (long)1851495258)] = "Comfortaa Bold";
        stringArray[((int)-2040995974L ^ 0x8658DF7B) << 2] = "Consolas";
        stringArray[(int)((long)2020915077 ^ (long)2020915072)] = "LexendDeca";
        stringArray[(int)((long)-517954379 ^ (long)-517954378) << 1] = "Futura";
        stringArray[(int)((long)-1735019346 ^ (long)-1735019351)] = "SfUi";
        stringArray[((int)-1854364552L ^ 0x9178A479) << 3] = "Century";
        this.Field16461 = new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Fallback Mode", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, "Futura", Arrays.asList(stringArray));
        this.Field16462 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Custom Size", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, ((int)-172690752L ^ 0xF5B4F2C0) != 0));
        this.Field16463 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Size", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, Double.longBitsToDouble(0xFC235566BF54524DL ^ 0xBC115566BF54524DL), Double.longBitsToDouble((long)1374408160 ^ 0x4014000051EBCDE0L), Double.longBitsToDouble(0x5850969F65986B88L ^ 0x186E969F65986B88L), (boolean)((long)-112674085 ^ (long)-112674086)).Method313(this.Field16462::Method365));
        super.Method44(this::Method6899);
        Field16465 = this;
    }

    @Override
    public void Method45() {
        Field16464 = (int)((long)-966527385 ^ (long)-966527386);
        if (XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3261() != this.Field16454.Method365()) {
            XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3259(this.Field16454.Method365());
        }
        if (XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3262() != this.Field16455.Method365()) {
            XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3260(this.Field16455.Method365());
            XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3259(this.Field16454.Method365());
        }
        XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3265(this.Field16459.Method335());
    }

    @Override
    public void Method39() {
        Field16464 = (int)((long)1480698217 ^ (long)1480698217);
    }

    private String Method6899() {
        String string;
        StringBuilder stringBuilder = new StringBuilder().append("[").append(this.Field16453.Method359());
        if (this.Field16460.Method365()) {
            string = " | " + this.Field16461.Method359();
            return stringBuilder.append(string).append("]").toString();
        }
        string = "";
        return stringBuilder.append(string).append("]").toString();
    }

    private static String Method57(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)1317258303L ^ 0x4E83C43F;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)-1910728640 ^ (long)-1910728513);
            int n2 = (int)((long)2057895134 ^ (long)2057895061);
            cArray2[n] = (char)(cArray[n] ^ ((int)439745212L ^ 0x1A35C19D ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

