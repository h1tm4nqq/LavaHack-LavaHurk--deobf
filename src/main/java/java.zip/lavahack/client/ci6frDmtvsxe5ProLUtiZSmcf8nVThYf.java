/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.Jl14CJNmtWTqlp58umYadtnd800b2Vd0;
import lavahack.client.OVr6sF5CeH66hsotktp9WWZm4gSQtcre;
import lavahack.client.QPlUy5UX00sJeOo267en2L4h1DlaeWfq;
import lavahack.client.ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$1;
import lavahack.client.ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.gW0lnlGk2rwQ1EHLEfYvz3h4P3UNvCW3;
import lavahack.client.hS2q7nEd8dHHQz33Sb2fmP8f1QDk01hc;
import lavahack.client.zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4;
import lavahack.client.zbns26JiHwo42IcUVKanfTHCxfIoRHEN;
import lavahack.client.zmVsbwAdTVZaRYytJCehCE9v2PCkzpEB;

public class ci6frDmtvsxe5ProLUtiZSmcf8nVThYf
implements QPlUy5UX00sJeOo267en2L4h1DlaeWfq {
    private final OVr6sF5CeH66hsotktp9WWZm4gSQtcre Field17280;
    private final ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field17281;
    private int Field17282;
    private int Field17283;
    private int Field17284;
    private int Field17285;
    private int Field17286 = (int)((long)1178079054 ^ (long)1178079041) << 3;
    private int Field17287;
    private String Field17288 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public ci6frDmtvsxe5ProLUtiZSmcf8nVThYf(OVr6sF5CeH66hsotktp9WWZm4gSQtcre oVr6sF5CeH66hsotktp9WWZm4gSQtcre, ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi, int n, int n2, int n3, int n4, int n5) {
        this.Field17280 = oVr6sF5CeH66hsotktp9WWZm4gSQtcre;
        this.Field17281 = ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
        this.Field17282 = n;
        this.Field17283 = n2;
        this.Field17285 = n3;
        this.Field17284 = n4;
        this.Field17287 = n5;
        this.Field17286 = zbns26JiHwo42IcUVKanfTHCxfIoRHEN.Method3992(n5, this.Field17286);
    }

    @Override
    public void Method623(int n, int n2) {
        QPlUy5UX00sJeOo267en2L4h1DlaeWfq.super.Method623(n, n2);
        if (zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14590) {
            hS2q7nEd8dHHQz33Sb2fmP8f1QDk01hc.drawRectWH(this.Field17282, this.Field17283 + this.Field17285, this.Field17286, zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604, zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14584.Method3626());
            double[] dArray = new double[((int)-1670279365L ^ 0x9C718F3A) << 1];
            dArray[(int)1680460735L ^ 0x6429CBBF] = this.Field17282;
            dArray[(int)((long)163804370 ^ (long)163804371)] = this.Field17283 + this.Field17285;
            double[] dArray2 = new double[(int)((long)-1478074084 ^ (long)-1478074083) << 1];
            dArray2[(int)((long)-1328468681 ^ (long)-1328468681)] = this.Field17282 + this.Field17286 / ((int)((long)1581813300 ^ (long)1581813301) << 1);
            dArray2[(int)1638108119L ^ 0x61A38BD6] = this.Field17283 + this.Field17285;
            double[] dArray3 = new double[(int)((long)1860902759 ^ (long)1860902758) << 1];
            dArray3[(int)1273953632L ^ 0x4BEEFD60] = this.Field17282 + this.Field17286 / ((int)((long)1102308456 ^ (long)1102308457) << 1);
            dArray3[(int)((long)1190888219 ^ (long)1190888218)] = this.Field17283 + this.Field17285 + zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604;
            double[] dArray4 = new double[(int)((long)-154515774 ^ (long)-154515773) << 1];
            dArray4[(int)-1902929980L ^ 0x8E9397C4] = this.Field17282;
            dArray4[(int)((long)-1861982185 ^ (long)-1861982186)] = this.Field17283 + this.Field17285 + zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604;
            hS2q7nEd8dHHQz33Sb2fmP8f1QDk01hc.drawAbstract(new gW0lnlGk2rwQ1EHLEfYvz3h4P3UNvCW3(new Jl14CJNmtWTqlp58umYadtnd800b2Vd0(dArray, dArray2, dArray3, dArray4), zmVsbwAdTVZaRYytJCehCE9v2PCkzpEB.Method4729(zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14584.Method3626(), null.Field16098.Method335()), zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Method1228(this.Field17284).Method3625()));
            double[] dArray5 = new double[(int)((long)1738650228 ^ (long)1738650229) << 1];
            dArray5[(int)1837704968L ^ 0x6D892708] = this.Field17282 + this.Field17286 / ((int)((long)125164734 ^ (long)125164735) << 1);
            dArray5[(int)-2080333959L ^ 0x84009F78] = this.Field17283 + this.Field17285;
            double[] dArray6 = new double[(int)((long)1972356854 ^ (long)1972356855) << 1];
            dArray6[(int)((long)-1734091911 ^ (long)-1734091911)] = this.Field17282 + this.Field17286;
            dArray6[(int)((long)-2057492604 ^ (long)-2057492603)] = this.Field17283 + this.Field17285;
            double[] dArray7 = new double[((int)972573371L ^ 0x39F84ABA) << 1];
            dArray7[(int)1810514196L ^ 0x6BEA4114] = this.Field17282 + this.Field17286;
            dArray7[(int)1695781358L ^ 0x651391EF] = this.Field17283 + this.Field17285 + zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604;
            double[] dArray8 = new double[(int)((long)1282460290 ^ (long)1282460291) << 1];
            dArray8[(int)((long)919089444 ^ (long)919089444)] = this.Field17282 + this.Field17286 / (((int)-41416800L ^ 0xFD8807A1) << 1);
            dArray8[(int)((long)130814246 ^ (long)130814247)] = this.Field17283 + this.Field17285 + zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604;
            hS2q7nEd8dHHQz33Sb2fmP8f1QDk01hc.drawAbstract(new gW0lnlGk2rwQ1EHLEfYvz3h4P3UNvCW3(new Jl14CJNmtWTqlp58umYadtnd800b2Vd0(dArray5, dArray6, dArray7, dArray8), zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Method1228(this.Field17284).Method3625(), zmVsbwAdTVZaRYytJCehCE9v2PCkzpEB.Method4729(zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14584.Method3626(), null.Field16098.Method335())));
        } else {
            hS2q7nEd8dHHQz33Sb2fmP8f1QDk01hc.drawRectWH(this.Field17282, this.Field17283 + this.Field17285, this.Field17286, zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604, zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Method1228(this.Field17284).Method3626());
        }
        zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Method1224(this.Field17281.Field10005, this.Field17282, this.Field17283 + this.Field17285, this.Field17286, zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604);
    }

    @Override
    public void Method625(int n, int n2, int n3) {
        if (!this.Method7473(n, n2)) return;
        if (n3 != 0) return;
        switch (ci6frDmtvsxe5ProLUtiZSmcf8nVThYf$1.Field13263[this.Field17281.ordinal()]) {
            case 1: {
                this.Field17280.Method20();
                return;
            }
            case 2: {
                this.Field17280.Method4454(((int)-1017194756L ^ 0xC35ED6FD) != 0);
                return;
            }
        }
    }

    @Override
    public void Method629(int n) {
        this.Field17285 = n;
    }

    @Override
    public void Method630(int n) {
        this.Field17284 = n;
    }

    @Override
    public int Method631() {
        return zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604;
    }

    @Override
    public int Method633() {
        return this.Field17284;
    }

    @Override
    public void Method634(int n) {
        this.Field17286 = n;
    }

    @Override
    public void Method635(int n) {
        this.Field17282 = n;
    }

    @Override
    public int Method636() {
        return this.Field17282;
    }

    @Override
    public void Method639(int n) {
        this.Field17287 = n;
    }

    @Override
    public int Method640() {
        return this.Field17287;
    }

    @Override
    public void Method627(int n, int n2) {
        this.Field17282 = n;
        this.Field17283 = n2;
    }

    private boolean Method7473(int n, int n2) {
        int n3;
        if (n > this.Field17282 && n < this.Field17282 + this.Field17286 && n2 > this.Field17283 + this.Field17285 && n2 < this.Field17283 + this.Field17285 + zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Field14604) {
            n3 = (int)-1966923583L ^ 0x8AC320C0;
            return n3 != 0;
        }
        n3 = (int)-1142731495L ^ 0xBBE34D19;
        return n3 != 0;
    }

    @Override
    public boolean Method641() {
        return zU4JHFzU3TzRhHwHm4yw1gyHDTNJkZT4.Method1233(this.Field17281.Field10005);
    }

    @Override
    public void Method637(int n) {
        this.Field17283 = n;
    }

    @Override
    public int Method638() {
        return this.Field17283 + this.Field17285;
    }
}

