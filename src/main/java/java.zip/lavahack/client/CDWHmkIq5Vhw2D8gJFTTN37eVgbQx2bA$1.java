/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 */
package lavahack.client;

import net.minecraft.util.EnumFacing;

class CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$1 {
    static final int[] Field16547 = new int[EnumFacing.values().length];
    private String Field16548 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$1.Field16547[EnumFacing.DOWN.ordinal()] = (int)2136360970L ^ 0x7F56480B;
        CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$1.Field16547[EnumFacing.UP.ordinal()] = (int)((long)2030824412 ^ (long)2030824413) << 1;
        CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$1.Field16547[EnumFacing.NORTH.ordinal()] = (int)-1198800761L ^ 0xB88BC084;
        CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$1.Field16547[EnumFacing.SOUTH.ordinal()] = (int)((long)817071001 ^ (long)817071000) << 2;
        CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$1.Field16547[EnumFacing.WEST.ordinal()] = (int)((long)-1110727164 ^ (long)-1110727167);
        CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$1.Field16547[EnumFacing.EAST.ordinal()] = ((int)-1394784965L ^ 0xACDD4538) << 1;
    }
}

