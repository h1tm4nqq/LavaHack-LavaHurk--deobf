/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import com.kisman.cc.util.vl3icpcdb9cWvH39NKe3weWQwVdWO7AV;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.GnakMUPs8Y6dOYDRxYeXWX0dk0PiYXm7;
import lavahack.client.WjjBVRrUqJUKhloA7ANknrTEODhuGa0J;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;
import lavahack.client.xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl;
import lavahack.client.zmVsbwAdTVZaRYytJCehCE9v2PCkzpEB;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\u0007\u001a\u00020\nJ\b\u0010\u000b\u001a\u00020\u0000H\u0016J\b\u0010\f\u001a\u00020\u0000H\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"}, d2={"Lcom/kisman/cc/settings/util/HudModuleColorPattern;", "Lcom/kisman/cc/settings/util/AbstractPattern;", "module", "Lcom/kisman/cc/features/module/Module;", "(Lcom/kisman/cc/features/module/Module;)V", "astolfo", "Lcom/kisman/cc/settings/Setting;", "color", "group_", "Lcom/kisman/cc/settings/types/SettingGroup;", "Lcom/kisman/cc/util/Colour;", "init", "preInit", "kisman.cc"})
public final class bswyLzHpeAZv7X9IKxiqd0ExgIBOww74
extends GnakMUPs8Y6dOYDRxYeXWX0dk0PiYXm7 {
    private final xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl Field9878;
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field9879;
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field9880;
    private String Field9881 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    @NotNull
    @NotNull
    public bswyLzHpeAZv7X9IKxiqd0ExgIBOww74 Method2149() {
        if (this.Method769() == null) return this;
        xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl2 = this.Method769();
        if (xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl2 == null) {
            Intrinsics.throwNpe();
        }
        xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl2.Method7406(this.Field9878);
        return this;
    }

    @Override
    public Object Method778() {
        return this.Method2149();
    }

    @NotNull
    @NotNull
    public bswyLzHpeAZv7X9IKxiqd0ExgIBOww74 Method2150() {
        this.Method780().Method24(this.Field9878);
        this.Method780().Method23(this.Field9879);
        this.Method780().Method23(this.Field9880);
        return this;
    }

    @Override
    public Object Method779() {
        return this.Method2150();
    }

    @NotNull
    @NotNull
    public final vl3icpcdb9cWvH39NKe3weWQwVdWO7AV Method2151() {
        vl3icpcdb9cWvH39NKe3weWQwVdWO7AV vl3icpcdb9cWvH39NKe3weWQwVdWO7AV2;
        if (this.Field9879.Method365()) {
            vl3icpcdb9cWvH39NKe3weWQwVdWO7AV2 = new vl3icpcdb9cWvH39NKe3weWQwVdWO7AV(zmVsbwAdTVZaRYytJCehCE9v2PCkzpEB.Method4709(((int)1989542513L ^ 0x76960268) << 2, (int)((long)1931009807 ^ (long)1931009814) << 2));
            return vl3icpcdb9cWvH39NKe3weWQwVdWO7AV2;
        }
        vl3icpcdb9cWvH39NKe3weWQwVdWO7AV vl3icpcdb9cWvH39NKe3weWQwVdWO7AV3 = this.Field9880.Method339();
        vl3icpcdb9cWvH39NKe3weWQwVdWO7AV2 = vl3icpcdb9cWvH39NKe3weWQwVdWO7AV3;
        Intrinsics.checkExpressionValueIsNotNull((Object)vl3icpcdb9cWvH39NKe3weWQwVdWO7AV3, (String)"color.colour");
        return vl3icpcdb9cWvH39NKe3weWQwVdWO7AV2;
    }

    public bswyLzHpeAZv7X9IKxiqd0ExgIBOww74(@NotNull @NotNull WjjBVRrUqJUKhloA7ANknrTEODhuGa0J wjjBVRrUqJUKhloA7ANknrTEODhuGa0J) {
        Intrinsics.checkParameterIsNotNull((Object)wjjBVRrUqJUKhloA7ANknrTEODhuGa0J, (String)"module");
        super(wjjBVRrUqJUKhloA7ANknrTEODhuGa0J);
        this.Field9878 = new xjMxQu4kQNOzMncWZP5nUX1159T9K8Wl(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Color", wjjBVRrUqJUKhloA7ANknrTEODhuGa0J));
        this.Field9879 = this.Field9878.Method7405(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Astolfo", wjjBVRrUqJUKhloA7ANknrTEODhuGa0J, ((int)2115007720L ^ 0x7E1074E8) != 0));
        this.Field9880 = this.Field9878.Method7405(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Color", wjjBVRrUqJUKhloA7ANknrTEODhuGa0J, new vl3icpcdb9cWvH39NKe3weWQwVdWO7AV((int)((long)1143065324 ^ (long)1143065107), (int)1858939897L ^ 0x6ECD2BF9, (int)-501990286L ^ 0xE2143C72, (int)305603413L ^ 0x123723AA)));
    }

    private static String Method781(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)492849474L ^ 0x1D604942;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)-1162301087 ^ (long)-1162301026);
            int n2 = (int)1802119761L ^ 0x6B6A2AA0;
            cArray2[n] = (char)(cArray[n] ^ ((int)963218039L ^ 0x3969A8A4 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

