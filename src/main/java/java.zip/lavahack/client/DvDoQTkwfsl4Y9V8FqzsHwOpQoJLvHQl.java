/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.GMX4zGkGCEBL3RzM3pAccbEOC6fgYiKM;
import lavahack.client.WjjBVRrUqJUKhloA7ANknrTEODhuGa0J;
import lavahack.client.ZnmE0qUkLUVFxZBVTXvC0GWhFQ7tgLZy;
import lavahack.client.qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

@GMX4zGkGCEBL3RzM3pAccbEOC6fgYiKM
@ZnmE0qUkLUVFxZBVTXvC0GWhFQ7tgLZy
@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\b\u0010\b\u001a\u00020\tH\u0007J\b\u0010\n\u001a\u00020\tH\u0007J\b\u0010\u000b\u001a\u00020\tH\u0007R\u0016\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0007\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2={"Lcom/kisman/cc/features/module/client/NoSpoof;", "Lcom/kisman/cc/features/module/Module;", "()V", "ground", "Lcom/kisman/cc/settings/Setting;", "kotlin.jvm.PlatformType", "position", "rotation", "noGround", "", "noPosition", "noRotation", "kisman.cc"})
public final class DvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl
extends WjjBVRrUqJUKhloA7ANknrTEODhuGa0J {
    private static final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field15166;
    private static final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field15167;
    private static final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field15168;
    public static final DvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl Field15169;
    private String Field15170 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    @JvmStatic
    @JvmStatic
    public static final boolean Method6081() {
        qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2 = Field15166;
        Intrinsics.checkExpressionValueIsNotNull((Object)qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, (String)"position");
        return qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2.Method365();
    }

    @JvmStatic
    @JvmStatic
    public static final boolean Method27() {
        qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2 = Field15167;
        Intrinsics.checkExpressionValueIsNotNull((Object)qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, (String)"rotation");
        return qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2.Method365();
    }

    @JvmStatic
    @JvmStatic
    public static final boolean Method28() {
        qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2 = Field15168;
        Intrinsics.checkExpressionValueIsNotNull((Object)qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, (String)"ground");
        return qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2.Method365();
    }

    private DvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl() {
        super("NoSpoof", "PingBypass stuff", qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P.Field8339);
    }

    static {
        DvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl dvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl;
        Field15169 = dvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl = new DvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl();
        Field15166 = dvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Position", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)dvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl, (boolean)((long)-442917298 ^ (long)-442917298)));
        Field15167 = dvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Rotation", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)dvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl, ((int)831290753L ^ 0x318C7D81) != 0));
        Field15168 = dvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Ground", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)dvDoQTkwfsl4Y9V8FqzsHwOpQoJLvHQl, (boolean)((long)869521826 ^ (long)869521826)));
    }

    private static String Method57(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)509787468L ^ 0x1E62BD4C;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)-1728941068 ^ (long)-1728941301);
            int n2 = (int)((long)1946039663 ^ (long)1946039646) << 1;
            cArray2[n] = (char)(cArray[n] ^ ((int)1151058118L ^ 0x449BFADB ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

