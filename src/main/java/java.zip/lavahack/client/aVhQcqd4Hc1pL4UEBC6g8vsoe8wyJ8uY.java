/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.TDrOJYGYE6GxbjOEblLxwsKQtY1HZZvO;

public interface aVhQcqd4Hc1pL4UEBC6g8vsoe8wyJ8uY {
    public TDrOJYGYE6GxbjOEblLxwsKQtY1HZZvO Method6962(String var1);
}

