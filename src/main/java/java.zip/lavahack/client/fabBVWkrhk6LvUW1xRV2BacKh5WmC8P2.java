/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public class fabBVWkrhk6LvUW1xRV2BacKh5WmC8P2
extends Exception {
    private String Field16500 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public fabBVWkrhk6LvUW1xRV2BacKh5WmC8P2() {
    }

    public fabBVWkrhk6LvUW1xRV2BacKh5WmC8P2(String string) {
        super(string);
    }

    public fabBVWkrhk6LvUW1xRV2BacKh5WmC8P2(Throwable throwable) {
        super(throwable);
    }

    public fabBVWkrhk6LvUW1xRV2BacKh5WmC8P2(String string, Throwable throwable) {
        super(string, throwable);
    }
}

