/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;
import lavahack.client.KjrOCoQhxsxPltWeRSN6l89ExVE5NRMF;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=3)
public final class AJ2FnB8fdoqBiVEms70GxKyOrqj1xJnZ {
    public static final int[] Field14877 = new int[KjrOCoQhxsxPltWeRSN6l89ExVE5NRMF.values().length];
    private int Field14878;

    static {
        AJ2FnB8fdoqBiVEms70GxKyOrqj1xJnZ.Field14877[KjrOCoQhxsxPltWeRSN6l89ExVE5NRMF.Field17156.ordinal()] = (int)((long)-59071677 ^ (long)-59071678);
        AJ2FnB8fdoqBiVEms70GxKyOrqj1xJnZ.Field14877[KjrOCoQhxsxPltWeRSN6l89ExVE5NRMF.Field17157.ordinal()] = ((int)248697929L ^ 0xED2D448) << 1;
        AJ2FnB8fdoqBiVEms70GxKyOrqj1xJnZ.Field14877[KjrOCoQhxsxPltWeRSN6l89ExVE5NRMF.Field17158.ordinal()] = (int)((long)-355507410 ^ (long)-355507411);
    }
}

