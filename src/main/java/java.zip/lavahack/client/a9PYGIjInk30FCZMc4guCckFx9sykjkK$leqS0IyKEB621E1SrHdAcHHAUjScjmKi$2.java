//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  net.minecraft.client.renderer.GlStateManager
 */
package lavahack.client;

import kotlin.Metadata;
import lavahack.client.Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC;
import lavahack.client.veyf9YVihv33TUGV0DuHJrqb7huCpMgR;
import net.minecraft.client.renderer.GlStateManager;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=3, d1={"\u0000\u0010\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u00012\u000e\u0010\u0002\u001a\n \u0004*\u0004\u0018\u00010\u00030\u0003H\n\u00a2\u0006\u0002\b\u0005"}, d2={"<anonymous>", "", "it", "Lorg/cubic/dynamictask/ArgumentFetcher;", "kotlin.jvm.PlatformType", "call"})
final class a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$2
implements veyf9YVihv33TUGV0DuHJrqb7huCpMgR {
    public static final a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$2 Field14326 = new a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$2();
    private String Field14327 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    @Override
    public Object Method1564(Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC) {
        return this.Method5524(z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC);
    }

    @Nullable
    @Nullable
    public final Void Method5524(Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC) {
        GlStateManager.disableCull();
        return null;
    }

    a9PYGIjInk30FCZMc4guCckFx9sykjkK$leqS0IyKEB621E1SrHdAcHHAUjScjmKi$2() {
    }
}

