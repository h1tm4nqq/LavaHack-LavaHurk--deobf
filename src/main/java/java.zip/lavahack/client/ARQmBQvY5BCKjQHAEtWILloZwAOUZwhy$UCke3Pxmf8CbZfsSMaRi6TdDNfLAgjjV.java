/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 */
package lavahack.client;

import com.kisman.cc.event.Event$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.ARQmBQvY5BCKjQHAEtWILloZwAOUZwhy;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

public class ARQmBQvY5BCKjQHAEtWILloZwAOUZwhy$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV
extends ARQmBQvY5BCKjQHAEtWILloZwAOUZwhy {
    private String Field9892 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public ARQmBQvY5BCKjQHAEtWILloZwAOUZwhy$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV(BlockPos blockPos, EnumFacing enumFacing) {
        super(blockPos, enumFacing, Event$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field13746);
    }
}

