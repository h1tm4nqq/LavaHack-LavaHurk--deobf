/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import com.kisman.cc.event.Event;

public class cOY3JnnL4iiLr0AUdZQ0yQaDvd9YMfX9
extends Event {
    private int Field15809;

    public cOY3JnnL4iiLr0AUdZQ0yQaDvd9YMfX9() {
        super(new Object[(int)((long)-915759162 ^ (long)-915759162)]);
    }
}

