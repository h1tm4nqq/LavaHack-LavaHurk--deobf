/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$1;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$10;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$11;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$12;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$13;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$14;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$15;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$16;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$17;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$18;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$19;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$2;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$20;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$21;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$22;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$23;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$24;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$25;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$26;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$3;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$4;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$5;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$6;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$7;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$8;
import lavahack.client.a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$9;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0014\n\u0002\b\u0013\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0015\b\u0012\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0002\u0010\u0005B#\b\u0012\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0002\u0010\u0007B?\b\u0002\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\t0\u0003\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u0003\u00a2\u0006\u0002\u0010\u000bR\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\t0\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\rR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\rj\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018j\u0002\b\u0019j\u0002\b\u001aj\u0002\b\u001b\u00a8\u0006\u001c"}, d2={"Lcom/kisman/cc/util/enums/dynamic/RotationEnum$Rotation;", "", "taskR", "Lorg/cubic/dynamictask/AbstractTask;", "Ljava/lang/Void;", "(Ljava/lang/String;ILorg/cubic/dynamictask/AbstractTask;)V", "taskRFromSaver", "(Ljava/lang/String;ILorg/cubic/dynamictask/AbstractTask;Lorg/cubic/dynamictask/AbstractTask;)V", "taskCEntity", "", "taskCBlock", "(Ljava/lang/String;ILorg/cubic/dynamictask/AbstractTask;Lorg/cubic/dynamictask/AbstractTask;Lorg/cubic/dynamictask/AbstractTask;Lorg/cubic/dynamictask/AbstractTask;)V", "getTaskCBlock", "()Lorg/cubic/dynamictask/AbstractTask;", "getTaskCEntity", "getTaskR", "getTaskRFromSaver", "None", "Client", "ClientFull", "Packet", "PacketClient", "PacketClientFull", "ClientSilent", "ClientFullSilent", "PacketSilent", "PacketClientSilent", "PacketClientFullSilent", "kisman.cc"})
public final class a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf
extends Enum {
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8498;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8499;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8500;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8501;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8502;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8503;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8504;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8505;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8506;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8507;
    public static final /* enum */ a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field8508;
    private static final a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[] Field8509;
    @NotNull
    private final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field8510;
    @NotNull
    private final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field8511;
    @NotNull
    private final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field8512;
    @NotNull
    private final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Field8513;
    private int Field8514;

    static {
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[] a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[(int)((long)-251179159 ^ (long)-251179166)];
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[] a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray2 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray;
        int n = (int)2128700369L ^ 0x7EE163D1;
        int n2 = (int)2067259787L ^ 0x7B37E18B;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs2 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$1.Field11579);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs2, (String)"taskR.task {\n           \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$12.Field9373);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3, (String)"taskRFromSaver.task {\n  \u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5365().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$20.Field9301);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4, (String)"taskCEntity.task {\n     \u2026oatArray(0)\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs5 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5366().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$21.Field9299);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs5, (String)"taskCBlock.task {\n      \u2026oatArray(0)\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n] = Field8498 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("None", n2, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs2, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs5);
        int n3 = (int)((long)-2017779064 ^ (long)-2017779063);
        int n4 = (int)-876323109L ^ 0xCBC45EDA;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs6 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$22.Field9297);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs6, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs7 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$23.Field9313);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs7, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs8 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5365().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$24.Field9311);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs8, (String)"taskCEntity.task { arg: \u2026          )\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs9 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5366().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$25.Field9309);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs9, (String)"taskCBlock.task { arg: A\u2026e() + 0.5))\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n3] = Field8499 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("Client", n4, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs6, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs7, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs8, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs9);
        int n5 = ((int)1341037409L ^ 0x4FEE9B60) << 1;
        int n6 = ((int)1644601037L ^ 0x62069ECC) << 1;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs10 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$26.Field9307);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs10, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs11 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$2.Field11581);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs11, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n5] = Field8500 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("ClientFull", n6, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs10, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs11);
        int n7 = (int)((long)2077776728 ^ (long)2077776731);
        int n8 = (int)-1760313812L ^ 0x9713BE2F;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs12 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$3.Field11553);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs12, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs13 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$4.Field11555);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs13, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n7] = Field8501 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("Packet", n8, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs12, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs13);
        int n9 = ((int)123834461L ^ 0x761905C) << 2;
        int n10 = ((int)-1945010998L ^ 0x8C117CCB) << 2;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs14 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$5.Field11547);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs14, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs15 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$6.Field11551);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs15, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n9] = Field8502 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("PacketClient", n10, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs14, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs15);
        int n11 = (int)((long)-1983876041 ^ (long)-1983876046);
        int n12 = (int)((long)-1541844408 ^ (long)-1541844403);
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs16 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$7.Field11571);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs16, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs17 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$8.Field11576);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs17, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n11] = Field8503 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("PacketClientFull", n12, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs16, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs17);
        int n13 = ((int)-2124826367L ^ 0x8159B902) << 1;
        int n14 = (int)((long)346043320 ^ (long)346043323) << 1;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs18 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$9.Field11560);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs18, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs19 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$10.Field9362);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs19, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n13] = Field8504 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("ClientSilent", n14, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs18, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs19);
        int n15 = (int)-30506270L ^ 0xFE2E82E5;
        int n16 = (int)((long)-2038444826 ^ (long)-2038444831);
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs20 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$11.Field9360);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs20, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs21 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$13.Field9369);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs21, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n15] = Field8505 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("ClientFullSilent", n16, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs20, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs21);
        int n17 = (int)((long)328378350 ^ (long)328378351) << 3;
        int n18 = (int)((long)96819083 ^ (long)96819082) << 3;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs22 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$14.Field9367);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs22, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs23 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$15.Field9365);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs23, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n17] = Field8506 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("PacketSilent", n18, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs22, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs23);
        int n19 = (int)((long)407583772 ^ (long)407583765);
        int n20 = (int)((long)-1680158938 ^ (long)-1680158929);
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs24 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$16.Field9391);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs24, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs25 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$17.Field9387);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs25, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n19] = Field8507 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("PacketClientSilent", n20, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs24, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs25);
        int n21 = (int)((long)1496054670 ^ (long)1496054667) << 1;
        int n22 = (int)((long)96680641 ^ (long)96680644) << 1;
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs26 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5363().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$18.Field9385);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs26, (String)"taskR.task { arg : Argum\u2026n@task null\n            }");
        hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs27 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF.Method5364().Method7663(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf$19.Field9375);
        Intrinsics.checkExpressionValueIsNotNull((Object)hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs27, (String)"taskRFromSaver.task { ar\u2026n@task null\n            }");
        a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[n21] = Field8508 = new a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("PacketClientFullSilent", n22, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs26, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs27);
        Field8509 = a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray;
    }

    @NotNull
    @NotNull
    public final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method929() {
        return this.Field8510;
    }

    @NotNull
    @NotNull
    public final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method930() {
        return this.Field8511;
    }

    @NotNull
    @NotNull
    public final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method931() {
        return this.Field8512;
    }

    @NotNull
    @NotNull
    public final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs Method932() {
        return this.Field8513;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf(hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3, hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4) {
        void var6_4;
        void var5_3;
        void var2_-1;
        void var1_-1;
        this.Field8510 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs3;
        this.Field8511 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs4;
        this.Field8512 = var5_3;
        this.Field8513 = var6_4;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf() {
        this((String)var1_-1, (int)var2_-1, (hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs)var3_1, a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field8499.Field8511, a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field8499.Field8512, a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field8499.Field8513);
        void var3_1;
        void var2_-1;
        void var1_-1;
    }

    /*
     * WARNING - void declaration
     */
    private a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf() {
        this((String)var1_-1, (int)var2_-1, (hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs)var3_1, (hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs)var4_2, a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field8499.Field8512, a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field8499.Field8513);
        void var4_2;
        void var3_1;
        void var2_-1;
        void var1_-1;
    }

    public static a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[] values() {
        return (a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[])Field8509.clone();
    }

    public static a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf valueOf(String string) {
        return Enum.valueOf(a2RqMGLVL5eLhJgc0LAUR9msraZzFUNF$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.class, string);
    }

    private static String Method933(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-1695867784 ^ (long)-1695867784);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)1258083964 ^ (long)1258083971);
            int n2 = (int)-865299299L ^ 0xCC6C94D6;
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)953390767 ^ (long)953407456) ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

