/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.luaj.vm2.LuaValue
 *  org.luaj.vm2.lib.ThreeArgFunction
 */
package lavahack.client;

import lavahack.client.enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.ThreeArgFunction;

class enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf
extends ThreeArgFunction {
    private int Field15037;

    enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf() {
    }

    public LuaValue call(LuaValue luaValue, LuaValue luaValue2, LuaValue luaValue3) {
        return enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL.Method6380(luaValue, luaValue2, luaValue3);
    }
}

