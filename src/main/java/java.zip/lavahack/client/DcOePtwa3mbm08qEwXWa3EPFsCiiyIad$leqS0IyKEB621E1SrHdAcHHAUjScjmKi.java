/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import lavahack.client.DcOePtwa3mbm08qEwXWa3EPFsCiiyIad;
import lavahack.client.DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2={"Lcom/kisman/cc/util/chat/ChatHandler$Companion;", "", "()V", "instance", "Lcom/kisman/cc/util/chat/ChatHandler$Instance;", "getInstance", "()Lcom/kisman/cc/util/chat/ChatHandler$Instance;", "kisman.cc"})
public final class DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$leqS0IyKEB621E1SrHdAcHHAUjScjmKi {
    private String Field13029 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    @NotNull
    @NotNull
    public final DcOePtwa3mbm08qEwXWa3EPFsCiiyIad.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method4563() {
        return DcOePtwa3mbm08qEwXWa3EPFsCiiyIad.Method440();
    }

    private DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
    }

    public DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }
}

