/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;
import lavahack.client.DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.MtRGnZ0MQXYZVwcrh1IN1d8I8EVjc3bI;
import lavahack.client.WjjBVRrUqJUKhloA7ANknrTEODhuGa0J;
import lavahack.client.qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 \n2\u00020\u0001:\u0001\nB\u0005\u00a2\u0006\u0002\u0010\u0002R\u0019\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0019\u0010\b\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0007\u00a8\u0006\u000b"}, d2={"Lcom/kisman/cc/features/module/client/DevelopmentHelper;", "Lcom/kisman/cc/features/module/Module;", "()V", "displaySlots", "Lcom/kisman/cc/settings/Setting;", "kotlin.jvm.PlatformType", "getDisplaySlots", "()Lcom/kisman/cc/settings/Setting;", "slotType", "getSlotType", "Companion", "kisman.cc"})
public final class DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh
extends WjjBVRrUqJUKhloA7ANknrTEODhuGa0J {
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field9967 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Display Slots", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, (boolean)((long)707273193 ^ (long)707273193)));
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field9968 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Slot Type", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, MtRGnZ0MQXYZVwcrh1IN1d8I8EVjc3bI.Field16945));
    @Nullable
    private static DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh Field9969;
    public static final DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field9970;
    private String Field9971 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Method2210() {
        return this.Field9967;
    }

    public final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Method2211() {
        return this.Field9968;
    }

    public DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh() {
        super("DevelopmentHelper", "Helps with lavahack development.", qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P.Field8339);
        Field9969 = this;
    }

    static {
        Field9970 = new DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(null);
    }

    public static final DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh Method2212() {
        return Field9969;
    }

    public static final void Method2213(DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh dfxOZyI94jdDOZQSfulpe3ocgVMaQcfh) {
        Field9969 = dfxOZyI94jdDOZQSfulpe3ocgVMaQcfh;
    }

    @Nullable
    @Nullable
    public static final DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh Method2214() {
        DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh$leqS0IyKEB621E1SrHdAcHHAUjScjmKi dfxOZyI94jdDOZQSfulpe3ocgVMaQcfh$leqS0IyKEB621E1SrHdAcHHAUjScjmKi = Field9970;
        return Field9969;
    }

    public static final void Method2215(@Nullable @Nullable DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh dfxOZyI94jdDOZQSfulpe3ocgVMaQcfh) {
        DfxOZyI94jdDOZQSfulpe3ocgVMaQcfh$leqS0IyKEB621E1SrHdAcHHAUjScjmKi dfxOZyI94jdDOZQSfulpe3ocgVMaQcfh$leqS0IyKEB621E1SrHdAcHHAUjScjmKi = Field9970;
        Field9969 = dfxOZyI94jdDOZQSfulpe3ocgVMaQcfh;
    }

    private static String Method57(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)1307393709L ^ 0x4DED3EAD;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)1042339498L ^ 0x3E20D655);
            int n2 = ((int)-263921174L ^ 0xF044E1B5) << 1;
            cArray2[n] = (char)(cArray[n] ^ ((int)-1205670853L ^ 0xB8229560 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

