//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 *  net.minecraftforge.event.entity.EntityJoinWorldEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package lavahack.client;

import java.util.function.Predicate;
import lavahack.client.CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt;
import lavahack.client.F3RUJ4pqKqExz7WB5oipQI42Y4NfLlLa;
import lavahack.client.PzymjJJ9R7LhPzqSLW2fMv06yAvJr5Gb;
import lavahack.client.TAt7QzOqrfY8P9hNnkrnImm9scdhYm72$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV;
import lavahack.client.TAt7QzOqrfY8P9hNnkrnImm9scdhYm72$vl3icpcdb9cWvH39NKe3weWQwVdWO7AV;
import lavahack.client.WjjBVRrUqJUKhloA7ANknrTEODhuGa0J;
import lavahack.client.WkowkMIYywGBZ1LvpVpVCHmyCihJiruH;
import lavahack.client.Xk5sPHveL7cs0etgQcPiiTDg9MaCU9uc;
import lavahack.client.leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.o73igJQaa2O9BEYFQNAk42oaxHBow5kd;
import lavahack.client.qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;
import lavahack.client.uwE7kWOUin9fjWlKYd2g07AwOzCzWS4x;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AgUkNNp6h0gOf2NNPecFmCotl8eelugl
extends WjjBVRrUqJUKhloA7ANknrTEODhuGa0J {
    public static AgUkNNp6h0gOf2NNPecFmCotl8eelugl Field9377;
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field9378 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Speed", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, 1.0, 0.0, Double.longBitsToDouble(0x74743DB608987948L ^ 0x34503DB608987948L), ((int)516734380L ^ 0x1ECCBDAC) != 0));
    private EntityOtherPlayerMP Field9379;
    @F3RUJ4pqKqExz7WB5oipQI42Y4NfLlLa
    private final CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt Field9380 = new CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt(AgUkNNp6h0gOf2NNPecFmCotl8eelugl::Method1658, new Predicate[(int)-2048091532L ^ 0x85EC9A74]);
    @F3RUJ4pqKqExz7WB5oipQI42Y4NfLlLa
    private final CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt Field9381 = new CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt(AgUkNNp6h0gOf2NNPecFmCotl8eelugl::Method1657, new Predicate[(int)1764259186L ^ 0x69287572]);
    @F3RUJ4pqKqExz7WB5oipQI42Y4NfLlLa
    private final CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt Field9382 = new CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt(this::Method1655, new Predicate[(int)((long)1609403375 ^ (long)1609403375)]);
    @F3RUJ4pqKqExz7WB5oipQI42Y4NfLlLa
    private final CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt Field9383 = new CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt(WkowkMIYywGBZ1LvpVpVCHmyCihJiruH::Method158, new Predicate[(int)-1853184085L ^ 0x918AA7AB]);
    private String Field9384 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public AgUkNNp6h0gOf2NNPecFmCotl8eelugl() {
        super("FreeCamRewrite", qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P.Field8341);
        Field9377 = this;
    }

    @Override
    public void Method38() {
        super.Method38();
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method706(this.Field9380);
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method706(this.Field9381);
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method706(this.Field9382);
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method706(this.Field9383);
        if (AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player != null && AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.world != null) {
            AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.dismountRidingEntity();
            this.Field9379 = PzymjJJ9R7LhPzqSLW2fMv06yAvJr5Gb.Method6634(AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.getGameProfile());
            this.Field9379.onGround = AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.onGround;
            return;
        }
        super.Method21(((int)211511579L ^ 0xC9B691B) != 0);
    }

    @Override
    public void Method39() {
        super.Method39();
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method711(this.Field9380);
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method711(this.Field9381);
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method711(this.Field9382);
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method711(this.Field9383);
        if (AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player == null) return;
        if (AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.world == null) {
            return;
        }
        AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.setPosition(this.Field9379.posX, this.Field9379.posY, this.Field9379.posZ);
        AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.noClip = (int)((long)-1894855363 ^ (long)-1894855363);
        PzymjJJ9R7LhPzqSLW2fMv06yAvJr5Gb.Method6637(this.Field9379);
        this.Field9379 = null;
    }

    @SubscribeEvent
    @SubscribeEvent
    public void Method1652(EntityJoinWorldEvent entityJoinWorldEvent) {
        if (entityJoinWorldEvent.getEntity() != AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player) return;
        super.Method21(((int)1535900284L ^ 0x5B8BFA7C) != 0);
    }

    public EntityOtherPlayerMP Method1653() {
        return this.Field9379;
    }

    public void Method1654(float f, float f2) {
        if (this.Field9379 == null) return;
        this.Field9379.rotationYawHead = f;
        this.Field9379.setPositionAndRotation(this.Field9379.posX, this.Field9379.posY, this.Field9379.posZ, f, f2);
        this.Field9379.setPositionAndRotationDirect(this.Field9379.posX, this.Field9379.posY, this.Field9379.posZ, f, f2, (int)((long)-668255490 ^ (long)-668255491), ((int)1832820373L ^ 0x6D3E9E95) != 0);
    }

    @Override
    public void Method45() {
        if (AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player == null) return;
        if (AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.world == null) {
            return;
        }
        AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.noClip = (int)-1852660265L ^ 0x9192A5D6;
        AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.setVelocity(0.0, 0.0, 0.0);
        AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.jumpMovementFactor = (float)this.Field9378.Method367();
        if (o73igJQaa2O9BEYFQNAk42oaxHBow5kd.Method7159()) {
            double[] dArray = o73igJQaa2O9BEYFQNAk42oaxHBow5kd.Method7166(this.Field9378.Method367());
            AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.motionX = dArray[(int)((long)-1319000161 ^ (long)-1319000161)];
            AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.motionZ = dArray[(int)-377518385L ^ 0xE97F86CE];
        } else {
            AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.motionX = 0.0;
            AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.motionZ = 0.0;
        }
        AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.setSprinting((boolean)((long)-1762334500 ^ (long)-1762334500));
        if (AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.gameSettings.keyBindJump.isKeyDown()) {
            AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.motionY += this.Field9378.Method367();
        }
        if (!AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.gameSettings.keyBindSneak.isKeyDown()) return;
        AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.motionY -= this.Field9378.Method367();
    }

    private void Method1655(TAt7QzOqrfY8P9hNnkrnImm9scdhYm72$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV tAt7QzOqrfY8P9hNnkrnImm9scdhYm72$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV) {
        vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.addScheduledTask(() -> this.Method1656(tAt7QzOqrfY8P9hNnkrnImm9scdhYm72$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV));
        tAt7QzOqrfY8P9hNnkrnImm9scdhYm72$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV.Method158();
    }

    private void Method1656(TAt7QzOqrfY8P9hNnkrnImm9scdhYm72$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV tAt7QzOqrfY8P9hNnkrnImm9scdhYm72$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV) {
        if (AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player == null) {
            return;
        }
        Xk5sPHveL7cs0etgQcPiiTDg9MaCU9uc.Method4344((SPacketPlayerPosLook)tAt7QzOqrfY8P9hNnkrnImm9scdhYm72$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV.Method982(), (Entity)(this.Method1653() == null ? AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player : this.Method1653()), ((int)-435049048L ^ 0xE611ADA8) != 0);
        this.Method1653().onGround = (int)((long)-697033522 ^ (long)-697033521);
    }

    private static void Method1657(TAt7QzOqrfY8P9hNnkrnImm9scdhYm72$vl3icpcdb9cWvH39NKe3weWQwVdWO7AV tAt7QzOqrfY8P9hNnkrnImm9scdhYm72$vl3icpcdb9cWvH39NKe3weWQwVdWO7AV) {
        if (!(tAt7QzOqrfY8P9hNnkrnImm9scdhYm72$vl3icpcdb9cWvH39NKe3weWQwVdWO7AV.Method982() instanceof CPacketPlayer)) return;
        tAt7QzOqrfY8P9hNnkrnImm9scdhYm72$vl3icpcdb9cWvH39NKe3weWQwVdWO7AV.Method158();
    }

    private static void Method1658(uwE7kWOUin9fjWlKYd2g07AwOzCzWS4x uwE7kWOUin9fjWlKYd2g07AwOzCzWS4x2) {
        AgUkNNp6h0gOf2NNPecFmCotl8eelugl.vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.player.noClip = (int)-2111232894L ^ 0x82292483;
    }

    private static String Method57(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)-420850668L ^ 0xE6EA5414;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)750213070 ^ (long)750212913);
            int n2 = (int)((long)545092001 ^ (long)545092010) << 4;
            cArray2[n] = (char)(cArray[n] ^ ((int)501127408L ^ 0x1DDE871D ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

