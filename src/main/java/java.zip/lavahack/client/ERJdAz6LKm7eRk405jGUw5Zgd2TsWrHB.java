/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.Event
 */
package lavahack.client;

import lavahack.client.meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU;
import net.minecraftforge.fml.common.eventhandler.Event;

public class ERJdAz6LKm7eRk405jGUw5Zgd2TsWrHB
extends Event {
    public final meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU Field10827;
    private int Field10828;

    public ERJdAz6LKm7eRk405jGUw5Zgd2TsWrHB(meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU2) {
        this.Field10827 = meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU2;
    }
}

