/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.objects.ObjectArrayList
 *  it.unimi.dsi.fastutil.objects.ObjectList
 */
package lavahack.client;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import lavahack.client.OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj;
import lavahack.client.auE3dCySxyIc1tKngAVuALlcvYBWsMni$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import lavahack.client.auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE;
import lavahack.client.leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo;
import lavahack.client.xubZE46GRLM33q2kL5Cp8EKtKVuCQgm6;

public class auE3dCySxyIc1tKngAVuALlcvYBWsMni {
    public ObjectList Field14198;
    public ObjectList Field14199;
    public ObjectList Field14200;
    private String Field14201 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public void Method5435(InputStream inputStream) throws IOException {
        String string;
        this.Field14198 = new ObjectArrayList();
        this.Field14199 = new ObjectArrayList();
        this.Field14200 = new ObjectArrayList();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        while ((string = bufferedReader.readLine()) != null) {
            irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2;
            String[] stringArray;
            if (string.startsWith("CL")) {
                stringArray = string.replace("CL: ", "").split(" ");
                irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2 = new xubZE46GRLM33q2kL5Cp8EKtKVuCQgm6();
                irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2.vl3icpcdb9cWvH39NKe3weWQwVdWO7AV = stringArray[(int)((long)1994152185 ^ (long)1994152185)];
                irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2.Ljc0gDTN8WkwPRHY480HpEkScGALG41A = irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS = stringArray[(int)-1094615319L ^ 0xBEC17EE8];
                this.Field14198.add((Object)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2);
                System.out.println("Class: official " + irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2.vl3icpcdb9cWvH39NKe3weWQwVdWO7AV + ", named/intermediary " + irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2.Ljc0gDTN8WkwPRHY480HpEkScGALG41A);
            }
            if (string.startsWith("FD")) {
                stringArray = string.replaceAll("FD: ", "").split(" ");
                irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2 = new OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj();
                ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).vl3icpcdb9cWvH39NKe3weWQwVdWO7AV = stringArray[(int)1273918661L ^ 0x4BEE74C5].split("/")[(int)-2015087398L ^ 0x87E434DB];
                ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Field12715 = "";
                ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS = stringArray[(int)479337782L ^ 0x1C921D37].split("/")[stringArray[(int)1610388620L ^ 0x5FFC948D].split("/").length - (int)((long)2016172743 ^ (long)2016172742)];
                ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Ljc0gDTN8WkwPRHY480HpEkScGALG41A = leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16241.Field16280.Method2925(((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS);
                ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Field12717 = this.Method5436(stringArray[(int)-110966007L ^ 0xF962CB09].split("/")[(int)-1892570942L ^ 0x8F31A8C2], auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field14820);
                if (((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Field12717 != null) {
                    ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).vl3icpcdb9cWvH39NKe3weWQwVdWO7AV = ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Field12717.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS;
                }
                this.Field14200.add((Object)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2);
                System.out.println("Field: official " + ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).vl3icpcdb9cWvH39NKe3weWQwVdWO7AV + ", named " + ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Ljc0gDTN8WkwPRHY480HpEkScGALG41A + ", intermediary " + ((OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS);
            }
            if (!string.startsWith("MD")) continue;
            stringArray = string.replace("MD: ", "").split(" ");
            irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2 = new x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo();
            ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).vl3icpcdb9cWvH39NKe3weWQwVdWO7AV = stringArray[(int)-1922837936L ^ 0x8D63D250].split("/")[(int)((long)-1879218613 ^ (long)-1879218614)];
            ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Field10347 = stringArray[(int)((long)-739627929 ^ (long)-739627930)];
            ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS = stringArray[((int)-783462361L ^ 0xD14D5026) << 1].split("/")[stringArray[(int)((long)1138324544 ^ (long)1138324545) << 1].split("/").length - (int)((long)-128675485 ^ (long)-128675486)];
            ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Ljc0gDTN8WkwPRHY480HpEkScGALG41A = leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16241.Field16280.Method2926(((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS);
            ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Field10350 = this.Method5436(stringArray[(int)((long)1170326068 ^ (long)1170326068)].split("/")[(int)((long)-451412679 ^ (long)-451412679)], auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field14820);
            if (((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Field10350 != null) {
                ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).vl3icpcdb9cWvH39NKe3weWQwVdWO7AV = ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Field10350.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS;
            }
            this.Field14199.add((Object)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2);
            System.out.println("Method: official " + ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).vl3icpcdb9cWvH39NKe3weWQwVdWO7AV + ", named " + ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).Ljc0gDTN8WkwPRHY480HpEkScGALG41A + ", intermediary " + ((x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo)irSM0nCRtSY6ZWq3s5JmlQVvz6scz6TE2).ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS);
        }
    }

    /*
     * Exception decompiling
     */
    public xubZE46GRLM33q2kL5Cp8EKtKVuCQgm6 Method5436(String var1_1, auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: CONTINUE without a while class org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement
         *     at org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement.getTargetStartBlock(GotoStatement.java:102)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement.getStructuredStatement(IfStatement.java:110)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.getStructuredStatementPlaceHolder(Op03SimpleStatement.java:550)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:727)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:306)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:262)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:127)
         *     at java.base/java.lang.Thread.run(Thread.java:833)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public OyVemAom7WJvMzvqs1ycxsl3bSXvkSBj Method5437(String var1_1, String var2_2, auE3dCySxyIc1tKngAVuALlcvYBWsMni$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf var3_3) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: CONTINUE without a while class org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement
         *     at org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement.getTargetStartBlock(GotoStatement.java:102)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement.getStructuredStatement(IfStatement.java:110)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.getStructuredStatementPlaceHolder(Op03SimpleStatement.java:550)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:727)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:306)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:262)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:127)
         *     at java.base/java.lang.Thread.run(Thread.java:833)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public x8LbbvCQGB4o4M1tMsGMFfLlydneLlLo Method5438(String var1_1, String var2_2, auE3dCySxyIc1tKngAVuALlcvYBWsMni$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf var3_3, int var4_4, String var5_5) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: CONTINUE without a while class org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement
         *     at org.benf.cfr.reader.bytecode.analysis.parse.statement.GotoStatement.getTargetStartBlock(GotoStatement.java:102)
         *     at org.benf.cfr.reader.bytecode.analysis.parse.statement.IfStatement.getStructuredStatement(IfStatement.java:110)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.getStructuredStatementPlaceHolder(Op03SimpleStatement.java:550)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:727)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         *     at the.bytecode.club.bytecodeviewer.decompilers.impl.CFRDecompiler.decompileToZip(CFRDecompiler.java:306)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.decompileSaveAll(ResourceDecompiling.java:262)
         *     at the.bytecode.club.bytecodeviewer.resources.ResourceDecompiling.lambda$decompileSaveAll$0(ResourceDecompiling.java:127)
         *     at java.base/java.lang.Thread.run(Thread.java:833)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public List Method5439() {
        return this.Field14198;
    }

    public List Method5440() {
        return this.Field14200;
    }

    public List Method5441() {
        return this.Field14199;
    }

    private static String Method5442(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)1103275708 ^ (long)1103275708);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)50956388L ^ 0x309889B);
            int n2 = (int)((long)329812005 ^ (long)329812166);
            cArray2[n] = (char)(cArray[n] ^ (((int)1690822011L ^ 0x64C7FB80) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

