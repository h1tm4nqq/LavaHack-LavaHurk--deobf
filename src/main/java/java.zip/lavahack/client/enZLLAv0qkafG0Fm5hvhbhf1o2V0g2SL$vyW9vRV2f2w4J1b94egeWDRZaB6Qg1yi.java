/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.luaj.vm2.LuaValue
 *  org.luaj.vm2.lib.LibFunction
 */
package lavahack.client;

import java.awt.Color;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.LibFunction;

class enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi
extends LibFunction {
    private int Field11934;

    enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi() {
    }

    public LuaValue call(LuaValue luaValue, LuaValue luaValue2, LuaValue luaValue3, LuaValue luaValue4) {
        return enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL$vyW9vRV2f2w4J1b94egeWDRZaB6Qg1yi.userdataOf((Object)new Color(luaValue.toint(), luaValue2.toint(), luaValue3.toint(), luaValue4.toint()));
    }
}

