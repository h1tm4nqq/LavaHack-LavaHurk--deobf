/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.util.ArrayList;
import java.util.List;
import lavahack.client.CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt;
import lavahack.client.GAy9jV5JLrUCU1UxQkzXttscRqZTYALl;
import lavahack.client.Gq6OgEUadFqjKDsmcy3j7Wy4KndAfLHO;
import lavahack.client.qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc4;
import lavahack.client.zwWWWaEO7zKr7XG54ZhX4c3PejN1DTzJ;

public class Cc5sotfbW2hLrMhwA1jJ8muyUL0CjjVz
extends zwWWWaEO7zKr7XG54ZhX4c3PejN1DTzJ
implements Gq6OgEUadFqjKDsmcy3j7Wy4KndAfLHO {
    private final List Field13683 = new ArrayList();
    private int Field13684;

    @Override
    public void Method705(GAy9jV5JLrUCU1UxQkzXttscRqZTYALl gAy9jV5JLrUCU1UxQkzXttscRqZTYALl) {
        super.Method705(gAy9jV5JLrUCU1UxQkzXttscRqZTYALl);
        if (this.Field13683.isEmpty()) return;
        this.Field13683.forEach(arg_0 -> Cc5sotfbW2hLrMhwA1jJ8muyUL0CjjVz.Method5060(gAy9jV5JLrUCU1UxQkzXttscRqZTYALl, arg_0));
    }

    @Override
    public void Method706(CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt) {
        super.Method706(cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt);
        if (this.Field13683.isEmpty()) return;
        this.Field13683.forEach(arg_0 -> Cc5sotfbW2hLrMhwA1jJ8muyUL0CjjVz.Method5059(cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt, arg_0));
    }

    @Override
    public void Method710(GAy9jV5JLrUCU1UxQkzXttscRqZTYALl gAy9jV5JLrUCU1UxQkzXttscRqZTYALl) {
        super.Method710(gAy9jV5JLrUCU1UxQkzXttscRqZTYALl);
        if (this.Field13683.isEmpty()) return;
        this.Field13683.forEach(arg_0 -> Cc5sotfbW2hLrMhwA1jJ8muyUL0CjjVz.Method5058(gAy9jV5JLrUCU1UxQkzXttscRqZTYALl, arg_0));
    }

    @Override
    public void Method711(CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt) {
        super.Method711(cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt);
        if (this.Field13683.isEmpty()) return;
        this.Field13683.forEach(arg_0 -> Cc5sotfbW2hLrMhwA1jJ8muyUL0CjjVz.Method5057(cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt, arg_0));
    }

    @Override
    public void Method715(Object object) {
        super.Method715(object);
        if (this.Field13683.isEmpty()) return;
        this.Field13683.forEach(arg_0 -> Cc5sotfbW2hLrMhwA1jJ8muyUL0CjjVz.Method5056(object, arg_0));
    }

    @Override
    public void Method3147(qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc4 qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42) {
        if (this.Field13683.contains(qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42)) return;
        this.Field13683.add(qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42);
    }

    @Override
    public void Method3148(qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc4 qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42) {
        this.Field13683.remove(qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42);
    }

    private static void Method5056(Object object, qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc4 qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42) {
        qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42.Method715(object);
    }

    private static void Method5057(CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt, qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc4 qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42) {
        qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42.Method711(cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt);
    }

    private static void Method5058(GAy9jV5JLrUCU1UxQkzXttscRqZTYALl gAy9jV5JLrUCU1UxQkzXttscRqZTYALl, qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc4 qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42) {
        qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42.Method710(gAy9jV5JLrUCU1UxQkzXttscRqZTYALl);
    }

    private static void Method5059(CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt, qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc4 qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42) {
        qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42.Method706(cWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt);
    }

    private static void Method5060(GAy9jV5JLrUCU1UxQkzXttscRqZTYALl gAy9jV5JLrUCU1UxQkzXttscRqZTYALl, qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc4 qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42) {
        qb1yYFNvzTdeM4b9Rg8oe7A4N8NQcVc42.Method705(gAy9jV5JLrUCU1UxQkzXttscRqZTYALl);
    }
}

