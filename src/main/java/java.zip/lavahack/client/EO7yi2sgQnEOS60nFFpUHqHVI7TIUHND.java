/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.mPNKUHesROKSVtFpAZyhLqRAupt8dodO;
import lavahack.client.pfsG8JbTXjnFvZbRhJLzfGBjgbBi78oW;
import lavahack.client.wVrpt4geN1bZiIzz3Cg8ao4ARNJY2Ej1;

public class EO7yi2sgQnEOS60nFFpUHqHVI7TIUHND
extends pfsG8JbTXjnFvZbRhJLzfGBjgbBi78oW {
    private String Field9358 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public EO7yi2sgQnEOS60nFFpUHqHVI7TIUHND() {
        super(mPNKUHesROKSVtFpAZyhLqRAupt8dodO.Field11930);
    }

    public EO7yi2sgQnEOS60nFFpUHqHVI7TIUHND(wVrpt4geN1bZiIzz3Cg8ao4ARNJY2Ej1 wVrpt4geN1bZiIzz3Cg8ao4ARNJY2Ej12) {
        super(mPNKUHesROKSVtFpAZyhLqRAupt8dodO.Field11930);
        this.Method1621(wVrpt4geN1bZiIzz3Cg8ao4ARNJY2Ej12.Method1618());
    }
}

