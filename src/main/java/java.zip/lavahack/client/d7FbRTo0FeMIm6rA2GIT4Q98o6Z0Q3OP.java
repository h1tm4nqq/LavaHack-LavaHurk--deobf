/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.mmeg18oY4uIMDyPf1InyU6fi9CsvOLTd;

public @interface d7FbRTo0FeMIm6rA2GIT4Q98o6Z0Q3OP {
    public boolean Method2184() default false;

    public mmeg18oY4uIMDyPf1InyU6fi9CsvOLTd Method2185() default @mmeg18oY4uIMDyPf1InyU6fi9CsvOLTd(parents={""});

    public boolean Method2186() default false;

    public boolean Method2187() default false;

    public boolean Method2188() default false;

    public boolean Method2189() default false;
}

