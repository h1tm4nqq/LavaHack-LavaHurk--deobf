//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.util.ResourceLocation
 */
package lavahack.client;

import java.awt.Font;
import java.io.InputStream;
import lavahack.client.BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj;
import lavahack.client.JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk;
import lavahack.client.XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0;
import lavahack.client.XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9;
import lavahack.client.aaIDVwbtzp3KxPpHfK7jnkVMYqAV3lzi;
import lavahack.client.qTretGQGc3EMQ1oiqlGmYy7Xw28i5pmW;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.ResourceLocation;

public class fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj {
    private static final FontRenderer Field13308 = Minecraft.getMinecraft().fontRenderer;
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13309 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-light", ((int)1693054927L ^ 0x64E9F7C0) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13310 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-light", ((int)1953526634L ^ 0x74707363) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13311 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-light", (int)((long)1537597896 ^ (long)1537597895)));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13312 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-light", (int)((long)-185936137 ^ (long)-185936138) << 4));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13313 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-light", ((int)1084445380L ^ 0x40A352C1) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13314 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-bold", (int)((long)753872181 ^ (long)753872188) << 3));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13315 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-bold", (int)-1292347746L ^ 0xB2F856A9));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13316 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-bold", ((int)-1179788985L ^ 0xB9ADD948) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13317 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-bold", ((int)340010835L ^ 0x1444275A) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13318 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-bold", ((int)72476760L ^ 0x451E859) << 4));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13319 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-bold", ((int)666077583L ^ 0x27B3898A) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13320 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-regular", (int)((long)2037655691 ^ (long)2037655684) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13321 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-regular", ((int)-290057951L ^ 0xEEB61128) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13322 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-regular", (int)-432689347L ^ 0xE635AF32));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13323 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("comfortaa-regular", ((int)-564644690L ^ 0xDE5834AB) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13324 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("consolas", (int)((long)-1527764410 ^ (long)-1527764401) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13325 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("consolas", ((int)-1029823985L ^ 0xC29E220E) << 4));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13326 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("consolas", (int)-87872248L ^ 0xFAC32D07));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13327 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("sf-ui", (int)797766164L ^ 0x2F8CF207));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13328 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("sf-ui", (int)((long)-1048488916 ^ (long)-1048488923) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13329 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("futura-normal", ((int)-1217348949L ^ 0xB770BAAE) << 2));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13330 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("futura-normal", (int)((long)-586896594 ^ (long)-586896601) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13331 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("lexenddeca-regular", (int)((long)1162411353 ^ (long)1162411344) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13332 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("main", ((int)1570283209L ^ 0x5D989EC0) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13333 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(new Font("Verdana", (int)-1833249173L ^ 0x92BAD66B, (int)((long)-1348533824 ^ (long)-1348533815) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13334 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("jellee-bold", ((int)1911110036L ^ 0x71E9399D) << 1));
    public static XFDKv2nzCgumb6lLxnd2S4gp8mbth6i0 Field13335 = new JusQ1IZtIMcb8IQYLRTaEmdLvan9Dlhk(fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4739("minecraft", (int)((long)-321342646 ^ (long)-321342649)));
    private int Field13336;

    public static Font Method4739(String string, int n) {
        return fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4740(string, qTretGQGc3EMQ1oiqlGmYy7Xw28i5pmW.Field15543, n);
    }

    public static Font Method4740(String string, qTretGQGc3EMQ1oiqlGmYy7Xw28i5pmW qTretGQGc3EMQ1oiqlGmYy7Xw28i5pmW2, int n) {
        InputStream inputStream = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("font/" + string + ".ttf")).getInputStream();
        Font font = Font.createFont((int)((long)-2112574712 ^ (long)-2112574712), inputStream);
        return font.deriveFont(qTretGQGc3EMQ1oiqlGmYy7Xw28i5pmW2.Method6280(), n);
    }

    public static int Method4741(String string) {
        return XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3256(string);
    }

    public static int Method4742(String string, boolean bl) {
        return XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3255(string, bl);
    }

    public static void Method4743(String string, double d, double d2, int n, boolean bl) {
        if (fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4749()) {
            XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3253(bl).Method760(string, d, d2, n);
            return;
        }
        Field13308.drawString(string, (int)d, (int)d2, n);
    }

    public static int Method4744(String string, double d, double d2, int n) {
        if (!fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4749()) return Field13308.drawString(string, (int)d, (int)d2, n);
        XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3254().Method760(string, d, d2, n);
        return (int)((long)119986209 ^ (long)119986209);
    }

    public static int Method4745(String string, double d, double d2, int n) {
        if (!fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4749()) return Field13308.drawStringWithShadow(string, (float)d, (float)d2, n);
        XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3254().Method748(string, (int)d, (int)d2, n);
        return (int)541082586L ^ 0x204043DA;
    }

    public static void Method4746(String string, double d, double d2, int n) {
        if (fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4749()) {
            XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3254().Method762(string, (int)d, (int)d2, n);
            return;
        }
        Field13308.drawStringWithShadow(string, (float)d - (float)Field13308.getStringWidth(string) / 2.0f, (float)d2, n);
    }

    public static int Method4747(boolean bl) {
        return XvP7gS3PLmwH0ZiDETuLnw1fz7IcbIE9.Field17910.Method3257(bl);
    }

    public static int Method4748() {
        return fG4zHmfoRGE4EaMv1zmxKijeYT9zMfCj.Method4747((boolean)((long)874082524 ^ (long)874082524));
    }

    private static boolean Method4749() {
        return aaIDVwbtzp3KxPpHfK7jnkVMYqAV3lzi.Field16464;
    }

    public static BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj Method4750() {
        return (BmDBjuOmykn9mD97FxXzBnUx0Br6VJYj)aaIDVwbtzp3KxPpHfK7jnkVMYqAV3lzi.Field16465.Field16453.Method341();
    }

    private static String Method4751(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)1916208283 ^ (long)1916208283);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)187957406L ^ 0xB340061);
            int n2 = (int)((long)1878450519 ^ (long)1878450512) << 3;
            cArray2[n] = (char)(cArray[n] ^ (((int)-1926889531L ^ 0x8D25C0F2) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

