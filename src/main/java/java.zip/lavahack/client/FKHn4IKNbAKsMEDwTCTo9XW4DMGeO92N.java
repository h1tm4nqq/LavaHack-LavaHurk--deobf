//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package lavahack.client;

import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import net.minecraft.client.Minecraft;

public class FKHn4IKNbAKsMEDwTCTo9XW4DMGeO92N {
    private static final Minecraft Field16756 = Minecraft.getMinecraft();
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field16757;
    private String Field16758 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method7049() {
        return Field16757;
    }

    static Minecraft Method7050() {
        return Field16756;
    }

    static {
        Class[] classArray = new Class[(int)((long)850804718 ^ (long)850804719) << 1];
        classArray[(int)-96722867L ^ 0xFA3C204D] = Integer.class;
        classArray[(int)1632144762L ^ 0x61488D7B] = Boolean.class;
        Field16757 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, classArray);
    }
}

