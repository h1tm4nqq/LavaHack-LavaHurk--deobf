/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0082\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005\u00a8\u0006\u0006"}, d2={"Lcom/kisman/cc/features/module/Debug/PacketMineProviderTest$Mode;", "", "(Ljava/lang/String;I)V", "PacketMineProvider", "PlayerDamageBlock", "LeftClick", "kisman.cc"})
final class EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends Enum {
    public static final /* enum */ EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field16346;
    public static final /* enum */ EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field16347;
    public static final /* enum */ EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field16348;
    private static final EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] Field16349;
    private String Field16350 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] efE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray = new EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[(int)192745376L ^ 0xB7D0FA3];
        EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] efE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray2 = efE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
        efE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)-2061139926 ^ (long)-2061139926)] = Field16346 = new EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("PacketMineProvider", (int)((long)298898145 ^ (long)298898145));
        efE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)1331487814L ^ 0x4F5CE447] = Field16347 = new EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("PlayerDamageBlock", (int)((long)-1460744849 ^ (long)-1460744850));
        efE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)1701023676 ^ (long)1701023677) << 1] = Field16348 = new EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("LeftClick", ((int)22600349L ^ 0x158DA9C) << 1);
        Field16349 = efE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
        void var2_-1;
        void var1_-1;
    }

    public static EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] values() {
        return (EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[])Field16349.clone();
    }

    public static EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi valueOf(String string) {
        return Enum.valueOf(EfE9qCkc0P1OxItaW7ZiKOJIssmf3wkk$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.class, string);
    }

    private static String Method6841(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-1161354460 ^ (long)-1161354460);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)-1367113204 ^ (long)-1367112973);
            int n2 = ((int)-1147044927L ^ 0xBBA17BC4) << 1;
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)-700493352 ^ (long)-700492945) << 2 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

