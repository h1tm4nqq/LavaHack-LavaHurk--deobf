/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

final class AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV
extends Enum {
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV Field16549 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV("Off", (int)((long)1144986443 ^ (long)1144986443));
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV Field16550 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV("RemoveEntity", (int)2104189816L ^ 0x7D6B6379);
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV Field16551 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV("SetDead", ((int)-275872052L ^ 0xEF8E86CD) << 1);
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV Field16552 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV("Both", (int)((long)-304671343 ^ (long)-304671342));
    private static final AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV[] Field16553;
    private String Field16554 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public static AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV[] values() {
        return (AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV[])Field16553.clone();
    }

    public static AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV valueOf(String string) {
        return Enum.valueOf(AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV.class, string);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV() {
        void var2_-1;
        void var1_-1;
    }

    static {
        AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV[] aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjVArray = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjV[((int)1480084912L ^ 0x58384DB1) << 2];
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjVArray[(int)((long)1538447261 ^ (long)1538447261)] = Field16549;
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjVArray[(int)((long)-6715654 ^ (long)-6715653)] = Field16550;
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjVArray[((int)217018329L ^ 0xCEF6FD8) << 1] = Field16551;
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjVArray[(int)((long)539694223 ^ (long)539694220)] = Field16552;
        Field16553 = aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$UCke3Pxmf8CbZfsSMaRi6TdDNfLAgjjVArray;
    }

    private static String Method6950(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)2130831394L ^ 0x7F01E822;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)-531021373 ^ (long)-531021508);
            int n2 = ((int)77847584L ^ 0x4A3DC5D) << 1;
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)805109726 ^ (long)805101047) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

