/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import com.kisman.cc.event.Event;
import com.kisman.cc.event.Event$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

public class ERDZZaC7E7qEsEwC2UFlE3xI88227PAM
extends Event {
    public qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field15269;
    public String Field15270;
    public Event$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field15271;
    public boolean Field15272;
    private String Field15273 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public ERDZZaC7E7qEsEwC2UFlE3xI88227PAM(qdws5c2TrWCYwByZ0oQUUWIrq72gJscD qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2, String string, Event$leqS0IyKEB621E1SrHdAcHHAUjScjmKi event$leqS0IyKEB621E1SrHdAcHHAUjScjmKi, boolean bl) {
        super(new Object[(int)-1786289908L ^ 0x9587610C]);
        this.Field15269 = qdws5c2TrWCYwByZ0oQUUWIrq72gJscD2;
        this.Field15270 = string;
        this.Field15271 = event$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
        this.Field15272 = bl;
    }
}

