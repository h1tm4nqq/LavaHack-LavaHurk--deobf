//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 */
package lavahack.client;

import kotlin.Metadata;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0011\b\u0002\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0002\u0010\u0004R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b\u00a8\u0006\f"}, d2={"Lcom/kisman/cc/features/module/combat/HandRewrite$Modes;", "", "item", "Lnet/minecraft/item/Item;", "(Ljava/lang/String;ILnet/minecraft/item/Item;)V", "getItem", "()Lnet/minecraft/item/Item;", "None", "Crystal", "Gap", "Totem", "Exp", "kisman.cc"})
public final class adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends Enum {
    public static final /* enum */ adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field16825;
    public static final /* enum */ adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field16826;
    public static final /* enum */ adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field16827;
    public static final /* enum */ adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field16828;
    public static final /* enum */ adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field16829;
    private static final adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] Field16830;
    @Nullable
    private final Item Field16831;
    private String Field16832 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray = new adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[(int)-700752388L ^ 0xD63B5DF9];
        adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray2 = adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
        adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)-840123325L ^ 0xCDECBC43] = Field16825 = new adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("None", (int)19721706L ^ 0x12CEDEA, null);
        adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)156253104 ^ (long)156253105)] = Field16826 = new adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Crystal", (int)((long)-376471301 ^ (long)-376471302), Items.END_CRYSTAL);
        adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[((int)932063982L ^ 0x378E2AEF) << 1] = Field16827 = new adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Gap", ((int)-206561326L ^ 0xF3B01FD3) << 1, Items.GOLDEN_APPLE);
        adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)-594900448 ^ (long)-594900445)] = Field16828 = new adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Totem", (int)((long)-807463498 ^ (long)-807463499), Items.TOTEM_OF_UNDYING);
        adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray[(int)((long)-1631697237 ^ (long)-1631697238) << 2] = Field16829 = new adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi("Exp", (int)((long)-1466752678 ^ (long)-1466752677) << 2, Items.EXPERIENCE_BOTTLE);
        Field16830 = adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKiArray;
    }

    @Nullable
    @Nullable
    public final Item Method7099() {
        return this.Field16831;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
        void var3_1;
        void var2_-1;
        void var1_-1;
        this.Field16831 = var3_1;
    }

    public static adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[] values() {
        return (adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi[])Field16830.clone();
    }

    public static adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi valueOf(String string) {
        return Enum.valueOf(adxKLRUfKrz15cz62FrIMLBHho9GUWzV$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.class, string);
    }

    private static String Method7100(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-478845401 ^ (long)-478845401);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)1898698652 ^ (long)1898698595);
            int n2 = (int)((long)428213790 ^ (long)428213965);
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)1437611606 ^ (long)1437608473) ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

