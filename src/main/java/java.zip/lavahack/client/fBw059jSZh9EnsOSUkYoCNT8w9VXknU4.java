/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.EaPO2tejfzeKFPU19fHIJkdD7KPbX6qP;
import lavahack.client.PBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL;
import lavahack.client.PxnV1NdjGxyN4Clkf4DCZI9zHTzdx6fo;
import lavahack.client.Std84MWzLhfFZ8wdKETeFXiMbDdoeIjj;
import lavahack.client.hS2q7nEd8dHHQz33Sb2fmP8f1QDk01hc;

public class fBw059jSZh9EnsOSUkYoCNT8w9VXknU4
extends Std84MWzLhfFZ8wdKETeFXiMbDdoeIjj {
    private static final int Field17197;
    public static final int Field17198;
    public String Field17199;
    private int Field17200;
    private int Field17201;
    private boolean Field17202;
    private PBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL Field17203;
    private PBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL Field17204;
    private String Field17205 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public fBw059jSZh9EnsOSUkYoCNT8w9VXknU4(EaPO2tejfzeKFPU19fHIJkdD7KPbX6qP eaPO2tejfzeKFPU19fHIJkdD7KPbX6qP, String string, int n, int n2) {
        super(eaPO2tejfzeKFPU19fHIJkdD7KPbX6qP);
        this.Field17200 = n;
        this.Field17201 = n2;
        this.Method688(string);
    }

    public fBw059jSZh9EnsOSUkYoCNT8w9VXknU4(EaPO2tejfzeKFPU19fHIJkdD7KPbX6qP eaPO2tejfzeKFPU19fHIJkdD7KPbX6qP, String string) {
        this(eaPO2tejfzeKFPU19fHIJkdD7KPbX6qP, string, (int)((long)883744735 ^ (long)883744754) << 2, (int)((long)455830076 ^ (long)455830071) << 1);
    }

    @Override
    public void Method668() {
        this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2445(this.leqS0IyKEB621E1SrHdAcHHAUjScjmKi, this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf, this.Method675(), this.Method677(), this.Field17202 ? PxnV1NdjGxyN4Clkf4DCZI9zHTzdx6fo.Field12569 : PxnV1NdjGxyN4Clkf4DCZI9zHTzdx6fo.Field12570);
        this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2446(this.leqS0IyKEB621E1SrHdAcHHAUjScjmKi, this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf, this.Method675(), this.Method677(), 1.0f, this.Field17202 ? (null.Field11804.Method365() ? this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2456() : PxnV1NdjGxyN4Clkf4DCZI9zHTzdx6fo.Field12571) : PxnV1NdjGxyN4Clkf4DCZI9zHTzdx6fo.Field12569);
        if (null.Field11786.Method365()) {
            hS2q7nEd8dHHQz33Sb2fmP8f1QDk01hc.drawRoundedRect((double)(this.leqS0IyKEB621E1SrHdAcHHAUjScjmKi / ((int)((long)-345430480 ^ (long)-345430479) << 1)), (double)(this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf / ((int)((long)-195126185 ^ (long)-195126186) << 1)), (double)((this.leqS0IyKEB621E1SrHdAcHHAUjScjmKi + this.Method675()) / ((int)((long)-177112588 ^ (long)-177112587) << 1)), (double)((this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf + this.Method677()) / ((int)((long)-1782240766 ^ (long)-1782240765) << 1)), this.Field17202 ? (null.Field11804.Method365() ? this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2456() : PxnV1NdjGxyN4Clkf4DCZI9zHTzdx6fo.Field12571) : PxnV1NdjGxyN4Clkf4DCZI9zHTzdx6fo.Field12569, null.Field11788.Method367());
        }
        this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2448(this.leqS0IyKEB621E1SrHdAcHHAUjScjmKi + this.Method675() / ((int)((long)1888762270 ^ (long)1888762271) << 1) - this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2449(this.Field17199) / ((int)((long)174977776 ^ (long)174977777) << 1), this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf + this.Method677() / ((int)((long)1179941095 ^ (long)1179941094) << 1) - this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2450(this.Field17199) / ((int)((long)-357870397 ^ (long)-357870398) << 1), this.Field17199, PxnV1NdjGxyN4Clkf4DCZI9zHTzdx6fo.Field12573);
    }

    @Override
    public void Method669() {
    }

    @Override
    public boolean Method683(int n, int n2, boolean bl) {
        this.Method686(n, n2, bl);
        return ((int)-502228756L ^ 0xE21098EC) != 0;
    }

    private void Method686(int n, int n2, boolean bl) {
        this.Field17202 = !bl && n >= this.leqS0IyKEB621E1SrHdAcHHAUjScjmKi && n2 >= this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf && n <= this.leqS0IyKEB621E1SrHdAcHHAUjScjmKi + this.Method675() && n2 <= this.YlFSugLHQAjzunVBKfamPjSRsvHTy3jf + this.Method677() ? (int)-411811530L ^ 0xE7744137 : (int)-264237163L ^ 0xF0400F95;
    }

    @Override
    public boolean Method684(int n, int n2, int n3, boolean bl) {
        if (n == 0) {
            this.Method686(n2, n3, bl);
            if (!this.Field17202) return ((int)1514826748L ^ 0x5A4A6BFC) != 0;
            if (this.Field17203 == null) return ((int)1514826748L ^ 0x5A4A6BFC) != 0;
            this.Field17203.Method3300();
            return ((int)-1517652383L ^ 0xA58A7660) != 0;
        }
        if (n != (int)((long)1127685532 ^ (long)1127685533)) return ((int)1514826748L ^ 0x5A4A6BFC) != 0;
        this.Method686(n2, n3, bl);
        if (!this.Field17202) return ((int)1514826748L ^ 0x5A4A6BFC) != 0;
        if (this.Field17204 == null) return ((int)1514826748L ^ 0x5A4A6BFC) != 0;
        this.Field17204.Method3300();
        return (int)((long)2008857044 ^ (long)2008857045) != 0;
    }

    public String Method687() {
        return this.Field17199;
    }

    public void Method688(String string) {
        this.Field17199 = string;
        this.Method676(Math.max(this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2449(string), this.Field17200));
        this.Method678(Math.max(this.ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS.Method2450(string) * ((int)140581895L ^ 0x8611C02) / (((int)-1268516684L ^ 0xB463F8B5) << 2), this.Field17201));
    }

    public PBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL Method689() {
        return this.Field17203;
    }

    public void Method690(PBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL pBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL) {
        this.Field17203 = pBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL;
    }

    public PBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL Method691() {
        return this.Field17204;
    }

    public void Method692(PBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL pBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL) {
        this.Field17204 = pBtjwi0ZRCaTfQdYS0S0jZE8Q8rauwqL;
    }

    static {
        Field17198 = ((int)-505126237L ^ 0xE1E462A8) << 1;
        Field17197 = ((int)-1324661991L ^ 0xB10B4334) << 2;
    }
}

