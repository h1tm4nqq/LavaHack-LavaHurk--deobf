/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.luaj.vm2.LuaValue
 *  org.luaj.vm2.lib.LibFunction
 */
package lavahack.client;

import com.kisman.cc.util.vl3icpcdb9cWvH39NKe3weWQwVdWO7AV;
import lavahack.client.zmVsbwAdTVZaRYytJCehCE9v2PCkzpEB;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.LibFunction;

class enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends LibFunction {
    private String Field10818 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL$leqS0IyKEB621E1SrHdAcHHAUjScjmKi() {
    }

    public LuaValue call(LuaValue luaValue, LuaValue luaValue2, LuaValue luaValue3, LuaValue luaValue4) {
        return enZLLAv0qkafG0Fm5hvhbhf1o2V0g2SL$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.userdataOf((Object)new vl3icpcdb9cWvH39NKe3weWQwVdWO7AV(zmVsbwAdTVZaRYytJCehCE9v2PCkzpEB.Method4709(((int)-310141262L ^ 0xED839EAB) << 2, (int)((long)1241279265 ^ (long)1241279288) << 2)).Method3615(luaValue2.tofloat()).Method3611(luaValue3.tofloat()).Method3613(luaValue4.toint()).Method3625());
    }
}

