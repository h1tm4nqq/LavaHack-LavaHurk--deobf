/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package lavahack.client;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.U0aN48ek2FoZNiy3vGHkWmQ1E3Qn8U4n;
import lavahack.client.ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u000f\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\n\u00a2\u0006\u0002\u0010\u000bJ\b\u0010\u0014\u001a\u00020\u0003H\u0016J\b\u0010\u0015\u001a\u00020\u0007H\u0016J\b\u0010\u0016\u001a\u00020\u0007H\u0016J\b\u0010\u0017\u001a\u00020\u0005H\u0016J\b\u0010\u0018\u001a\u00020\nH\u0016J\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\t\u001a\u00020\nH\u0016J\u0010\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\u0010\u0010\u001c\u001a\u00020\u001a2\u0006\u0010\u001d\u001a\u00020\u0007H\u0016J\u0010\u0010\u001e\u001a\u00020\u001a2\u0006\u0010\u0004\u001a\u00020\u0005H\u0016R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\b\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\r\"\u0004\b\u0011\u0010\u000fR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"}, d2={"Lcom/kisman/cc/features/Binder;", "Lcom/kisman/cc/features/module/IBindable;", "name", "", "type", "Lcom/kisman/cc/features/module/BindType;", "key", "", "mouse", "hold", "", "(Ljava/lang/String;Lcom/kisman/cc/features/module/BindType;IIZ)V", "getKey", "()I", "setKey", "(I)V", "getMouse", "setMouse", "getName", "()Ljava/lang/String;", "getButtonName", "getKeyboardKey", "getMouseButton", "getType", "isHold", "setHold", "", "setKeyboardKey", "setMouseButton", "button", "setType", "kisman.cc"})
public final class g2MHw5IDmmZCmUau6MlAGt3iyRVkrrNh
implements U0aN48ek2FoZNiy3vGHkWmQ1E3Qn8U4n {
    @NotNull
    private final String Field16949;
    private ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K Field16950;
    private int Field16951;
    private int Field16952;
    private boolean Field16953;
    private int Field16954;

    @Override
    public int Method8() {
        return this.Field16951;
    }

    @Override
    public void Method9(int n) {
        this.Field16951 = n;
    }

    @Override
    public int Method10() {
        return this.Field16952;
    }

    @Override
    public void Method11(int n) {
        this.Field16952 = n;
    }

    @Override
    @NotNull
    @NotNull
    public ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K Method12() {
        return this.Field16950;
    }

    @Override
    public void Method13(@NotNull @NotNull ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K2) {
        Intrinsics.checkParameterIsNotNull((Object)((Object)ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K2), (String)"type");
        this.Field16950 = ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K2;
    }

    @Override
    public boolean Method14() {
        return this.Field16953;
    }

    @Override
    public void Method15(boolean bl) {
        this.Field16953 = bl;
    }

    @Override
    @NotNull
    @NotNull
    public String Method16() {
        return this.Field16949;
    }

    @NotNull
    @NotNull
    public final String Method7178() {
        return this.Field16949;
    }

    public final int Method7179() {
        return this.Field16951;
    }

    public final void Method7180(int n) {
        this.Field16951 = n;
    }

    public final int Method7181() {
        return this.Field16952;
    }

    public final void Method7182(int n) {
        this.Field16952 = n;
    }

    public g2MHw5IDmmZCmUau6MlAGt3iyRVkrrNh(@NotNull @NotNull String string, @NotNull @NotNull ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K2, int n, int n2, boolean bl) {
        Intrinsics.checkParameterIsNotNull((Object)string, (String)"name");
        Intrinsics.checkParameterIsNotNull((Object)((Object)ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K2), (String)"type");
        this.Field16949 = string;
        this.Field16950 = ucrr2PAxIgRz5eGlrtTOTP7pMQa9Df1K2;
        this.Field16951 = n;
        this.Field16952 = n2;
        this.Field16953 = bl;
    }

    private static String Method7183(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)585189728 ^ (long)585189728);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)-1914096659 ^ (long)-1914096878);
            int n2 = (int)73861556L ^ 0x4670977;
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)-1769772991 ^ (long)-1769775236) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

