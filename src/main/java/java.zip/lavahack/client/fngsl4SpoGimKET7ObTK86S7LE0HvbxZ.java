//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher
 *  net.minecraft.entity.Entity
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.util.math.Vec3d
 */
package lavahack.client;

import lavahack.client.Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC;
import lavahack.client.dHW1jZK49fXgBu9AY91BXDMHsTGGza8u;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs;
import lavahack.client.hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.Vec3d;

public class fngsl4SpoGimKET7ObTK86S7LE0HvbxZ {
    private static final Minecraft Field12703 = Minecraft.getMinecraft();
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field12704;
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field12705;
    private static final hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field12706;
    private String Field12707 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    private static void Method4328(Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC) {
        Vec3d vec3d = dHW1jZK49fXgBu9AY91BXDMHsTGGza8u.Method2103((Entity)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)((long)-738021979 ^ (long)-738021980)), ((Float)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)1994763899L ^ 0x76E5AE7B)).floatValue());
        Field12703.getRenderManager().getEntityRenderObject((Entity)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)-1484601756L ^ 0xA782C665)).doRender((Entity)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)-2111027967L ^ 0x822C4500), vec3d.x, vec3d.y, vec3d.z, ((Entity)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)((int)((long)-373183296 ^ (long)-373183295)))).rotationYaw, ((Float)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)-1256671122L ^ 0xB518B86E)).floatValue());
    }

    private static void Method4329(Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC) {
        TileEntityRendererDispatcher.instance.render((TileEntity)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)((long)-854114434 ^ (long)-854114433)), (double)((TileEntity)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)((long)1224604884 ^ (long)1224604885))).getPos().getX() - fngsl4SpoGimKET7ObTK86S7LE0HvbxZ.Field12703.renderManager.renderPosX, (double)((TileEntity)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)((long)-553859146 ^ (long)-553859145))).getPos().getY() - fngsl4SpoGimKET7ObTK86S7LE0HvbxZ.Field12703.renderManager.renderPosY, (double)((TileEntity)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)((long)-1002610705 ^ (long)-1002610706))).getPos().getZ() - fngsl4SpoGimKET7ObTK86S7LE0HvbxZ.Field12703.renderManager.renderPosZ, ((Float)z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC.Method2054((int)((long)1206341009 ^ (long)1206341009))).floatValue());
    }

    static hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method4330() {
        return Field12704;
    }

    static hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method4331() {
        return Field12705;
    }

    static hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method4332() {
        return Field12706;
    }

    static void Method4333(Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC) {
        fngsl4SpoGimKET7ObTK86S7LE0HvbxZ.Method4329(z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC);
    }

    static void Method4334(Z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC) {
        fngsl4SpoGimKET7ObTK86S7LE0HvbxZ.Method4328(z557Xkt0AW4jCvkPSKwfIN0oRCjfHldC);
    }

    static Minecraft Method4335() {
        return Field12703;
    }

    static {
        Class[] classArray = new Class[(int)((long)-2093207536 ^ (long)-2093207535)];
        classArray[(int)((long)-857498675 ^ (long)-857498675)] = Float.class;
        Field12704 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, classArray);
        Class[] classArray2 = new Class[((int)-482495332L ^ 0xE33DB49D) << 1];
        classArray2[(int)((long)1327027354 ^ (long)1327027354)] = Float.class;
        classArray2[(int)2092626982L ^ 0x7CBAF427] = Entity.class;
        Field12705 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, classArray2);
        Class[] classArray3 = new Class[(int)((long)2078612398 ^ (long)2078612399) << 1];
        classArray3[(int)-648746286L ^ 0xD954EAD2] = Float.class;
        classArray3[(int)((long)267610287 ^ (long)267610286)] = Entity.class;
        Field12706 = hFi9sJW27NhKFOb6I9Bpx6sOKiwsbeRs.Method1727(Void.class, classArray3);
    }
}

