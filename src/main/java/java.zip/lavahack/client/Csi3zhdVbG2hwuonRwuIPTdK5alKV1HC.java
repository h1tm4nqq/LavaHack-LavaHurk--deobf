/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public class Csi3zhdVbG2hwuonRwuIPTdK5alKV1HC
extends Exception {
    private String Field17118 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public Csi3zhdVbG2hwuonRwuIPTdK5alKV1HC(String string) {
        super(string);
    }

    public Csi3zhdVbG2hwuonRwuIPTdK5alKV1HC(Throwable throwable) {
        super(throwable);
    }
}

