/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import java.util.function.Supplier;
import kotlin.Metadata;
import lavahack.client.DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU;
import lavahack.client.k2xS3X9Hiu97q1kXmWdLuKIc9dhkROz8;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=3, d1={"\u0000\b\n\u0000\n\u0002\u0010\u000b\n\u0000\u0010\u0000\u001a\u00020\u0001H\n\u00a2\u0006\u0002\b\u0002"}, d2={"<anonymous>", "", "get"})
final class DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf
implements Supplier {
    final DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU Field17376;
    private String Field17377 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public Object get() {
        return this.Method7535();
    }

    public final boolean Method7535() {
        int n;
        if (this.Field17376.Method2735().Method341() != k2xS3X9Hiu97q1kXmWdLuKIc9dhkROz8.Field11309 && this.Field17376.Method2735().Method341() != k2xS3X9Hiu97q1kXmWdLuKIc9dhkROz8.Field11316) {
            n = (int)((long)-878051739 ^ (long)-878051740);
            return n != 0;
        }
        n = (int)-1449615500L ^ 0xA9989F74;
        return n != 0;
    }

    DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf(DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU dZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU) {
        this.Field17376 = dZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU;
    }
}

