/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 */
package lavahack.client;

import com.kisman.cc.event.Event;
import net.minecraft.item.ItemStack;

public class ahJMkUtzzEf7tJjbemx3021mGngs1J3z
extends Event {
    public ItemStack Field9200;
    public int Field9201;
    public int Field9202;
    private int Field9203;

    public ahJMkUtzzEf7tJjbemx3021mGngs1J3z(ItemStack itemStack, int n, int n2) {
        super(new Object[(int)((long)-1209006535 ^ (long)-1209006535)]);
        this.Field9200 = itemStack;
        this.Field9201 = n;
        this.Field9202 = n2;
    }
}

