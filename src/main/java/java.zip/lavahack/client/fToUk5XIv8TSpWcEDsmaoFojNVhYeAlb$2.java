/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import lavahack.client.fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb;
import lavahack.client.paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF;

class fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb$2
implements ActionListener {
    final paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF Field13124;
    final fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb Field13125;
    private int Field13126;

    fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb$2(fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb2, paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF2) {
        this.Field13125 = fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb2;
        this.Field13124 = paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF2;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        this.Field13124.Method5023();
    }
}

