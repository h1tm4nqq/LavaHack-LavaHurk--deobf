/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import java.util.function.Supplier;
import kotlin.Metadata;
import lavahack.client.DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU;
import lavahack.client.k2xS3X9Hiu97q1kXmWdLuKIc9dhkROz8;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=3, d1={"\u0000\b\n\u0000\n\u0002\u0010\u000b\n\u0000\u0010\u0000\u001a\u00020\u0001H\n\u00a2\u0006\u0002\b\u0002"}, d2={"<anonymous>", "", "get"})
final class DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
implements Supplier {
    final DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU Field8241;
    private int Field8242;

    public Object get() {
        return this.Method659();
    }

    public final boolean Method659() {
        int n;
        if (this.Field8241.Method2735().Method341() != k2xS3X9Hiu97q1kXmWdLuKIc9dhkROz8.Field11316 && this.Field8241.Method2735().Method341() != k2xS3X9Hiu97q1kXmWdLuKIc9dhkROz8.Field11318 && this.Field8241.Method2735().Method341() != k2xS3X9Hiu97q1kXmWdLuKIc9dhkROz8.Field11319) {
            n = (int)1485183126L ^ 0x58861896;
            return n != 0;
        }
        n = (int)((long)743603324 ^ (long)743603325);
        return n != 0;
    }

    DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(DZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU dZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU) {
        this.Field8241 = dZhxCGAc8sX8Q52Jr3RJX2HnqL7CzxkU;
    }
}

