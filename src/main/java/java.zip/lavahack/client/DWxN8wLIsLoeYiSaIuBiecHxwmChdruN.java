/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumHandSide
 */
package lavahack.client;

import com.kisman.cc.event.Event;
import net.minecraft.util.EnumHandSide;

public class DWxN8wLIsLoeYiSaIuBiecHxwmChdruN
extends Event {
    public final EnumHandSide Field15600;
    public final float Field15601;
    private String Field15602 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public DWxN8wLIsLoeYiSaIuBiecHxwmChdruN(EnumHandSide enumHandSide, float f) {
        super(new Object[(int)-915611954L ^ 0xC96CDECE]);
        this.Field15600 = enumHandSide;
        this.Field15601 = f;
    }
}

