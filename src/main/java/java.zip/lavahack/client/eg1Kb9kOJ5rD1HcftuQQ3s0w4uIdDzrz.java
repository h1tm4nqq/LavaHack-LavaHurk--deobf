/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.util.function.Predicate;
import lavahack.client.A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt;
import lavahack.client.F3RUJ4pqKqExz7WB5oipQI42Y4NfLlLa;
import lavahack.client.WjjBVRrUqJUKhloA7ANknrTEODhuGa0J;
import lavahack.client.WkowkMIYywGBZ1LvpVpVCHmyCihJiruH;
import lavahack.client.leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P;
import lavahack.client.qdws5c2TrWCYwByZ0oQUUWIrq72gJscD;

public class eg1Kb9kOJ5rD1HcftuQQ3s0w4uIdDzrz
extends WjjBVRrUqJUKhloA7ANknrTEODhuGa0J {
    private final qdws5c2TrWCYwByZ0oQUUWIrq72gJscD Field12397 = this.Method23(new qdws5c2TrWCYwByZ0oQUUWIrq72gJscD("Compatibility", (WjjBVRrUqJUKhloA7ANknrTEODhuGa0J)this, (boolean)((long)-25382023 ^ (long)-25382023)));
    @F3RUJ4pqKqExz7WB5oipQI42Y4NfLlLa
    private final CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt Field12398 = new CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt(WkowkMIYywGBZ1LvpVpVCHmyCihJiruH::Method158, new Predicate[(int)71697393L ^ 0x44603F1]);
    @F3RUJ4pqKqExz7WB5oipQI42Y4NfLlLa
    private final CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt Field12399 = new CWbHmUEXMBlBn6yy1FNsdHDsxUN4RrYt(this::Method4121, new Predicate[(int)-1904352648L ^ 0x8E7DE278]);
    private String Field12400 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public eg1Kb9kOJ5rD1HcftuQQ3s0w4uIdDzrz() {
        super("NoPing", qQsb6s7p9s2mO0qNTfMhaY3YQsyB7U4P.Field8343, ((int)-2009467039L ^ 0x8839F760) != 0);
    }

    @Override
    public void Method38() {
        super.Method38();
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method705(this);
    }

    @Override
    public void Method39() {
        super.Method39();
        leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field16242.Method710(this);
    }

    private void Method4121(A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB$leqS0IyKEB621E1SrHdAcHHAUjScjmKi a50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB$leqS0IyKEB621E1SrHdAcHHAUjScjmKi) {
        if (!this.Field12397.Method365()) return;
        a50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Method158();
    }

    private static String Method57(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-1891285253 ^ (long)-1891285253);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)2036946345 ^ (long)2036946262);
            int n2 = (int)((long)1065550891 ^ (long)1065550904) << 1;
            cArray2[n] = (char)(cArray[n] ^ ((int)661770560L ^ 0x2771C121 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

