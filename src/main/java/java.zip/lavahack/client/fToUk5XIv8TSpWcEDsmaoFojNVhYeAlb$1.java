/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import lavahack.client.fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb;
import lavahack.client.paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF;

class fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb$1
implements ActionListener {
    final paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF Field13131;
    final fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb Field13132;
    private int Field13133;

    fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb$1(fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb2, paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF2) {
        this.Field13132 = fToUk5XIv8TSpWcEDsmaoFojNVhYeAlb2;
        this.Field13131 = paYMcmWOiGqKfUxhe7rFt8jRbDJD9ksF2;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        this.Field13131.Method5021();
    }
}

