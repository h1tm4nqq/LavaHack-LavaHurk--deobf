/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import com.kisman.cc.event.Event;

public class agYEaptPUW8OPC6jB7DK1WZuIoCKRIex
extends Event {
    private String Field11209 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public agYEaptPUW8OPC6jB7DK1WZuIoCKRIex() {
        super(new Object[(int)1666483238L ^ 0x63548426]);
    }
}

