/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;
import lavahack.client.KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$1;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$2;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$3;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$4;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$5;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$6;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$7;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$8;
import lavahack.client.aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\b\u0086\u0001\u0018\u0000 \u000f2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000fB\u000f\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000e\u00a8\u0006\u0010"}, d2={"Lcom/kisman/cc/features/module/movement/speed/SpeedModes;", "", "mode", "Lcom/kisman/cc/features/module/movement/speed/ISpeedMode;", "(Ljava/lang/String;ILcom/kisman/cc/features/module/movement/speed/ISpeedMode;)V", "getMode", "()Lcom/kisman/cc/features/module/movement/speed/ISpeedMode;", "Strafe", "YPort", "StrafeNew", "MatrixBhop", "MatrixStrafe", "Bhop", "Strafe2", "Matrix", "Companion", "kisman.cc"})
public final class aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8
extends Enum {
    public static final /* enum */ aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 Field12092;
    public static final /* enum */ aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 Field12093;
    public static final /* enum */ aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 Field12094;
    public static final /* enum */ aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 Field12095;
    public static final /* enum */ aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 Field12096;
    public static final /* enum */ aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 Field12097;
    public static final /* enum */ aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 Field12098;
    public static final /* enum */ aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 Field12099;
    private static final aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8[] Field12100;
    @NotNull
    private final KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l Field12101;
    public static final aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field12102;
    private String Field12103 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8[] aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8[((int)1114427358L ^ 0x426CCFDF) << 3];
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8[] aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array2 = aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array;
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array[(int)-2035709104L ^ 0x86A98B50] = Field12092 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8("Strafe", (int)-1739905934L ^ 0x984B2472, (KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l)new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$1());
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array[(int)((long)-1022983159 ^ (long)-1022983160)] = Field12093 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8("YPort", (int)2014872609L ^ 0x78188420, (KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l)new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$2());
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array[(int)((long)-69791025 ^ (long)-69791026) << 1] = Field12094 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8("StrafeNew", ((int)-71997451L ^ 0xFBB567F4) << 1, (KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l)new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$3());
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array[(int)-476776169L ^ 0xE394F914] = Field12095 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8("MatrixBhop", (int)((long)401309688 ^ (long)401309691), (KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l)new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$4());
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array[(int)((long)-543695999 ^ (long)-543696000) << 2] = Field12096 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8("MatrixStrafe", ((int)-570306011L ^ 0xDE01D224) << 2, (KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l)new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$5());
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array[(int)((long)-1720008072 ^ (long)-1720008067)] = Field12097 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8("Bhop", (int)-437653066L ^ 0xE5E9F1B3, (KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l)new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$6());
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array[((int)-1886370601L ^ 0x8F9044D4) << 1] = Field12098 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8("Strafe2", (int)((long)33427341 ^ (long)33427342) << 1, (KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l)new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$7());
        aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array[(int)-1625385166L ^ 0x9F1E9735] = Field12099 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8("Matrix", (int)((long)1425478427 ^ (long)1425478428), (KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l)new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$8());
        Field12100 = aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8Array;
        Field12102 = new aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(null);
    }

    @NotNull
    @NotNull
    public final KERrE2LuaTOrvMyD8cdKgzP1mK1VMR0l Method3949() {
        return this.Field12101;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8() {
        void var3_1;
        void var2_-1;
        void var1_-1;
        this.Field12101 = var3_1;
    }

    public static aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8[] values() {
        return (aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8[])Field12100.clone();
    }

    public static aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8 valueOf(String string) {
        return Enum.valueOf(aDmeYUB2VnDg9d9L01Dcca8IRra9cIH8.class, string);
    }

    private static String Method3950(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)1950447569 ^ (long)1950447569);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-69294335L ^ 0xFBDEA7FE);
            int n2 = (int)((long)-1737569244 ^ (long)-1737569103);
            cArray2[n] = (char)(cArray[n] ^ (((int)949295991L ^ 0x389518F4) << 5 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

