/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public class CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends Exception {
    private String Field15553 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public CDWHmkIq5Vhw2D8gJFTTN37eVgbQx2bA$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(String string, Object ... objectArray) {
        super(String.format(string, objectArray));
    }
}

