/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.BufferBuilder
 */
package lavahack.client;

import lavahack.client.fUZKfctezG345L0QhxwhtNsgI8JBzBFm;
import net.minecraft.client.renderer.BufferBuilder;

interface fUZKfctezG345L0QhxwhtNsgI8JBzBFm$leqS0IyKEB621E1SrHdAcHHAUjScjmKi {
    public void Method2767(fUZKfctezG345L0QhxwhtNsgI8JBzBFm var1, BufferBuilder var2, Object ... var3);
}

