/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.RIhfMBGyAK9DkxAEjgwAXL20KiC6veIl;

public interface DH1H695Ac7tbIgJH29mL6vYZdjYnf9BH {
    public void Method2144(RIhfMBGyAK9DkxAEjgwAXL20KiC6veIl var1);

    public RIhfMBGyAK9DkxAEjgwAXL20KiC6veIl Method2145();
}

