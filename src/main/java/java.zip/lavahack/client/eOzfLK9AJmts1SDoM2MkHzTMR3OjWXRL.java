/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public class eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL
extends Exception {
    private static final long Field7913 = 0x33CA2AE9AF8EDAE7L & 0x33CA2AE9AF9EDEC6L;
    private final int Field7914;
    private String Field7915 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL(int n) {
        this.Field7914 = n;
    }

    public eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL(int n, String string) {
        super(string);
        this.Field7914 = n;
    }

    public eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL(int n, Throwable throwable) {
        super(throwable);
        this.Field7914 = n;
    }

    public eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL(int n, String string, Throwable throwable) {
        super(string, throwable);
        this.Field7914 = n;
    }

    public int Method192() {
        return this.Field7914;
    }
}

