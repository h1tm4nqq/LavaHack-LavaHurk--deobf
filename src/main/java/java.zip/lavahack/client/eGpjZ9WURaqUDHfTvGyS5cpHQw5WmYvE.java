/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;
import lavahack.client.abbi5WXwBhAC2jwfVuZJg478P13czAOh;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=3)
public final class eGpjZ9WURaqUDHfTvGyS5cpHQw5WmYvE {
    public static final int[] Field11549 = new int[abbi5WXwBhAC2jwfVuZJg478P13czAOh.values().length];
    private int Field11550;

    static {
        eGpjZ9WURaqUDHfTvGyS5cpHQw5WmYvE.Field11549[abbi5WXwBhAC2jwfVuZJg478P13czAOh.Field17489.ordinal()] = (int)((long)-1035950720 ^ (long)-1035950719);
        eGpjZ9WURaqUDHfTvGyS5cpHQw5WmYvE.Field11549[abbi5WXwBhAC2jwfVuZJg478P13czAOh.Field17490.ordinal()] = (int)((long)1189794887 ^ (long)1189794886) << 1;
        eGpjZ9WURaqUDHfTvGyS5cpHQw5WmYvE.Field11549[abbi5WXwBhAC2jwfVuZJg478P13czAOh.Field17491.ordinal()] = (int)-1913572640L ^ 0x8DF132E3;
        eGpjZ9WURaqUDHfTvGyS5cpHQw5WmYvE.Field11549[abbi5WXwBhAC2jwfVuZJg478P13czAOh.Field17492.ordinal()] = ((int)-212644771L ^ 0xF3534C5C) << 2;
    }
}

