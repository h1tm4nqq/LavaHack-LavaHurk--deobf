/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public final class eFEpfCAesya7Iz2wWcyO3vTwaFs0zBbe$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf {
    public static final int Field11125;
    public static final int Field11126;
    public static final int Field11127;
    public static final int Field11128;
    public static final int Field11129;
    public static final int Field11130;
    public static final int Field11131;
    private String Field11132 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        Field11131 = (int)((long)1397598972 ^ (long)1397598915);
        Field11130 = (int)((long)-1557149675 ^ (long)-1557149676) << 5;
        Field11129 = ((int)-1948300032L ^ 0x8BDF4D01) << 4;
        Field11128 = ((int)587744096L ^ 0x23084361) << 3;
        Field11127 = ((int)-1368293243L ^ 0xAE718084) << 2;
        Field11126 = ((int)-1089325445L ^ 0xBF12367A) << 1;
        Field11125 = (int)((long)830406823 ^ (long)830406822);
    }
}

