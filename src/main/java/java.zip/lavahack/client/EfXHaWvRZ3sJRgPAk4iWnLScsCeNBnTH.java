/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import kotlin.Metadata;

@Retention(value=RetentionPolicy.RUNTIME)
@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u001b\n\u0000\b\u0086\u0002\u0018\u00002\u00020\u0001B\u0000\u00a8\u0006\u0002"}, d2={"Lcom/kisman/cc/features/subsystem/subsystems/Targetable;", "", "kisman.cc"})
public @interface EfXHaWvRZ3sJRgPAk4iWnLScsCeNBnTH {
}

