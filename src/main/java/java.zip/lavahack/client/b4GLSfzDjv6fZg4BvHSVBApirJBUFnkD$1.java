/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$t8Zz9kLYOvPClkfi3gawfSO9zXOPwv4r;

class b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$1 {
    static final int[] Field16113 = new int[b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$t8Zz9kLYOvPClkfi3gawfSO9zXOPwv4r.values().length];
    private String Field16114 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$1.Field16113[b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$t8Zz9kLYOvPClkfi3gawfSO9zXOPwv4r.Field15749.ordinal()] = (int)((long)-1694184663 ^ (long)-1694184664);
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$1.Field16113[b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$t8Zz9kLYOvPClkfi3gawfSO9zXOPwv4r.Field15750.ordinal()] = ((int)605478650L ^ 0x2416DEFB) << 1;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$1.Field16113[b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$t8Zz9kLYOvPClkfi3gawfSO9zXOPwv4r.Field15751.ordinal()] = (int)1302368809L ^ 0x4DA0922A;
    }
}

