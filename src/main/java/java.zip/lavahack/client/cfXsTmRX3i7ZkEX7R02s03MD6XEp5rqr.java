/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import com.kisman.cc.event.Event;

public class cfXsTmRX3i7ZkEX7R02s03MD6XEp5rqr
extends Event {
    double Field14778;
    double Field14779;
    double Field14780;
    double Field14781;
    double Field14782;
    double Field14783;
    double Field14784;
    double Field14785;
    double Field14786;
    double Field14787;
    double Field14788;
    double Field14789;
    double Field14790;
    double Field14791;
    double Field14792;
    double Field14793;
    double Field14794;
    double Field14795;
    double Field14796;
    double Field14797;
    private String Field14798 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public cfXsTmRX3i7ZkEX7R02s03MD6XEp5rqr(double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8, double d9, double d10, double d11, double d12, double d13, double d14, double d15, double d16, double d17, double d18, double d19, double d20) {
        super(new Object[(int)-1250836020L ^ 0xB571C1CC]);
        this.Field14778 = d;
        this.Field14779 = d2;
        this.Field14780 = d3;
        this.Field14781 = d4;
        this.Field14782 = d5;
        this.Field14783 = d6;
        this.Field14784 = d7;
        this.Field14785 = d8;
        this.Field14786 = d9;
        this.Field14787 = d10;
        this.Field14788 = d11;
        this.Field14789 = d12;
        this.Field14790 = d13;
        this.Field14791 = d14;
        this.Field14792 = d15;
        this.Field14793 = d16;
        this.Field14794 = d17;
        this.Field14795 = d18;
        this.Field14796 = d19;
        this.Field14797 = d20;
    }

    public void Method5772(double d) {
        this.Field14778 = d;
    }

    public void Method5773(double d) {
        this.Field14779 = d;
    }

    public void Method5774(double d) {
        this.Field14780 = d;
    }

    public void Method5775(double d) {
        this.Field14781 = d;
    }

    public void Method5776(double d) {
        this.Field14782 = d;
    }

    public void Method5777(double d) {
        this.Field14783 = d;
    }

    public void Method5778(double d) {
        this.Field14788 = d;
    }

    public void Method5779(double d) {
        this.Field14789 = d;
    }

    public void Method5780(double d) {
        this.Field14790 = d;
    }

    public void Method5781(double d) {
        this.Field14791 = d;
    }

    public void Method5782(double d) {
        this.Field14784 = d;
    }

    public void Method5783(double d) {
        this.Field14785 = d;
    }

    public void Method5784(double d) {
        this.Field14786 = d;
    }

    public void Method5785(double d) {
        this.Field14787 = d;
    }

    public void Method5786(double d) {
        this.Field14792 = d;
    }

    public void Method5787(double d) {
        this.Field14793 = d;
    }

    public void Method5788(double d) {
        this.Field14794 = d;
    }

    public void Method5789(double d) {
        this.Field14795 = d;
    }

    public void Method5790(double d) {
        this.Field14796 = d;
    }

    public void Method5791(double d) {
        this.Field14797 = d;
    }

    public double Method5792() {
        return this.Field14778;
    }

    public double Method5793() {
        return this.Field14779;
    }

    public double Method5794() {
        return this.Field14780;
    }

    public double Method5795() {
        return this.Field14781;
    }

    public double Method5796() {
        return this.Field14782;
    }

    public double Method5797() {
        return this.Field14783;
    }

    public double Method5798() {
        return this.Field14784;
    }

    public double Method5799() {
        return this.Field14785;
    }

    public double Method5800() {
        return this.Field14786;
    }

    public double Method5801() {
        return this.Field14787;
    }

    public double Method5802() {
        return this.Field14788;
    }

    public double Method5803() {
        return this.Field14789;
    }

    public double Method5804() {
        return this.Field14790;
    }

    public double Method5805() {
        return this.Field14791;
    }

    public double Method5806() {
        return this.Field14792;
    }

    public double Method5807() {
        return this.Field14793;
    }

    public double Method5808() {
        return this.Field14794;
    }

    public double Method5809() {
        return this.Field14795;
    }

    public double Method5810() {
        return this.Field14796;
    }

    public double Method5811() {
        return this.Field14797;
    }
}

