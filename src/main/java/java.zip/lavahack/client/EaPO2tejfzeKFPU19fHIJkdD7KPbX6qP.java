/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.awt.Color;

public interface EaPO2tejfzeKFPU19fHIJkdD7KPbX6qP {
    public void Method2444(float var1, float var2, int var3, int var4);

    public void Method2445(double var1, double var3, double var5, double var7, Color var9);

    public void Method2446(double var1, double var3, double var5, double var7, float var9, Color var10);

    public void Method2447(Color var1);

    public void Method2448(int var1, int var2, String var3, Color var4);

    public int Method2449(String var1);

    public int Method2450(String var1);

    public void Method2451(double var1, double var3, double var5, double var7, double var9, double var11, Color var13);

    public void Method2452();

    public void Method2453();

    public void Method2454();

    public int Method2455();

    public Color Method2456();
}

