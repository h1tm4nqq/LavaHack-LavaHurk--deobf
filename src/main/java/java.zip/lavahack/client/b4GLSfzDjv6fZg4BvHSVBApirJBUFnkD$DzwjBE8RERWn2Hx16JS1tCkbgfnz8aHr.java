/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public final class b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr
extends Enum {
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr Field8392 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr("None", (int)((long)365550083 ^ (long)365550083));
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr Field8393 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr("Normal", (int)((long)320408832 ^ (long)320408833));
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr Field8394 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr("Silent", ((int)327129313L ^ 0x137F98E0) << 1);
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr Field8395 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr("Smart", (int)-1676988914L ^ 0x9C0B2E0D);
    private static final b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr[] Field8396;
    private String Field8397 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public static b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr[] values() {
        return (b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr[])Field8396.clone();
    }

    public static b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr valueOf(String string) {
        return Enum.valueOf(b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr.class, string);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr() {
        void var2_-1;
        void var1_-1;
    }

    static {
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr[] b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHrArray = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHr[((int)955107555L ^ 0x38EDC8E2) << 2];
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHrArray[(int)((long)-1437940897 ^ (long)-1437940897)] = Field8392;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHrArray[(int)2131535186L ^ 0x7F0CA553] = Field8393;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHrArray[(int)((long)-1346375658 ^ (long)-1346375657) << 1] = Field8394;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHrArray[(int)((long)1201292687 ^ (long)1201292684)] = Field8395;
        Field8396 = b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DzwjBE8RERWn2Hx16JS1tCkbgfnz8aHrArray;
    }

    private static String Method828(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)1759548586 ^ (long)1759548586);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-1619998933L ^ 0x9F70C7D4);
            int n2 = ((int)1802858773L ^ 0x6B75713A) << 1;
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)116404274 ^ (long)116404275) << 8 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

