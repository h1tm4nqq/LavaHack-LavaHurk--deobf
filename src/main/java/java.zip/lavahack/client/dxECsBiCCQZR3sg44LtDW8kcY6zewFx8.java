/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.TDrOJYGYE6GxbjOEblLxwsKQtY1HZZvO;

public abstract class dxECsBiCCQZR3sg44LtDW8kcY6zewFx8 {
    protected final String Field10037;
    protected final String Field10038;
    protected final TDrOJYGYE6GxbjOEblLxwsKQtY1HZZvO Field10039;
    protected boolean Field10040;
    private int Field10041;

    public dxECsBiCCQZR3sg44LtDW8kcY6zewFx8(String string, String string2, TDrOJYGYE6GxbjOEblLxwsKQtY1HZZvO tDrOJYGYE6GxbjOEblLxwsKQtY1HZZvO) {
        this.Field10037 = string;
        this.Field10038 = string2;
        this.Field10039 = tDrOJYGYE6GxbjOEblLxwsKQtY1HZZvO;
        this.Field10040 = (int)((long)703608664 ^ (long)703608664);
    }

    public String Method2259() {
        return this.Field10037;
    }

    public String Method2260() {
        return this.Field10038;
    }

    public TDrOJYGYE6GxbjOEblLxwsKQtY1HZZvO Method2261() {
        return this.Field10039;
    }

    public final void Method2262() {
        this.Field10040 = (int)-1953388602L ^ 0x8B91A7C7;
        this.Method2267();
    }

    public final void Method2263() {
        this.Field10040 = (int)((long)-945986907 ^ (long)-945986907);
        this.Method2268();
    }

    public boolean Method2264() {
        return this.Field10040;
    }

    public boolean Method2265() {
        boolean bl;
        if (!this.Field10040) {
            bl = (int)241734761L ^ 0xE689468;
            return bl;
        }
        bl = (int)-331859102L ^ 0xEC383B62;
        return bl;
    }

    protected void Method2266() {
        if (this.Field10040) {
            return;
        }
        this.Field10039.Method4692();
    }

    protected void Method2267() {
    }

    protected void Method2268() {
    }
}

