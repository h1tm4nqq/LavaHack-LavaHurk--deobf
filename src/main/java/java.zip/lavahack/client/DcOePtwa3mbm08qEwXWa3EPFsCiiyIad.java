//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.util.text.TextFormatting
 */
package lavahack.client;

import com.kisman.cc.util.Ljc0gDTN8WkwPRHY480HpEkScGALG41A;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.ABhseIFL1PQVX4WAovmpeO8P6T0dQPpk;
import lavahack.client.DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import lavahack.client.DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.NCAK0sFLWmP0xBxkwWzF2T1bn3cRmhqs;
import lavahack.client.cZ4bypSRWV3YzaQMwmpKCiS4RsRbKd08;
import lavahack.client.leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import net.minecraft.util.text.TextFormatting;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\b&\u0018\u0000 \n2\u00020\u0001:\u0002\n\u000bB\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\u0010\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\u0010\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\u0012\u0010\b\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0016J\u0010\u0010\t\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016\u00a8\u0006\f"}, d2={"Lcom/kisman/cc/util/chat/ChatHandler;", "", "()V", "complete", "", "message", "", "error", "print", "warning", "Companion", "Instance", "kisman.cc"})
public abstract class DcOePtwa3mbm08qEwXWa3EPFsCiiyIad {
    @NotNull
    private static final DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field15281;
    public static final DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field15282;
    private String Field15283 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public void Method435(@NotNull @NotNull String string) {
        Intrinsics.checkParameterIsNotNull((Object)string, (String)"message");
        if (Ljc0gDTN8WkwPRHY480HpEkScGALG41A.Field17803.currentScreen instanceof ABhseIFL1PQVX4WAovmpeO8P6T0dQPpk) {
            new cZ4bypSRWV3YzaQMwmpKCiS4RsRbKd08(TextFormatting.GRAY.toString() + "[" + TextFormatting.WHITE + leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Method6783() + TextFormatting.GRAY + "] " + string).Method167();
            return;
        }
        NCAK0sFLWmP0xBxkwWzF2T1bn3cRmhqs.Method5506().Method1882(string);
    }

    public void Method436(@NotNull @NotNull String string) {
        Intrinsics.checkParameterIsNotNull((Object)string, (String)"message");
        if (Ljc0gDTN8WkwPRHY480HpEkScGALG41A.Field17803.currentScreen instanceof ABhseIFL1PQVX4WAovmpeO8P6T0dQPpk) {
            new cZ4bypSRWV3YzaQMwmpKCiS4RsRbKd08(TextFormatting.GRAY.toString() + "[" + TextFormatting.GOLD + leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Method6783() + TextFormatting.GRAY + "] " + string).Method167();
            return;
        }
        NCAK0sFLWmP0xBxkwWzF2T1bn3cRmhqs.Method5507().Method1882(string);
    }

    public void Method437(@NotNull @NotNull String string) {
        Intrinsics.checkParameterIsNotNull((Object)string, (String)"message");
        if (Ljc0gDTN8WkwPRHY480HpEkScGALG41A.Field17803.currentScreen instanceof ABhseIFL1PQVX4WAovmpeO8P6T0dQPpk) {
            new cZ4bypSRWV3YzaQMwmpKCiS4RsRbKd08(TextFormatting.GRAY.toString() + "[" + TextFormatting.LIGHT_PURPLE + leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Method6783() + TextFormatting.GRAY + "] " + string).Method167();
            return;
        }
        NCAK0sFLWmP0xBxkwWzF2T1bn3cRmhqs.Method5503().Method1882(string);
    }

    public void Method438(@NotNull @NotNull String string) {
        Intrinsics.checkParameterIsNotNull((Object)string, (String)"message");
        if (Ljc0gDTN8WkwPRHY480HpEkScGALG41A.Field17803.currentScreen instanceof ABhseIFL1PQVX4WAovmpeO8P6T0dQPpk) {
            new cZ4bypSRWV3YzaQMwmpKCiS4RsRbKd08(TextFormatting.GRAY.toString() + "[" + TextFormatting.RED + leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Method6783() + TextFormatting.GRAY + "] " + string).Method167();
            return;
        }
        NCAK0sFLWmP0xBxkwWzF2T1bn3cRmhqs.Method5504().Method1882(string);
    }

    public void Method439(@Nullable @Nullable String string) {
        if (!(Ljc0gDTN8WkwPRHY480HpEkScGALG41A.Field17803.currentScreen instanceof ABhseIFL1PQVX4WAovmpeO8P6T0dQPpk)) {
            NCAK0sFLWmP0xBxkwWzF2T1bn3cRmhqs.Method5506().Method1875(string);
            return;
        }
        String string2 = string;
        if (string2 == null) {
            Intrinsics.throwNpe();
        }
        new cZ4bypSRWV3YzaQMwmpKCiS4RsRbKd08(string2).Method167();
    }

    static {
        Field15282 = new DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(null);
        Field15281 = new DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf();
    }

    public static final DcOePtwa3mbm08qEwXWa3EPFsCiiyIad$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Method440() {
        return Field15281;
    }

    private static String Method441(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-1343372000 ^ (long)-1343372000);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-1554820360L ^ 0xA3535207);
            int n2 = (int)((long)1271486788 ^ (long)1271486877);
            cArray2[n] = (char)(cArray[n] ^ (((int)-427608778L ^ 0xE6830031) << 1 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

