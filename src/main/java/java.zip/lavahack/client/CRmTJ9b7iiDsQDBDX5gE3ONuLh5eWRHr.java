/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.GgPix2l2IhOV2YPNehltx3kYgn5Hae5d;
import lavahack.client.eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL;

public interface CRmTJ9b7iiDsQDBDX5gE3ONuLh5eWRHr {
    public void Method2866(GgPix2l2IhOV2YPNehltx3kYgn5Hae5d var1) throws eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL;

    public void Method2867(GgPix2l2IhOV2YPNehltx3kYgn5Hae5d var1);

    public boolean Method2868(String var1);

    public boolean Method2869(String var1);

    public void Method2870(GgPix2l2IhOV2YPNehltx3kYgn5Hae5d var1) throws eOzfLK9AJmts1SDoM2MkHzTMR3OjWXRL;

    public String Method2871();

    public String Method2872();

    public CRmTJ9b7iiDsQDBDX5gE3ONuLh5eWRHr Method2873();

    public void Method2874();

    public String toString();
}

