/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 */
package lavahack.client;

import java.util.HashMap;
import net.minecraft.util.EnumFacing;

public final class eFEpfCAesya7Iz2wWcyO3vTwaFs0zBbe {
    public static final HashMap Field12667 = new HashMap();
    private int Field12668;

    static {
        Field12667.put(EnumFacing.DOWN, (int)945008672L ^ 0x3853B021);
        Field12667.put(EnumFacing.WEST, (int)((long)-312150263 ^ (long)-312150264) << 4);
        Field12667.put(EnumFacing.NORTH, (int)((long)-510017166 ^ (long)-510017165) << 2);
        Field12667.put(EnumFacing.SOUTH, (int)((long)-1281966604 ^ (long)-1281966603) << 3);
        Field12667.put(EnumFacing.EAST, (int)((long)2003953156 ^ (long)2003953157) << 5);
        Field12667.put(EnumFacing.UP, ((int)-1573988535L ^ 0xA22ED748) << 1);
    }
}

