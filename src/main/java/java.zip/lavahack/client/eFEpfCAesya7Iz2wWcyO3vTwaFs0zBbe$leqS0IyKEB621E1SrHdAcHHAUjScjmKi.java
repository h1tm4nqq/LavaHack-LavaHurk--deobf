/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public final class eFEpfCAesya7Iz2wWcyO3vTwaFs0zBbe$leqS0IyKEB621E1SrHdAcHHAUjScjmKi {
    public static final int Field17621;
    public static final int Field17622;
    public static final int Field17623;
    public static final int Field17624;
    public static final int Field17625;
    public static final int Field17626;
    public static final int Field17627;
    public static final int Field17628;
    public static final int Field17629;
    public static final int Field17630;
    public static final int Field17631;
    public static final int Field17632;
    public static final int Field17633;
    private int Field17634;

    static {
        Field17633 = (int)((long)-220629485 ^ (long)-220629460);
        Field17632 = (int)((long)-1577168735 ^ (long)-1577168732) << 3;
        Field17631 = (int)((long)938318979 ^ (long)938318976) << 3;
        Field17630 = (int)((long)1223662189 ^ (long)1223662180) << 2;
        Field17629 = (int)((long)536967594 ^ (long)536967599) << 2;
        Field17628 = (int)((long)215676304 ^ (long)215676309) << 1;
        Field17627 = (int)1697974853L ^ 0x65350A4C;
        Field17626 = ((int)528431134L ^ 0x1F7F381D) << 1;
        Field17625 = (int)1353097892L ^ 0x50A6A2A1;
        Field17624 = (int)((long)-952143238 ^ (long)-952143253) << 1;
        Field17623 = (int)((long)1199165249 ^ (long)1199165280);
        Field17622 = (int)((long)-439431430 ^ (long)-439431437) << 1;
        Field17621 = (int)289664499L ^ 0x1143EDE2;
    }
}

