/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

final class AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3
extends Enum {
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3 Field16501 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3("Never", (int)-2020633425L ^ 0x878F94AF);
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3 Field16502 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3("OffGround", (int)((long)703637254 ^ (long)703637255));
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3 Field16503 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3("YChange", ((int)-1275874394L ^ 0xB3F3B3A7) << 1);
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3 Field16504 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3("PositiveYChange", (int)173273472L ^ 0xA53F183);
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3 Field16505 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3("Combo", ((int)1465709579L ^ 0x575CF40A) << 2);
    public static final /* enum */ AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3 Field16506 = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3("OnComplete", (int)-817239784L ^ 0xCF49E91D);
    private static final AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3[] Field16507;
    private String Field16508 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public static AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3[] values() {
        return (AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3[])Field16507.clone();
    }

    public static AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3 valueOf(String string) {
        return Enum.valueOf(AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3.class, string);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3() {
        void var2_-1;
        void var1_-1;
    }

    static {
        AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3[] aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3Array = new AT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3[((int)158096468L ^ 0x96C5C57) << 1];
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3Array[(int)((long)-471707534 ^ (long)-471707534)] = Field16501;
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3Array[(int)-1395392686L ^ 0xACD3FF53] = Field16502;
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3Array[(int)((long)1740629001 ^ (long)1740629000) << 1] = Field16503;
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3Array[(int)659028174L ^ 0x2747F8CD] = Field16504;
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3Array[((int)-2143995973L ^ 0x803537BA) << 2] = Field16505;
        aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3Array[(int)-135955935L ^ 0xF7E57A24] = Field16506;
        Field16507 = aT4Eb2QUOXh8P7k5bsyaslDhPZ3FpNxA$vhU7xeLI7WfeS1z6pYV1cBvLp1rkdkt3Array;
    }

    private static String Method6939(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)-1419406650L ^ 0xAB6592C6;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)1197359362 ^ (long)1197359613);
            int n2 = ((int)829589006L ^ 0x31728623) << 1;
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)370634440 ^ (long)370618987) ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

