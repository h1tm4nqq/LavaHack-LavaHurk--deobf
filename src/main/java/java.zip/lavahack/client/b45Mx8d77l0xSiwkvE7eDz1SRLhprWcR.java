/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import java.util.List;
import lavahack.client.DkMZhn6HTXSMui7v30mYhxPkVEtejJaC;
import lavahack.client.ZJ0rgChafnBW8bL000CqsHF7n9Wv4YDA;
import lavahack.client.Zlk9e3kfSWGG6zqSbWF0nVPgAvKtrhFE;

public interface b45Mx8d77l0xSiwkvE7eDz1SRLhprWcR {
    public ZJ0rgChafnBW8bL000CqsHF7n9Wv4YDA Method1312(Zlk9e3kfSWGG6zqSbWF0nVPgAvKtrhFE var1, DkMZhn6HTXSMui7v30mYhxPkVEtejJaC var2);

    public ZJ0rgChafnBW8bL000CqsHF7n9Wv4YDA Method1313(Zlk9e3kfSWGG6zqSbWF0nVPgAvKtrhFE var1, List var2);
}

