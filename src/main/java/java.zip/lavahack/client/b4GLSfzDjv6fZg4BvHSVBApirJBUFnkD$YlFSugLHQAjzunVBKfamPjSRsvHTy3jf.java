/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec3i
 */
package lavahack.client;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.minecraft.util.math.Vec3i;

public final class b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf
extends Enum {
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field14352 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("Cev", (int)((long)-860297551 ^ (long)-860297551), Collections.singletonList(new Vec3i((int)((long)548487659 ^ (long)548487659), (int)((long)-1416398155 ^ (long)-1416398156) << 1, (int)((long)-1423252838 ^ (long)-1423252838))));
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf Field14353;
    public final List Field14354;
    private static final b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[] Field14355;
    private int Field14356;

    public static b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[] values() {
        return (b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[])Field14355.clone();
    }

    public static b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf valueOf(String string) {
        return Enum.valueOf(b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.class, string);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf() {
        void var3_1;
        void var2_-1;
        void var1_-1;
        this.Field14354 = var3_1;
    }

    static {
        Vec3i[] vec3iArray = new Vec3i[(int)((long)1464226218 ^ (long)1464226219) << 3];
        vec3iArray[(int)((long)-395753960 ^ (long)-395753960)] = new Vec3i((int)((long)967711823 ^ (long)967711822), (int)((long)-131290113 ^ (long)-131290114) << 1, (int)-2040293661L ^ 0x866396E3);
        vec3iArray[(int)-1318414968L ^ 0xB16A9589] = new Vec3i((int)((long)223852812 ^ (long)-223852813), ((int)-749532344L ^ 0xD3530B49) << 1, (int)-1563528439L ^ 0xA2CE7309);
        vec3iArray[(int)((long)1615806002 ^ (long)1615806003) << 1] = new Vec3i((int)((long)-396974595 ^ (long)-396974595), ((int)989117205L ^ 0x3AF4BB14) << 1, (int)((long)-1418116681 ^ (long)-1418116682));
        vec3iArray[(int)((long)201134208 ^ (long)201134211)] = new Vec3i((int)864409566L ^ 0x3385D7DE, (int)((long)1350363400 ^ (long)1350363401) << 1, (int)1431465735L ^ 0xAAAD90F8);
        vec3iArray[((int)-519226906L ^ 0xE10D39E7) << 2] = new Vec3i((int)702217766L ^ 0x29DAFE27, (int)((long)1551490129 ^ (long)1551490128) << 1, (int)-1381969444L ^ 0xADA0D1DD);
        vec3iArray[(int)-1510078028L ^ 0xA5FE09B1] = new Vec3i((int)-1678542445L ^ 0x640C866C, ((int)1933630970L ^ 0x7340DDFB) << 1, (int)-294844751L ^ 0x1192F94E);
        vec3iArray[(int)((long)-1453862462 ^ (long)-1453862463) << 1] = new Vec3i((int)9669661L ^ 0x938C1C, (int)((long)331004674 ^ (long)331004675) << 1, (int)((long)122700364 ^ (long)-122700365));
        vec3iArray[(int)((long)107983975 ^ (long)107983968)] = new Vec3i((int)((long)-950736615 ^ (long)950736614), ((int)1118428196L ^ 0x42A9DC25) << 1, (int)-1693734402L ^ 0x9B0BA9FF);
        Field14353 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf("Civ", (int)((long)794367580 ^ (long)794367581), Arrays.asList(vec3iArray));
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[] b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf[((int)-1158992397L ^ 0xBAEB2DF2) << 1];
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[(int)((long)-1591736781 ^ (long)-1591736781)] = Field14352;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray[(int)968209080L ^ 0x39B5B2B9] = Field14353;
        Field14355 = b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$YlFSugLHQAjzunVBKfamPjSRsvHTy3jfArray;
    }

    private static String Method5535(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)-709325577L ^ 0xD5B88CF7;
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-105039944L ^ 0xF9BD3747);
            int n2 = (int)((long)1491461452 ^ (long)1491461435);
            cArray2[n] = (char)(cArray[n] ^ ((int)((long)680828189 ^ (long)680820766) ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

