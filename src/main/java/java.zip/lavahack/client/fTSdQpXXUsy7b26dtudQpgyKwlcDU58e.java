/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import com.kisman.cc.event.Event;
import kotlin.Metadata;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lcom/kisman/cc/event/events/EventSetupFog;", "Lcom/kisman/cc/event/Event;", "()V", "kisman.cc"})
public final class fTSdQpXXUsy7b26dtudQpgyKwlcDU58e
extends Event {
    private String Field9674 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public fTSdQpXXUsy7b26dtudQpgyKwlcDU58e() {
        super(new Object[(int)((long)-1633587720 ^ (long)-1633587720)]);
    }
}

