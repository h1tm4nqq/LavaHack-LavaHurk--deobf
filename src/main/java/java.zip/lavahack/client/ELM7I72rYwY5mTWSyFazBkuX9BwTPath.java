/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import lavahack.client.meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU;

public class ELM7I72rYwY5mTWSyFazBkuX9BwTPath {
    public final meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU Field11615;
    public final String Field11616;
    public final int Field11617;
    public final int Field11618;
    public final int Field11619;
    public ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field11620 = ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field13466;
    public int Field11621 = (int)-829610127L ^ 0xCE8D2771;
    public int Field11622 = (int)((long)1282717908 ^ (long)1282717908);
    public int Field11623 = (int)-471864468L ^ 0xE3DFEB6C;
    public int Field11624 = (int)((long)1403770657 ^ (long)1403770657);
    public int Field11625 = (int)((long)-1798556906 ^ (long)-1798556906);
    private String Field11626 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public ELM7I72rYwY5mTWSyFazBkuX9BwTPath(meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU2, String string) {
        this.Field11615 = meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU2;
        this.Field11616 = string;
        this.Field11617 = meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU2.Method2891();
        this.Field11618 = meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU2.Method2893();
        this.Field11619 = meYrWVonLJdF1AJ3NQoOtP0KCSTOigFU2.Method2892();
    }

    public boolean Method3605(int n, int n2, int n3) {
        if (n != this.Field11623) return ((int)-1790301266L ^ 0x954A2BAF) != 0;
        if (n2 != this.Field11624) return ((int)-1790301266L ^ 0x954A2BAF) != 0;
        if (n3 != this.Field11625) return ((int)-1790301266L ^ 0x954A2BAF) != 0;
        this.Method3606(ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field13468);
        this.Field11623 += ((int)1369801118L ^ 0x51A5819F) << 4;
        if (this.Field11623 < this.Field11617) return ((int)-1790301266L ^ 0x954A2BAF) != 0;
        this.Field11623 = (int)((long)-96680717 ^ (long)-96680717);
        this.Field11624 += ((int)1107047658L ^ 0x41FC34EB) << 4;
        if (this.Field11624 < this.Field11618) return ((int)-1790301266L ^ 0x954A2BAF) != 0;
        this.Field11624 = (int)254209636L ^ 0xF26EE64;
        this.Field11625 += (int)((long)2092368301 ^ (long)2092368300) << 4;
        if (this.Field11625 < this.Field11619) return ((int)-1790301266L ^ 0x954A2BAF) != 0;
        this.Method3606(ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field13470);
        return (int)((long)655818416 ^ (long)655818416) != 0;
    }

    public void Method3606(ELM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi) {
        this.Field11620 = eLM7I72rYwY5mTWSyFazBkuX9BwTPath$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
        this.Field11621 = (int)((long)-800005271 ^ (long)-800005271);
        this.Field11622 = (int)219070094L ^ 0xD0EBE8E;
    }
}

