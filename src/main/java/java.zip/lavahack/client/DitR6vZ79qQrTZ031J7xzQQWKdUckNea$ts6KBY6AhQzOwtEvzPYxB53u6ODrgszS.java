/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package lavahack.client;

import kotlin.Metadata;
import lavahack.client.DitR6vZ79qQrTZ031J7xzQQWKdUckNea;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lcom/kisman/cc/event/events/EventIngameOverlay$Pumpkin;", "Lcom/kisman/cc/event/events/EventIngameOverlay;", "()V", "kisman.cc"})
public final class DitR6vZ79qQrTZ031J7xzQQWKdUckNea$ts6KBY6AhQzOwtEvzPYxB53u6ODrgszS
extends DitR6vZ79qQrTZ031J7xzQQWKdUckNea {
    private String Field16342 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";
}

