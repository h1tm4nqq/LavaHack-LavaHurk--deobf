/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

import lavahack.client.auE3dCySxyIc1tKngAVuALlcvYBWsMni$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf;
import lavahack.client.auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;

class auE3dCySxyIc1tKngAVuALlcvYBWsMni$1 {
    static final int[] Field7892;
    static final int[] Field7893;
    private String Field7894 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        Field7893 = new int[auE3dCySxyIc1tKngAVuALlcvYBWsMni$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.values().length];
        auE3dCySxyIc1tKngAVuALlcvYBWsMni$1.Field7893[auE3dCySxyIc1tKngAVuALlcvYBWsMni$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field8329.ordinal()] = (int)((long)1023694016 ^ (long)1023694017);
        auE3dCySxyIc1tKngAVuALlcvYBWsMni$1.Field7893[auE3dCySxyIc1tKngAVuALlcvYBWsMni$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field8330.ordinal()] = ((int)-621081778L ^ 0xDAFB0B4F) << 1;
        auE3dCySxyIc1tKngAVuALlcvYBWsMni$1.Field7893[auE3dCySxyIc1tKngAVuALlcvYBWsMni$YlFSugLHQAjzunVBKfamPjSRsvHTy3jf.Field8331.ordinal()] = (int)((long)-1030608607 ^ (long)-1030608606);
        Field7892 = new int[auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.values().length];
        auE3dCySxyIc1tKngAVuALlcvYBWsMni$1.Field7892[auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field14820.ordinal()] = (int)1343428406L ^ 0x50131737;
        auE3dCySxyIc1tKngAVuALlcvYBWsMni$1.Field7892[auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field14821.ordinal()] = ((int)-113389260L ^ 0xF93DD135) << 1;
        auE3dCySxyIc1tKngAVuALlcvYBWsMni$1.Field7892[auE3dCySxyIc1tKngAVuALlcvYBWsMni$leqS0IyKEB621E1SrHdAcHHAUjScjmKi.Field14822.ordinal()] = (int)((long)426377670 ^ (long)426377669);
    }
}

