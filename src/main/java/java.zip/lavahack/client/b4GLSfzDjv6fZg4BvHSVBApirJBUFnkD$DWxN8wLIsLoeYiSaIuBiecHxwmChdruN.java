/*
 * Decompiled with CFR 0.152.
 */
package lavahack.client;

public final class b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN
extends Enum {
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN Field13625 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN("MainHand", (int)154629387L ^ 0x937750B);
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN Field13626 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN("OffHand", (int)790469201L ^ 0x2F1D9A50);
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN Field13627 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN("CurrentHand", ((int)1834908581L ^ 0x6D5E7BA4) << 1);
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN Field13628 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN("PacketSwing", (int)1014996977L ^ 0x3C7F9FF2);
    public static final /* enum */ b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN Field13629 = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN("None", ((int)-1763676334L ^ 0x96E06F53) << 2);
    private static final b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN[] Field13630;
    private int Field13631;

    public static b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN[] values() {
        return (b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN[])Field13630.clone();
    }

    public static b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN valueOf(String string) {
        return Enum.valueOf(b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN.class, string);
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN() {
        void var2_-1;
        void var1_-1;
    }

    static {
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN[] b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruNArray = new b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruN[(int)1653719979L ^ 0x6291C3AE];
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruNArray[(int)((long)-718820238 ^ (long)-718820238)] = Field13625;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruNArray[(int)((long)208887831 ^ (long)208887830)] = Field13626;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruNArray[((int)648375067L ^ 0x26A56B1A) << 1] = Field13627;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruNArray[(int)((long)2137489762 ^ (long)2137489761)] = Field13628;
        b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruNArray[(int)((long)-1094018434 ^ (long)-1094018433) << 2] = Field13629;
        Field13630 = b4GLSfzDjv6fZg4BvHSVBApirJBUFnkD$DWxN8wLIsLoeYiSaIuBiecHxwmChdruNArray;
    }

    private static String Method4990(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-906761670 ^ (long)-906761670);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & (int)((long)-1943157675 ^ (long)-1943157590);
            int n2 = ((int)-577385196L ^ 0xDD95CD15) << 6;
            cArray2[n] = (char)(cArray[n] ^ (((int)748679111L ^ 0x2C9FFC74) << 2 ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

