/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.ServerData
 */
package lavahack.client;

import lavahack.client.A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB;
import net.minecraft.client.multiplayer.ServerData;

public class A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB$leqS0IyKEB621E1SrHdAcHHAUjScjmKi
extends A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB {
    private String Field17046 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    public A50mpNcG9Jr7zq65VRTWW1xeYXIz5VEB$leqS0IyKEB621E1SrHdAcHHAUjScjmKi(ServerData serverData) {
        super(serverData);
    }
}

