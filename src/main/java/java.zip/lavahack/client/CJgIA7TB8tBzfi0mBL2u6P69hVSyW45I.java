//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\hitmanqq\Documents\Decompiler\mappings"!

/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 */
package lavahack.client;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import lavahack.client.CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I$leqS0IyKEB621E1SrHdAcHHAUjScjmKi;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 13}, bv={1, 0, 3}, k=1, d1={"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0011B\u001b\b\u0002\u0012\u0012\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003\"\u00020\u0004\u00a2\u0006\u0002\u0010\u0005R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010\u00a8\u0006\u0012"}, d2={"Lcom/kisman/cc/util/enums/XRayBlocks;", "", "blocks", "", "Lnet/minecraft/block/Block;", "(Ljava/lang/String;I[Lnet/minecraft/block/Block;)V", "validator", "Lcom/kisman/cc/util/enums/XRayBlocks$Validator;", "getValidator", "()Lcom/kisman/cc/util/enums/XRayBlocks$Validator;", "Coal", "Iron", "Gold", "Lapis", "Redstone", "Diamond", "Emerald", "Validator", "kisman.cc"})
public final class CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I
extends Enum {
    public static final /* enum */ CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I Field10925;
    public static final /* enum */ CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I Field10926;
    public static final /* enum */ CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I Field10927;
    public static final /* enum */ CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I Field10928;
    public static final /* enum */ CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I Field10929;
    public static final /* enum */ CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I Field10930;
    public static final /* enum */ CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I Field10931;
    private static final CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I[] Field10932;
    @NotNull
    private final CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Field10933;
    private String Field10934 = " TheKisDevs & LavaHack Development owns you, and I am sorry, because it is uncrackable <3";

    static {
        CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I[] cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I[(int)((long)-866802664 ^ (long)-866802657)];
        CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I[] cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray2 = cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray;
        int n = (int)-1762713772L ^ 0x96EF1F54;
        int n2 = (int)((long)-216203148 ^ (long)-216203148);
        Block[] blockArray = new Block[(int)803440110L ^ 0x2FE385EF];
        int n3 = (int)315604832L ^ 0x12CFBF60;
        Block block = Blocks.COAL_ORE;
        Intrinsics.checkExpressionValueIsNotNull((Object)block, (String)"Blocks.COAL_ORE");
        blockArray[n3] = block;
        cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray[n] = Field10925 = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I("Coal", n2, blockArray);
        int n4 = (int)-1528986391L ^ 0xA4DD84E8;
        int n5 = (int)1081173373L ^ 0x4071657C;
        Block[] blockArray2 = new Block[(int)1950088454L ^ 0x743BFD07];
        int n6 = (int)((long)532113198 ^ (long)532113198);
        Block block2 = Blocks.IRON_ORE;
        Intrinsics.checkExpressionValueIsNotNull((Object)block2, (String)"Blocks.IRON_ORE");
        blockArray2[n6] = block2;
        cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray[n4] = Field10926 = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I("Iron", n5, blockArray2);
        int n7 = ((int)-20456055L ^ 0xFEC7DD88) << 1;
        int n8 = ((int)-1868553405L ^ 0x90A02342) << 1;
        Block[] blockArray3 = new Block[(int)((long)793704330 ^ (long)793704331)];
        int n9 = (int)-1589882525L ^ 0xA13C5163;
        Block block3 = Blocks.GOLD_ORE;
        Intrinsics.checkExpressionValueIsNotNull((Object)block3, (String)"Blocks.GOLD_ORE");
        blockArray3[n9] = block3;
        cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray[n7] = Field10927 = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I("Gold", n8, blockArray3);
        int n10 = (int)-219080532L ^ 0xF2F118AF;
        int n11 = (int)((long)-1343860905 ^ (long)-1343860908);
        Block[] blockArray4 = new Block[(int)-1313060256L ^ 0xB1BC4A61];
        int n12 = (int)((long)866287324 ^ (long)866287324);
        Block block4 = Blocks.LAPIS_ORE;
        Intrinsics.checkExpressionValueIsNotNull((Object)block4, (String)"Blocks.LAPIS_ORE");
        blockArray4[n12] = block4;
        cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray[n10] = Field10928 = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I("Lapis", n11, blockArray4);
        int n13 = ((int)-651599113L ^ 0xD92962F6) << 2;
        int n14 = (int)((long)-1106654248 ^ (long)-1106654247) << 2;
        Block[] blockArray5 = new Block[((int)1330831577L ^ 0x4F52E0D8) << 1];
        int n15 = (int)-1904946534L ^ 0x8E74D29A;
        Block block5 = Blocks.REDSTONE_ORE;
        Intrinsics.checkExpressionValueIsNotNull((Object)block5, (String)"Blocks.REDSTONE_ORE");
        blockArray5[n15] = block5;
        int n16 = (int)-1557924397L ^ 0xA323F5D2;
        Block block6 = Blocks.LIT_REDSTONE_ORE;
        Intrinsics.checkExpressionValueIsNotNull((Object)block6, (String)"Blocks.LIT_REDSTONE_ORE");
        blockArray5[n16] = block6;
        cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray[n13] = Field10929 = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I("Redstone", n14, blockArray5);
        int n17 = (int)-272850187L ^ 0xEFBCA2F0;
        int n18 = (int)((long)261269738 ^ (long)261269743);
        Block[] blockArray6 = new Block[(int)((long)-1884449787 ^ (long)-1884449788)];
        int n19 = (int)877399860L ^ 0x344C0F34;
        Block block7 = Blocks.DIAMOND_ORE;
        Intrinsics.checkExpressionValueIsNotNull((Object)block7, (String)"Blocks.DIAMOND_ORE");
        blockArray6[n19] = block7;
        cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray[n17] = Field10930 = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I("Diamond", n18, blockArray6);
        int n20 = (int)((long)1973871678 ^ (long)1973871677) << 1;
        int n21 = (int)((long)-565781899 ^ (long)-565781898) << 1;
        Block[] blockArray7 = new Block[(int)-1472829512L ^ 0xA83667B9];
        int n22 = (int)783804706L ^ 0x2EB7E922;
        Block block8 = Blocks.EMERALD_BLOCK;
        Intrinsics.checkExpressionValueIsNotNull((Object)block8, (String)"Blocks.EMERALD_BLOCK");
        blockArray7[n22] = block8;
        cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray[n20] = Field10931 = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I("Emerald", n21, blockArray7);
        Field10932 = cJgIA7TB8tBzfi0mBL2u6P69hVSyW45IArray;
    }

    @NotNull
    @NotNull
    public final CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I$leqS0IyKEB621E1SrHdAcHHAUjScjmKi Method2906() {
        return this.Field10933;
    }

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I() {
        void var3_1;
        void var2_-1;
        void var1_-1;
        void v0 = var3_1;
        this.Field10933 = new CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I$leqS0IyKEB621E1SrHdAcHHAUjScjmKi((Block[])Arrays.copyOf(v0, ((void)v0).length));
    }

    public static CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I[] values() {
        return (CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I[])Field10932.clone();
    }

    public static CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I valueOf(String string) {
        return Enum.valueOf(CJgIA7TB8tBzfi0mBL2u6P69hVSyW45I.class, string);
    }

    private static String Method2907(String string) {
        if (string == null) throw new NullPointerException("String deobfuscation parameter should not be null");
        char[] cArray = string.toCharArray();
        char[] cArray2 = new char[cArray.length];
        int n = (int)((long)-1053870137 ^ (long)-1053870137);
        while (n < cArray.length) {
            int cfr_ignored_0 = n & ((int)-321647281L ^ 0xECD40DB0);
            int n2 = (int)2017286576L ^ 0x783D5925;
            cArray2[n] = (char)(cArray[n] ^ ((int)1249037393L ^ 0x4A729DEC ^ n2));
            ++n;
        }
        return new String(cArray2);
    }
}

